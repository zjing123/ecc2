<?php
/**
 * Observe and upload customer to EConnect automatically.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer;

use Ebizcharge\Ebizcharge\Model\Config;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class ConfigObserver implements ObserverInterface
{
    protected $_tran;
    protected $config;
    protected $request;
    protected $_request;

    public function __construct
    (
        TranApi $tranApi,
        Config $config,
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->_tran = $tranApi;
        $this->config = $config;
        $this->_request = $request;
    }

    public function execute(EventObserver $observer)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $dataclass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');

		$reqeustParams = $this->_request->getParams();
        $paymentMethods = $reqeustParams['groups'];
        $ebizChargeArray = $paymentMethods['ebizcharge_ebizcharge'];

        if (empty($ebizChargeArray) || $this->config->isEbizchargeActive() == 0) {
			$this->_tran->log('EBizCharge module not found or disabled or inactive');
			$dataclass->updateConfig("recurring_payments", 0);
			$this->_tran->log('Recurring Payments are disabled');
			$dataclass->flushCache();
            $this->_tran->log('Cache is cleared');
            return;
        }

        $dataclass->validateApiKey();
    }

}