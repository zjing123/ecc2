<?php
/**
 * ECC GOR converttoxml event observer Class.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2016 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer\ECC;

use Magento\Framework\Event\ObserverInterface;

class GOR implements ObserverInterface
{
    protected $_order;
    protected $_logger;

    public function __construct(
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Psr\Log\LoggerInterface $logger
    )
    {
        $this->_order = $order;
        $this->_logger = $logger;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try
        {
            $message = $observer->getEvent()->getMessage();
            $message_array = $message->getMessageArray();

            $paymentMethod = $message_array['messages']['request']['body']['payment']['paymentMethod'];
            //$magentoid = $message_array['messages']['request']['body']['orderBy']['eccLoginId']; //This is not reliable, determine account type and get magentoid that way

            if ($paymentMethod == "CC")
            {
                $incrementIdWithPrefix = $message_array['messages']['request']['body']['order']['orderReference'];
                $pieces = explode("-", $incrementIdWithPrefix);

                if (sizeof($pieces) > 1)
                    $incrementId = $pieces[1];
                else
                    $incrementId = $pieces[0];

                $this->_order->loadByIncrementId($incrementId);

                if ($this->_order->getId())
                {
                    $customerid = $this->_order->getCustomerId();
                    $magentoid = "";

                    //if ($this->_order->getCustomerIsGuest() != 1)
                    //	$magentoid = $customerid;

                    $payment = $this->_order->getPayment();
                    $method = $payment->getMethod();

                    if ($method == "ebizcharge_ebizcharge")
                    {
                        $methodid = $payment->getEbzcMethodId();
                        $authcode = $payment->getCcApproval();
                        $refnum = $payment->getCcTransId();
                        $avsresultcode = $payment->getCcAvsStatus();
                        $cvv2resultcode = $payment->getCcCidStatus();
                        $cctype = $message_array['messages']['request']['body']['payment']['creditCard']['type'];

                        if ($methodid > 0) {
                            $magentoid = $customerid;
                        }

                        //$message_array['messages']['request']['body']['payment']['creditCard']['cardToken'] = "[EBIZCHARGE]" . "|" . $methodid . "|" . $refnum . "|" . $authcode . "|" . $avsresultcode . "|" . $cvv2resultcode . "|" . $magentoid;
                        $message_array['messages']['request']['body']['order']['orderText'] = "[EBIZCHARGE]" . "|" . $methodid . "|" . $refnum . "|" . $authcode . "|" . $avsresultcode . "|" . $cvv2resultcode . "|" . $magentoid;
                        $message_array['messages']['request']['body']['payment']['creditCard']['authorizationCode'] = 'Approved';

                        switch ($cctype)
                        {
                            case "AE":
                            case "ERPAX":
                            case "AMEX":
                                $cctype = "A";
                                break;
                            case "DISC":
                            case "ERPDS":
                            case "DI":
                                $cctype = "DS";
                                break;
                            case "ERPMC":
                            case "MC":
                                $cctype = "M";
                                break;
                            case "ERPVI":
                            case "VI":
                                $cctype = "V";
                                break;
                        }

                        $message_array['messages']['request']['body']['payment']['creditCard']['type'] = $cctype;

                        $message->setMessageArray($message_array);
                    }
                }
            }
        }
        catch(\Exception $ex)
        {
            $this->_logger->info($ex->getMessage());
        }
    }
}
