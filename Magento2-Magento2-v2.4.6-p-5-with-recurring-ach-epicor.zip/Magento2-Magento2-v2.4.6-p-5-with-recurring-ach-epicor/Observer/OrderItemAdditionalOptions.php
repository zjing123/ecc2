<?php
//declare(strict_types=1);
namespace Ebizcharge\Ebizcharge\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Unserialize\Unserialize;
use \Magento\Framework\Serialize\Serializer\Json;

class OrderItemAdditionalOptions implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var RequestInterface
     */
    private $request;
    protected $_tran;
    protected $productRepository;
    protected $configurable;

    /**
     * @param RequestInterface $request
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable
     */
    public function __construct(
        RequestInterface                                             $request,
        \Ebizcharge\Ebizcharge\Model\TranApi                         $tranApi,
        \Magento\Catalog\Api\ProductRepositoryInterface              $productRepository,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable
    )
    {
        $this->request = $request;
        $this->_tran = $tranApi;
        $this->productRepository = $productRepository;
        $this->configurable = $configurable;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            $quote = $observer->getQuote();
            $order = $observer->getOrder();
            $quoteItems = [];

            foreach ($quote->getAllVisibleItems() as $quoteItem) {
                $quoteItems[$quoteItem->getId()] = $quoteItem;
            }

            $item = $this->request->getParam('item');

            foreach ($order->getAllVisibleItems() as $orderItem) {

                $options = $orderItem->getProductOptions();
                $pid = $this->request->getParam('pid');
                $itemId = $orderItem->getQuoteitemId();
                $productId = $orderItem->getProductId();
                $productType = $orderItem->getProductType();
                $currentpid = '';

                if ($productType == 'configurable') {
                    $superAttribute = $options['info_buyRequest']['super_attribute']; //childs super attribute details
                    $currentpid = $this->getChildFromProductAttribute($productId, $superAttribute);
                }

                if (!isset($item[$itemId])) {
                    $recurringOptions = $item[$pid];
                } else {
                    $recurringOptions = $item[$itemId];
                }

                $recurringOptions['rec_activate'] = isset($recurringOptions['rec_activate']) ? 1 : 0;

                $childProductId = $currentpid ? $currentpid : $productId;

                if ($recurringOptions['rec_activate'] == 1) {
                    $info_buyRequest['product'] = $productId;
                    $info_buyRequest['currentpid'] = $childProductId;

                    $options['info_buyRequest'] = $info_buyRequest;
                    $options['info_buyRequest']['recurring'] = $recurringOptions;

                    $orderItem->setProductOptions($options);
                }

            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /* Pass Configurable product id as $configId
     * Pass array of super attribute of child item
     */
    public function getChildFromProductAttribute($configId, $superAttribute)
    {
        $_configProduct = $this->productRepository->getById($configId);
        $usedChild = $this->configurable->getProductByAttributes($superAttribute, $_configProduct);
        return $usedChild->getId();
    }

}
