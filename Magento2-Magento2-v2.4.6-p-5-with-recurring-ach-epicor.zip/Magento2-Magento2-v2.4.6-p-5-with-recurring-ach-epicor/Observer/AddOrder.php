<?php
/**
 * Observe and upload order to EConnect automatically.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer;

use Magento\Framework\ObjectManager\ObjectManager;

ini_set("soap.wsdl_cache_enabled", "0");
ini_set('memory_limit', '1000M');
ini_set('max_execution_time', 300);
ini_set('max_input_time', 600);
ini_set('max_input_vars', 3000);
ini_set('post_max_size', '1000M');

class AddOrder implements \Magento\Framework\Event\ObserverInterface
{
    protected $_logger;
    protected $_objectManager;
    protected $_orderFactory;
    protected $_checkoutSession;
    protected $_tran;
    protected $_token;
    protected $config;

    /**
     * @param \Psr\Log\LoggerInterface $loggerInterface
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param ObjectManager $objectManager
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Ebizcharge\Ebizcharge\Model\Token $token
     * @param \Ebizcharge\Ebizcharge\Model\Config $config
     */
    public function __construct(
        \Psr\Log\LoggerInterface                       $loggerInterface,
        \Magento\Checkout\Model\Session                $checkoutSession,
        \Magento\Sales\Model\OrderFactory              $orderFactory,
        \Magento\Framework\ObjectManager\ObjectManager $objectManager,
        // For TranAPI Config import
        \Ebizcharge\Ebizcharge\Model\TranApi           $tranApi,
        \Ebizcharge\Ebizcharge\Model\Token             $token,
        \Ebizcharge\Ebizcharge\Model\Config            $config
    )
    {
        $this->_logger = $loggerInterface;
        $this->_objectManager = $objectManager;
        $this->_orderFactory = $orderFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_tran = $tranApi;
        $this->_token = $token;
        $this->config = $config;
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->_tran->log('Add Order Observer ' . __METHOD__);

        if ($this->config->isEbizchargeActive() === 0) {
            $this->_tran->log('EBizCharge module is inactive. Please activate before upload.');
            return;
        }
        if ($this->config->isEconnectUploadEnabled() === 0) {
            $this->_tran->log('EBizCharge Upload functionality is inactive. Please activate before upload.');
            return;
        }
        sleep(2);

        try {
            $orderData = $observer->getEvent()->getData('order');
            if (!empty($orderData)) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $objectManager->get('Ebizcharge\Ebizcharge\Model\Data')->syncOrders($orderData);
                return;
            }

        } catch (Exception $e) {
            $this->_tran->log('Order #' . $orderData->getData('increment_id') . ' not added! ' . $e->getMessage());
        }
    }
}
