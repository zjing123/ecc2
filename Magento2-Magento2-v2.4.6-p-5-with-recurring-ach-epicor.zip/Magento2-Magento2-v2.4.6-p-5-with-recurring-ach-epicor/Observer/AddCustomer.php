<?php
/**
 * Observe and upload customer to EConnect automatically.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer;

use Magento\Framework\ObjectManager\ObjectManager;
use Magento\Framework\Event\ObserverInterface;

ini_set("soap.wsdl_cache_enabled", "0");
ini_set('memory_limit', '1000M');
ini_set('max_execution_time', 300);

ini_set('max_input_time', 600);
ini_set('max_input_vars', 3000);
ini_set('post_max_size', '1000M');

class AddCustomer implements ObserverInterface
{
    protected $_customerRepositoryInterface = null;
    protected $_tran = null;
    protected $_token = null;
    protected $config = null;

    /**
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Ebizcharge\Ebizcharge\Model\Token $token
     * @param \Ebizcharge\Ebizcharge\Model\Config $config
     */
    public function __construct
    (
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        // For TranAPI Config import
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\Config $config
    )
    {
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->_tran = $tranApi;
        $this->_token = $token;
        $this->config = $config;
    }

    public function SoftwareId()
    {
        return "Magento2";
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->_tran->log('Customer add/update caught by observer.' . __METHOD__);

        if ($this->config->isEbizchargeActive() == 0) {
            $this->_tran->log('EBizCharge module is inactive. Please activate before upload.');
            return;
        }
        if ($this->config->isEconnectUploadEnabled() == 0) {
            $this->_tran->log('EBizCharge Upload functionality is inactive. Please activate before upload.');
            return;
        }

        $customer = $observer->getEvent()->getCustomer();
        $customerId = $customer->getId();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $dataclass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
        $value = $dataclass->syncCustomer($customerId);
    }
}
