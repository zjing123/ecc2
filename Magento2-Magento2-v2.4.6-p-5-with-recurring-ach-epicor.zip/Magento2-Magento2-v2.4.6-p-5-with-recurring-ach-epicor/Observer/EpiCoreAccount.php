<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Observer;

use Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Customer\Model\CustomerRegistry;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class EpiCoreAccount
 * @package Ebizcharge\Ebizcharge\Observer\EpiCoreAccount
 */
class EpiCoreAccount implements ObserverInterface
{
    /**
     * Create order event name
     * @const ADMIN_CREATE_ORDER_EVENT
     */
    const ADMIN_CREATE_ORDER_EVENT = 'adminhtml_sales_order_create_process_data_before';

    /**
     * @var ErpAccount
     */
    private $erpAccount;

    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var CustomerRegistry
     */
    private $customerRegistry;

    /**
     * @param CustomerRegistry $customerRegistry
     * @param ErpAccount $erpAccount
     * @param TranApi $tranApi
     */
    public function __construct(
        CustomerRegistry $customerRegistry,
        ErpAccount $erpAccount,
        TranApi $tranApi
    )
    {
        $this->erpAccount = $erpAccount;
        $this->tranApi = $tranApi;
        $this->customerRegistry = $customerRegistry;
    }

    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        try {

            $eventName = $observer->getEvent()->getName();

            if ($eventName == self::ADMIN_CREATE_ORDER_EVENT) {
                $customerId = $observer->getEvent()->getSession()->getCustomerId();
                $customer = $this->customerRegistry->retrieve($customerId);
            } else {
                $customer = $observer->getEvent()->getCustomer();
            }

            $this->processErpCustomer($customer);

        } catch (\Exception $ex) {
            $this->tranApi->log(__METHOD__ . $ex->getMessage());
        }
    }

    /**
     * Process erp customer account
     * @param $customer
     * @return void
     */
    public function processErpCustomer($customer)
    {
        $customer = $this->customerRegistry->retrieve($customer->getId());

        if ($this->erpAccount->epiCorEnabled() && $customer->getEccErpaccountId() > 0) {

            $dataToUpdate = [
                'ec_cust_id' => $this->erpAccount->getErpAccountId($customer)
            ];


                $ebizCustomer = $this->getEbizchargeCustomer($customer);

                /** customer didn't exist on gateway too, add it ebizcharge */
                if ($ebizCustomer === null) {
                    $this->addCustomerToEbizcharge($customer);
                    // fetch customer to get token
                    $ebizCustomer = $this->getEbizchargeCustomer($customer);
                }

                $dataToUpdate['ec_cust_internalid'] = $ebizCustomer->CustomerInternalId;
                $dataToUpdate['ec_cust_token'] = $ebizCustomer->CustomerToken;

                $this->erpAccount->updateErpCustomer($customer, $dataToUpdate['ec_cust_token']);

            $this->updateCustomerEntity($customer->getId(), $dataToUpdate);

        } elseif (!$this->erpAccount->getErpAccountId($customer) && !$customer->getEccErpaccountId()) {

            try{
                $ebizCustomer = $this->tranApi->soapClient->GetCustomer(
                    array(
                        'securityToken' => $this->tranApi->getUeSecurityToken(),
                        'customerId' => $customer->getId()
                    ));

            } catch (\Exception $e) {
                $this->tranApi->log($e->getMessage());
                $ebizCustomer = null;
            }

            /** customer didn't exist on gateway too, add it ebizcharge */
            if ($ebizCustomer === null) {
                $this->addCustomerToEbizcharge($customer, $customer->getId());

                $ebizCustomer = $this->tranApi->soapClient->GetCustomer(
                    array(
                        'securityToken' => $this->tranApi->getUeSecurityToken(),
                        'customerId' => $customer->getId()
                    ));
            }

            if ($ebizCustomer && isset($ebizCustomer->GetCustomerResult)) {

                $dataToUpdate['ec_cust_id'] = $ebizCustomer->GetCustomerResult->CustomerId;
                $dataToUpdate['ec_cust_internalid'] = $ebizCustomer->GetCustomerResult->CustomerInternalId;
                $dataToUpdate['ec_cust_token'] = $ebizCustomer->GetCustomerResult->CustomerToken;

                $this->erpAccount->updateErpCustomer($customer, $dataToUpdate['ec_cust_token']);

                $this->updateCustomerEntity($customer->getId(), $dataToUpdate);
            }
        }
    }

    /**
     * Add customer to ebizcharge gateway
     * @param $customer
     * @return mixed
     */
    private function addCustomerToEbizcharge($customer, $customerId = null)
    {
        $customerResult = $this->tranApi->soapClient->AddCustomer(
            [
                'securityToken' => $this->tranApi->getUeSecurityToken(),
                'customer' => $this->getCustomerToAdd($customer, $customerId)
            ]
        );

        if (isset($customerResult->AddCustomerResult)) {
            return $customerResult->AddCustomerResult;
        }

        return null;
    }

    /**
     * Get formatted customer data to add on gateway
     * @param $customer
     * @return array
     */
    private function getCustomerToAdd($customer, $customerId = null): array
    {
        $mageCustomer = $customer->getData();

        return [
            'CustomerId' => $customerId ?: $this->erpAccount->getErpAccountId($customer),
            'FirstName' => $mageCustomer['firstname'],
            'LastName' => $mageCustomer['lastname'],
            'CompanyName' => $mageCustomer['firstname'],
            'Phone' => $mageCustomer['ec_cust_id'],
            'CellPhone' => $mageCustomer['ec_cust_id'],
            'Fax' => $mageCustomer['ec_cust_id'],
            'Email' => $mageCustomer['email'],
            'WebSite' => $mageCustomer['website_id'],
            'BillingAddress' => $customer->getDefaultBillingAddress() ? $this->getFormatedAddress($customer->getDefaultBillingAddress()) : '',
            'ShippingAddress' => $customer->getDefaultShippingAddress() ? $this->getFormatedAddress($customer->getDefaultShippingAddress()) : '',
            'SoftwareId' => $this->tranApi->software,
        ];
    }

    /**
     * Get formatted address for gateway
     * @param $address
     * @return array
     */
    private function getFormatedAddress($address): array
    {
        return [
            'FirstName' => $address->getData('firstname'),
            'LastName' => $address->getData('lastname'),
            'CompanyName' => $address->getData('company'),
            'Address1' => $address->getData(['street'][0]),
            'Address2' => '',
            'City' => $address->getData('city'),
            'State' => $address->getData('region'),
            'ZipCode' => $address->getData('postcode'),
            'Country' => $address->getData('country_id')
        ];
    }

    /**
     * Get customer from gateway
     * @param $customer
     * @return string|null
     */
    private function getEbizchargeCustomer($customer)
    {
        return $this->tranApi->getCustomer(
            $this->erpAccount->getErpAccountId($customer)
        );
    }

    /**
     * update magento customeer
     *
     * @param $entityId
     * @param $data
     * @return void
     */
    private function updateCustomerEntity($entityId, $data)
    {
        $updateQueryParameters = [
            'option' => 'update',
            'tableName' => 'customer_entity',
            'data' => $data,
            'where' => [
                'entity_id = ?' => $entityId,
            ]
        ];

        $this->tranApi->runUpdateQuery($updateQueryParameters);
    }
}
