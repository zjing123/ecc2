<?php
/**
 * Observe and upload invoice to EConnect automatically.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer;

use Magento\Framework\ObjectManager\ObjectManager;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Catalog\Model\ProductRepository;

ini_set("soap.wsdl_cache_enabled", "0");
ini_set('memory_limit', '1000M');
ini_set('max_execution_time', 300);


ini_set('max_input_time', 600);
ini_set('max_input_vars', 3000);
ini_set('post_max_size', '1000M');

class AddInvoice implements \Magento\Framework\Event\ObserverInterface
{
    protected $_logger;
    protected $_objectManager;
    protected $_orderFactory;
    protected $_checkoutSession;
    protected $_tran;
    protected $_token;
    protected $config;

    /**
     * @param \Psr\Log\LoggerInterface $loggerInterface
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param ObjectManager $objectManager
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Ebizcharge\Ebizcharge\Model\Token $token
     * @param \Ebizcharge\Ebizcharge\Model\Config $config
     */
    public function __construct(
        \Psr\Log\LoggerInterface                       $loggerInterface,
        \Magento\Checkout\Model\Session                $checkoutSession,
        \Magento\Sales\Model\OrderFactory              $orderFactory,
        \Magento\Framework\ObjectManager\ObjectManager $objectManager,
        // For TranAPI Config import
        \Ebizcharge\Ebizcharge\Model\TranApi           $tranApi,
        \Ebizcharge\Ebizcharge\Model\Token             $token,
        \Ebizcharge\Ebizcharge\Model\Config            $config
    )
    {
        $this->_logger = $loggerInterface;
        $this->_objectManager = $objectManager;
        $this->_orderFactory = $orderFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_tran = $tranApi;
        $this->_token = $token;
        $this->config = $config;
    }

    public function isAdmin()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $state = $objectManager->get('Magento\Framework\App\State');
        return ('adminhtml' === $state->getAreaCode());
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->_tran->log('Invoice Observer ' . __METHOD__);
        // Redirect if module or upload is disabled
        if ($this->config->isEbizchargeActive() == 0) {
            $this->_tran->log('EBizCharge module is inactive. Please activate before upload.');
            return;
        }
        if ($this->config->isEconnectUploadEnabled() == 0) {
            $this->_tran->log('EBizCharge Upload functionality is inactive. Please activate before upload.');
            return;
        }
        sleep(2);

        try {
            // transaction object start
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

            if ($this->isAdmin()) {
                $invoice = $observer->getEvent()->getInvoice();
                $currentOrderEntityId = $invoice->getOrderId();

                $order = $objectManager->create('\Magento\Sales\Model\Order')->load($currentOrderEntityId);
                $invoiceCollection[] = $invoice;

            } else {
                $orderIds = $observer->getEvent()->getOrderIds();
                $currentOrderEntityId = $orderIds[0] ?? null;
                if ($currentOrderEntityId) {
                    $order = $objectManager->create('\Magento\Sales\Model\Order')->load($currentOrderEntityId);
                    $invoiceCollection = $order->getInvoiceCollection();
                }
            }

            if (!empty($currentOrderEntityId)) {
                // Customer login action
                $customerSession = $objectManager->get('Magento\Customer\Model\Session');
                // Sync invoice Start
                if (($customerSession->isLoggedIn()) || $this->isAdmin()) {

                    if (!empty($invoiceCollection)) {
                        $objectManager->get('Ebizcharge\Ebizcharge\Model\Data')->processInvoices($order, $invoiceCollection);
                        return;

                    } else {
                        $this->_tran->log('Invoice collection not found!');
                    }
                }

            } else {
                $this->_tran->log('Invoice Order not found!');
            }

        } catch (Exception $e) {
            $this->_tran->log('Invoice #' . $invoice->getData('increment_id') . ' not added! ' . $e->getMessage());
        }
    }
}
