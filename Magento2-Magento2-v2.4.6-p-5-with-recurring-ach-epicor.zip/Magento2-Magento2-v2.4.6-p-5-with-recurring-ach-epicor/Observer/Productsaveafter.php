<?php
/**
 * Observe and upload order to EConnect automatically.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Observer;

ini_set("soap.wsdl_cache_enabled", "0");
ini_set('memory_limit', '1000M');
ini_set('max_execution_time', 300);
ini_set('max_input_time', 600);
ini_set('max_input_vars', 3000);
ini_set('post_max_size', '1000M');

class ProductSaveAfter implements \Magento\Framework\Event\ObserverInterface
{
    // For TranAPI Config import
    protected $_tran;
    protected $config;
    protected $_customerRepositoryInterface;

    /**
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Ebizcharge\Ebizcharge\Model\Config $config
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     */
    public function __construct(
        \Ebizcharge\Ebizcharge\Model\TranApi              $tranApi,
        \Ebizcharge\Ebizcharge\Model\Config               $config,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    )
    {
        // For TranAPI Config import
        $this->_tran = $tranApi;
        $this->config = $config;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->_tran->log('Product Save After Observer ' . __METHOD__);

        if ($this->config->isEbizchargeActive() == 0) {
            return;
        }
        if ($this->config->isRecurringEnabled() == 0) {
            return;
        }

        $item = $observer->getProduct();  // we will get product object here

        if (!empty($item)) {

            $productId = $item->getEntityId();

            /****** select recurring data ******/
            $selectQueryParametersRecurring = array(
                'option' => 'select',
                'tableName' => 'ebizcharge_recurring',
                'tableFields' => '*',
                'whereKey' => 'mage_item_id',
                'whereValue' => $productId,
                'whereKey2' => 'rec_status',
                'whereValue2' => 0
            );

            $recurringDataDb = $this->_tran->runSelectQueryMultipleInput($selectQueryParametersRecurring, 2);

            if (!empty($recurringDataDb)) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $dataClass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');

                foreach ($recurringDataDb as $recurring) {
                    try {

                        $endDate = date('Y-m-d', strtotime($recurring['eb_rec_end_date']));
                        $today = date('Y-m-d');
                        // update active and future recurring
                        if ($recurring['rec_status'] == 0 && strtotime($endDate) > strtotime($today)) {

                            /****** select customer group tier prices ******/
                            $tierPrice = $dataClass->getProductPriceWithTierGroup($productId, $recurring['mage_cust_id'], $recurring['qty_ordered']);
                            $itemPrice = $tierPrice['productPrice'];

                            $newAmount = number_format((float)trim($itemPrice * $recurring['qty_ordered']), 2, '.', '');

                            /****** update recurring on gateway ******/
                            $oldAmount = $recurring['amount'];

                            if ($oldAmount != $newAmount) {

                                $scheduleName = $productId . '-' . $recurring['mage_order_id'] . '-' . $recurring['mage_cust_id']
                                    . '-' . $recurring['eb_rec_frequency'] . '-' . $recurring['eb_rec_method_id'];

                                $receiptNote = '[' . $productId . '-' . $recurring['mage_item_name'] . '] recurring price updated.
                                                    Old Price: ' . $recurring . ' New Price: ' . $newAmount;

                                $recurringBilling = array(
                                    'Amount' => $newAmount,
                                    'Enabled' => true,
                                    'Start' => date('Y-m-d', strtotime($recurring['eb_rec_start_date'])),
                                    'Expire' => date('Y-m-d', strtotime($recurring['eb_rec_end_date'])),
                                    'Next' => date('Y-m-d', strtotime($recurring['eb_rec_end_date'])),
                                    'Schedule' => trim($recurring['eb_rec_frequency']),
                                    'ScheduleName' => trim($scheduleName),
                                    'ReceiptNote' => $receiptNote,
                                    'ReceiptTemplateName' => false,
                                    'SendCustomerReceipt' => true
                                );
                                $recurringObject = array(
                                    'securityToken' => $this->_tran->getUeSecurityToken(),
                                    'scheduledPaymentInternalId' => trim($recurring['eb_rec_scheduled_payment_internal_id']),
                                    'recurringBilling' => $recurringBilling
                                );

                                $modifyScheduled = $this->_tran->soapClient->ModifyScheduledRecurringPayment_RecurringBilling($recurringObject);

                                if (($modifyScheduled->ModifyScheduledRecurringPayment_RecurringBillingResult->Status == 'Success')) {
                                    /****** update pricing in recurring db ******/
                                    $updateQueryParameters = array(
                                        'option' => 'update',
                                        'tableName' => 'ebizcharge_recurring',
                                        'data' => array(
                                            'amount' => $newAmount
                                        ),
                                        'where' => array(
                                            'rec_id = ?' => $recurring['rec_id'],
                                            'mage_item_id = ?' => $recurring['mage_item_id']
                                        )
                                    );

                                    $this->_tran->runUpdateQuery($updateQueryParameters);

                                    $this->_tran->log('Recurring #' . $recurring['rec_id'] . ' price updated. Details: ' . $receiptNote);
                                }

                            } else {
                                $this->_tran->log('Recurring #' . $recurring['rec_id'] . ' not updated. There is no change in price.');
                            }
                        }

                    } catch (\Exception $e) {
                        $this->_tran->log('Exception: Recurring #' . $recurring['rec_id'] . ' not updated! ' . $e->getMessage());
                    }
                }

            } else {
                $this->_tran->log('There is no active recurring for item #' . $productId);
            }
        }
    }
}
