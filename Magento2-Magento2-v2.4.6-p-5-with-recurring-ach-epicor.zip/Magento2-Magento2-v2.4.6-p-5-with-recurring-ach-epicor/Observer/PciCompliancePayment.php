<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order\Payment;
use Ebizcharge\Ebizcharge\Model\Payment as EbizPayment;

/**
 * PCI compliance payment related info
 * Class PciCompliancePayment
 * @package Ebizcharge\Ebizcharge\Observer
 */
class PciCompliancePayment implements ObserverInterface
{
    /**
     * @inheritDoc
     */
    public function execute(Observer $observer)
    {
        /** @var Payment $payment */
        $payment = $observer->getEvent()->getPayment();

        if ($payment->getMethod() == EbizPayment::CODE) {

            if ($payment->getCcType() == EbizPayment::ACH) {
                $achRoute = $payment->getAdditionalInformation('ach_route') ?? '';
                $achRoute = substr_replace($achRoute, 'XXX', -3);
                $payment->setAdditionalInformation('ach_route', $achRoute);
            }
        }
        return $this;
    }
}
