let config = {
    map: {
        '*': {
            'ebizcharge-credit-card': 'Ebizcharge_Ebizcharge/js/ebizcharge-credit-card'
        }
    }
};
