require([
        'jquery',
        'Magento_Ui/js/modal/confirm'
    ],
    function ($, confirmation) {

        $(document).ready(function (){
            /** hide customer address tab while adding new customer */
            if (window.location.pathname.indexOf('customer/index/new') > 1) {
                $("<style>")
                    .prop("type", "text/css")
                    .html("\
                #tab_address {\
                display: none;\
                }")
                    .appendTo("head");
            }
        });

        $(document).on('click', '#deleteCard', function (e) {

            let deleteUrl = $(this).attr('href');

            e.preventDefault();

            confirmation({
                title: 'Delete this record.',
                content: 'Are you sure you wish to delete the selected payment method?',
                actions: {
                    confirm: function (e) {
                        $('body').trigger('processStart');
                        window.location.replace(deleteUrl);
                    },
                    cancel: function () {
                        return false;
                    }
                },
                buttons: [{
                    text: $.mage.__('Cancel'),
                    class: 'action-secondary action-dismiss',
                    click: function (event) {
                        this.closeModal(event);
                    }
                }, {
                    text: $.mage.__('Yes, delete.'),
                    class: 'action secondary',
                    click: function (event) {
                        this.closeModal(event, true);
                    }
                }]
            });
        });
    });
