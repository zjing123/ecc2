define(
    [
        'jquery',
    ],
    function ($) {

        return function (customData) {

            $(document).ready(function () {

                $('#payment_cc_number_new').change(function () {

                    let cc = jQuery(this).val();
                    cc = cc.replaceAll("\\D", "");
                    let pattern = new RegExp('[ ]+', 'g');
                    cc = cc.replace(pattern, '');
                    $(this).val(cc);

                    if (!cc || !cc.length) return undefined;
                    let ccType = '';
                    let firstNumber = cc.charAt(0);
                    if (firstNumber == '4') ccType = 'VI';
                    if (firstNumber == '5') ccType = 'MC';
                    if (firstNumber == '3') ccType = 'AE';
                    if (firstNumber == '6') ccType = 'DI';

                    $('#payment_cc_type_new').val(ccType);
                    if (ccType != '') {
                        $('#payment_cc_type_new option:not(:selected)').prop('disabled', true);
                    }
                });

                if (customData.requestCC) {
                    onlyIntegerInput('payment_cc_cid_new');
                }

                if (customData.action != 'edit') {
                    onlyIntegerInput('payment_cc_number_new');
                }

                $(document).on("click", "#save", function (e) {
                    $('body').trigger('processStart');
                    $('#admin-customer-card-form').submit();
                });

                function onlyIntegerInput(inputId) {
                    $("#" + inputId).bind("keypress", function (e) {
                        let keyCode = e.which ? e.which : e.keyCode
                        if (!(keyCode >= 48 && keyCode <= 57)) {
                            return false;
                        }
                    });
                }

            });
        }
    });
