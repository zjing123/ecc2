<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Setup\Patch\Data;

use Ebizcharge\Ebizcharge\Setup\Patch\Schema\SimpleRecurring as SimpleRecurringColumn;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Insert mage_order_id data to simple_recurring
 *
 * Class SimpleRecurring
 */
class SimpleRecurring implements DataPatchInterface
{

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * @inheritDoc
     */
    public function apply()
    {
        $this->moduleDataSetup->startSetup();

        $recurringTable = $this->moduleDataSetup->getTable('ebizcharge_recurring');

        $mergedRecurrings = "SELECT rec_t1.rec_id FROM " . $recurringTable . " AS rec_t1
        INNER JOIN " . $recurringTable . " AS rec_t2
        ON rec_t1.mage_order_id = rec_t2.mage_order_id
        AND rec_t1.shipping_address_id = rec_t2.shipping_address_id
        AND rec_t1.shipping_method = rec_t2.shipping_method
        AND rec_t1.rec_id != rec_t2.rec_id
        AND rec_t1.mage_order_id != 0
        GROUP BY rec_t1.rec_id";

        $recurringIds = $this->moduleDataSetup->getConnection()->query($mergedRecurrings);

        $recurringIds = implode(",", array_column($recurringIds->fetchAll(), 'rec_id'));

        if ($recurringIds) {
            /** add mage_order_id column data to simple_recurring */
            $queryToUpdate = "update " . $recurringTable . " set simple_recurring = IF(mage_order_id, mage_order_id, 0) where rec_id in(" . $recurringIds . ")";

            $this->moduleDataSetup->getConnection()->query($queryToUpdate);
        }

        $this->moduleDataSetup->endSetup();
    }

    /**
     * @inheritDoc
     */
    public static function getDependencies()
    {
        return [
            SimpleRecurringColumn::class,
        ];
    }

    /**
     * @inheritDoc
     */
    public function getAliases()
    {
       return [];
    }

}
