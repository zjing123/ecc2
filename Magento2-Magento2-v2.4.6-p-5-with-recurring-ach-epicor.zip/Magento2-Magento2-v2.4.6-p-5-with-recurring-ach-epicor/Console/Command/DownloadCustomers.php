<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 10/15/21
 * Time: 3:35 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Console\Command;

use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface as CustomerRepositoryInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\AddressFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Directory\Model\Region;
use Magento\Framework\App\Area;
use Magento\Framework\App\ResourceConnection as ResourceConnection;
use Magento\Framework\App\State;
use Magento\Framework\Console\Cli;
use Magento\Framework\File\Csv as CsvProcesser;
use Magento\Framework\Model\AbstractModel;
use Magento\Store\Model\StoreManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\ConsoleOutput;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Download customers from ebizcharge gateway
 * @usage bin/magento download:customers --file=my-file-name.csv --sync=true
 *
 * Class DownloadCustomers
 * @package Ebizcharge\Ebizcharge\Console\Command
 */
class DownloadCustomers extends Command
{
    const NAME = 'file';
    const SYNC = 'sync';
    const IMPORT = 'import';

    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var Region
     */
    private $region;

    /**
     * @var State
     */
    private $appState;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var CsvProcesser
     */
    private $csv;

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    /**
     * @var int
     */
    private $alreadyExistCounter = 0;

    /**
     * @var int
     */
    private $newCustomerCounter = 0;

    /**
     * @var CustomerFactory
     */
    private $customerFactory;

    /**
     * Objects which will be involved to save customer transaction
     *
     * @var array
     */
    private $objects = [];

    /**
     * @var AddressFactory
     */
    private $addressFactory;

    /**
     * @var ConsoleOutput
     */
    private $output;

    /**
     * @param AddressFactory $addressFactory
     * @param CustomerFactory $customerFactory
     * @param ResourceConnection $resourceConnection
     * @param CsvProcesser $csv
     * @param CustomerRepositoryInterface $customerRepository
     * @param State $appState
     * @param Region $region
     * @param StoreManagerInterface $storeManager
     * @param ConsoleOutput $output
     * @param TranApi $tranApi
     * @param string|null $name
     */
    public function __construct(
        AddressFactory $addressFactory,
        CustomerFactory $customerFactory,
        ResourceConnection $resourceConnection,
        CsvProcesser $csv,
        CustomerRepositoryInterface $customerRepository,
        State $appState,
        Region $region,
        StoreManagerInterface $storeManager,
        ConsoleOutput $output,
        TranApi $tranApi,
        string $name = null
    )
    {
        parent::__construct($name);
        $this->tranApi = $tranApi;
        $this->storeManager = $storeManager;
        $this->region = $region;
        $this->appState = $appState;
        $this->customerRepository = $customerRepository;
        $this->csv = $csv;
        $this->resourceConnection = $resourceConnection;
        $this->customerFactory = $customerFactory;
        $this->addressFactory = $addressFactory;
        $this->output = $output;
    }

    /**
     * Define the import customers command
     */
    protected function configure()
    {
        $options = [
            new InputOption(
                self::NAME,
                null,
                InputOption::VALUE_REQUIRED,
                'Name of the CSV file with file type required'
            ),
            new InputOption(
                self::SYNC,
                null,
                InputOption::VALUE_OPTIONAL,
                'Sync customers to ebizcharge gateway.'
            ),
            new InputOption(
                self::IMPORT,
                null,
                InputOption::VALUE_OPTIONAL,
                'Import customers to magento.'
            )
        ];
        $this->setName('download:customers')
            ->setDescription('Import customers to magento from CSV file.')
            ->setDefinition($options);

        parent::configure();
    }

    /**
     * Executes the download customers command.
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->appState->setAreaCode(Area::AREA_FRONTEND);

        $sync = $input->getOption(self::SYNC) == true;
        $import = $input->getOption(self::IMPORT) == true;

        if (!$sync) {
            $import = true;
        }
        $syncCount = !$import;

        try {

            if ($fileName = $input->getOption(self::NAME)) {

                try {
                    $customersToImport = $this->getCustomersFromCSVFile($fileName);

                    if (!empty($customersToImport)) {

                        $output->writeln('<info>Customer import process started.</info>');

                        foreach ($customersToImport as $customer) {

                            $customer['StoredValueID'] = $customer['StoredValueID'] ?? 0;

                            $message = $this->processCustomer($customer);

                            if ($message) {
                                $this->tranApi->log($message);
                                $output->writeln($message);
                            }
                        }
                    }
                } catch (\Exception $e) {
                    $output->writeln('<error>' . $e->getMessage() . '</error>');
                    return Cli::RETURN_FAILURE;
                }
            }
        } catch (\Exception $e) {
            $output->writeln("<error>An error occurred while processing your file: " . $e->getMessage() . '</error>');
            return Cli::RETURN_FAILURE;
        }

        $output->writeln('<info>Customer import process has been completed.</info>');

        if ($this->alreadyExistCounter > 0) {
            $output->writeln('<info>' . $this->alreadyExistCounter . ' customers was already exist and skipped. </info>');
        }

        $output->writeln('<info>' . $this->newCustomerCounter . ' new customers added to Magento. </info>');

        return Cli::RETURN_SUCCESS;
    }

    /**
     * Get customers to import from CSV file
     *
     * @param string $fileName
     * @return array
     * @throws \Exception
     */
    public function getCustomersFromCSVFile(string $fileName): array
    {
        $newCustomerArray = [];
        $customersArray = $this->csv->getData($fileName);

        $header = $this->getCsvHeader(array_shift($customersArray));

        foreach ($customersArray as $customer) {
            $newCustomerArray[] = array_combine($header, $customer);
        }

        return $newCustomerArray;
    }


    /**
     * @param array $customer
     * @return string
     */
    public function processCustomer(array $customer)
    {
        /**
         * check whether the email address is already registered or not
         */
        if ($customerId = $this->customerAlreadyExist($customer)) {
            $this->alreadyExistCounter++;
            return 'Customer (' . $customerId . ') with email ' . $customer['Email'] . ' is already registered.';
        }

        // Live ID's
        $liveCustId = $customer['CustomerID'];
        $getEbizCustomerNumber = $customer['CustomerNumber'] ?? '';

        if ((empty($getEbizCustomerNumber)) ||
            (empty($customer['FirstName'])) ||
            (empty($customer['LastName']))) {
            return 'Customer (' . $liveCustId . ') Econnect Customer Token/Firstname/Lastname is empty.';
        }

        try {
            return $this->saveNewCustomer($customer);
        } catch (\Exception $ex) {
            return $ex->getMessage();
        }

    }

    /**
     * Get region id for customer address
     *
     * @param $regionCode
     * @param $countryCode
     * @return array|mixed|null
     */
    private function getRegionIdFinal($regionCode, $countryCode)
    {
        if (empty($regionCode)) {
            $regionCode = 'CA';
        } else {
            $regionCode = substr($regionCode, 0, 2);
            $regionCode = strtoupper($regionCode);
        }
        if (empty($countryCode)) {
            $countryCode = 'US';
        } else {
            $countryCode = substr($countryCode, 0, 2);
            $countryCode = strtoupper($countryCode);
        }

        return $this->region->loadByCode($regionCode, $countryCode)->getData();
    }

    /**
     * This method add new customer to magento
     *
     * @param $customer
     * @return string
     */
    public function saveNewCustomer($customer)
    {
        $newCustomer = $this->customerFactory->create();

        $newCustomer->setWebsiteId($this->getStoreWebsiteId($customer['StoredValueID']));
        $newCustomer->setEmail($customer['Email']);
        $newCustomer->setFirstname($customer['FirstName']);
        $newCustomer->setLastname($customer['LastName']);
        $newCustomer->setConfirmation(null);
        $newCustomer->setPassword($customer['Email']);

        $savedCustomer = $this->beginSave($newCustomer);

        if ($savedCustomer == null) {
            return null;
        }

        try {
            $this->saveCustomerAddress($savedCustomer, $customer);

        } catch (\Exception $e) {
            return $this->rollbackTransaction($e->getMessage());
        }

        try {
            $success = $this->syncCustomerToEbiz($customer, $savedCustomer->getId());

            if ($success) {
                return 'Customer ' . $savedCustomer->getId() . ' with email ' . $customer['Email'] . ' is successfully created.';
            }

        } catch (\Exception $e) {
            return $this->rollbackTransaction($e->getMessage());
        }

    }

    /**
     * @param $tableName
     * @param $mageCustomerId
     * @param $ebzCustomerId
     * @return void|null
     */
    public function runInsertQuery($tableName, $mageCustomerId, $ebzCustomerId)
    {
        $connection = $this->resourceConnection->getConnection();
        $connection->beginTransaction();
        try {
            $connection = $this->resourceConnection->getConnection();
            $tableNamef = $this->resourceConnection->getTableName($tableName);
            $sql = "INSERT INTO " . $tableNamef . " (token_id, mage_cust_id, ebzc_cust_id) VALUES ('', $mageCustomerId, '$ebzCustomerId')";
            $connection->query($sql);
            $this->commitTransaction();
            $connection->commit();
        } catch (\Exception $e) {
            $connection->rollBack();
            return $this->rollbackTransaction($e->getMessage());
        }
    }

    /**
     * Get store website id
     *
     * @param int $storeId
     */
    private function getStoreWebsiteId($storeId): ?int
    {
        try {
            return (int)$this->storeManager->getStore($storeId)->getWebsiteId();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Weather customer already exist in magento
     *
     * @param array $customer
     * @return int|null
     */
    private function customerAlreadyExist(array $customer): ?int
    {
        try {
            return (int)$this->customerRepository->get($customer['Email'],
                $this->getStoreWebsiteId($customer['StoredValueID']))->getId();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get header of CSV file with formatting for associative array indexes
     *
     * @param array|string $csvFirstRow
     */
    private function getCsvHeader($csvFirstRow)
    {

        if (!is_array($csvFirstRow)) {
            $csvFirstRow = $csvFirstRow ?? '';
            return str_replace(' ', '', trim($csvFirstRow));
        }
        $newHeaderArray = [];
        foreach ($csvFirstRow as $key => $header) {
            $newHeaderArray[$key] = $this->getCsvHeader($header);
        }
        return $newHeaderArray;
    }

    /**
     * Save customer address with repository
     *
     * @param $savedCustomer
     * @param $customer
     * @return void
     */
    private function saveCustomerAddress($savedCustomer, $customer)
    {
        $country_id = $customer['Country'] ?: 'US';
        $Phone = $customer['Phone'] ?: '0123456789';

        $regionData = $this->getRegionIdFinal($customer['State'], $country_id);

        $regionData['region_id'] = $regionData['region_id'] ?: '12';

        $address = array(
            'customer_address_id' => '',
            'prefix' => '',
            'firstname' => $customer['FirstName'],
            'middlename' => '',
            'lastname' => $customer['LastName'],
            'suffix' => '',
            'company' => $customer['Company'] ?? 'N/A',
            'street' => array(
                '0' => $customer['Address'], // this is mandatory
                '1' => $customer['Address2'] // this is optional
            ),
            'city' => $customer['City'],
            'country_id' => $country_id, // two letters country code
            'region' => $customer['State'], // can be empty '' if no region
            'region_id' => $regionData['region_id'], // can be empty '' if no region_id
            //'region_id' => '', // can be empty '' if no region_id
            'postcode' => $customer['Zip'] ?? '',
            'telephone' => $Phone,
            'fax' => '',
            'save_in_address_book' => 1
        );

        $countryId = $address['country_id'] ?: 'US';
        $postcode = $address['postcode'] ?: '92618';
        $city = $address['city'] ?: 'irvine';
        $street = $address['street'] ?: array(0 => '20, pacifica');
        $regionId = $address['region_id'] ?: '';

        $regionName = null;

        $updateAddress = $this->addressFactory->create();

        $updateAddress->setFirstname($address['firstname'])
            ->setLastname($address['lastname'])
            ->setCountryId($countryId)
            ->setRegionId($regionId)
            ->setRegion($regionName)
            ->setCity($city)
            ->setPostcode($postcode)
            ->setCustomerId($savedCustomer->getId())
            ->setStreet($street)
            ->setIsDefaultBilling('1')
            ->setIsDefaultShipping('1')
            ->setTelephone($address['telephone']);

        //add address object for translation
        $this->beginSave($updateAddress);
    }

    /**
     * Get Customer Data for Add New Customer
     * @param array $customer
     * @return array
     */
    private function getCustomerData(array $customer): array
    {
        return [
            'CustomerId' => $customer['CustomerID'],
            'FirstName' => $customer['FirstName'],
            'LastName' => $customer['LastName'],
            'CompanyName' => $customer['Company'] ?? 'N/A',
            'Phone' => $customer['Phone'] ?: '0123456789',
            'CellPhone' => $customer['Phone'] ?: '0123456789',
            'Fax' => $customer['Fax'],
            'Email' => $customer['Email'],
            'WebSite' => $this->getStoreWebsiteId($customer['StoredValueID']),
            'ShippingAddress' => $this->getCustomerAddress($customer),
            'BillingAddress' => $this->getCustomerAddress($customer),
            'SoftwareId' => 'Magento2',
        ];
    }

    /**
     * @param array $customer
     * @param $entityId
     * @return string
     */
    private function syncCustomerToEbiz(array $customer, $entityId)
    {
        try {
            // search customer using customer id and email
            if ($ebizCustomer = $this->searchCustomer($customer['CustomerID'], $customer['Email'])) {
                // already exist
                $this->tranApi->log('Customer found on the gateway customerId: ' . $customer['CustomerID'] .', Email: '. $customer['Email']);

                $customerToken = $ebizCustomer->CustomerToken;

            } else {

                $customerResult = $this->tranApi->soapClient->AddCustomer(
                    [
                        'securityToken' => $this->tranApi->getUeSecurityToken(),
                        'customer' => $this->getCustomerData($customer)
                    ]
                );

                $ebizCustomer = $customerResult->AddCustomerResult;

                if ($ebizCustomer->Status == 'Success') {
                    $message = 'EbizCustomer ' . $customer['CustomerID'] . ' with email ' . $customer['Email'] . ' is successfully added to gateway.';
                    $this->tranApi->log($message);
                } else {
                    $message = 'EbizCustomer:' . $ebizCustomer->Error . '.... CustomerID: ' . $customer['CustomerID']  . ' already exist with different email on the gateway.';
                    $this->tranApi->log($message);
                }
                // get customer token - can't be used as defined in the sheet
                if($ebizCustomer = $this->searchCustomer($customer['CustomerID'], $customer['Email'])){
                    $customerToken = $ebizCustomer->CustomerToken;
                } else {
                    $message = 'CustomerID ' . $customer['CustomerID'] . ' with email ' . $customer['Email'] . ' not found on the gateway.';
                    $this->tranApi->log($message);
                }
            }

            // update mapping fields
            if ($ebizCustomer && !empty($customerToken)) {

                $this->tranApi->log('Updating token info in Magento for customer Email: '. $customer['Email']);

                $this->tranApi->runUpdateQueryCustomer(
                    'customer_entity',
                    'cust',
                    1,
                    $ebizCustomer->CustomerInternalId,
                    $ebizCustomer->CustomerId,
                    $customerToken,
                    $entityId
                );

                $this->runInsertQuery('ebizcharge_token', $entityId, $customerToken);

            } else {
                $msg = 'Record transaction not committed and Token not updated in Magento for customer email: ' . $customer['Email'];
                $this->tranApi->log($msg);
               return $this->rollbackTransaction($msg);
            }

        } catch (\Exception $e) {
            $this->tranApi->log($e->getMessage());
            return $this->rollbackTransaction($e->getMessage());
        }
        return true;
    }

    public function searchCustomer($customerId, $email)
    {
        try {
            $customerFilter = array(
                'FieldName' => 'CustomerId',
                'ComparisonOperator' => 'eq',
                'FieldValue' => $customerId
            );

            $emailFilter = array(
                'FieldName' => 'Email',
                'ComparisonOperator' => 'eq',
                'FieldValue' => $email
            );

            $filters['SearchFilter'][0] = $customerFilter;
            $filters['SearchFilter'][1] = $emailFilter;

            $params = [
                'securityToken' => $this->tranApi->getUeSecurityToken(),
                'filters' => $filters,
                'includeCustomerToken' => 1,
                'includePaymentMethodProfiles' => 0,
                'countOnly' => 0,
                'start' => 0,
                'limit' => 1
            ];

            $api = $this->tranApi->soapClient->SearchCustomerList($params);

            if (isset($api->SearchCustomerListResult->CustomerList->Customer)) {
                return $api->SearchCustomerListResult->CustomerList->Customer;
            }

        } catch (\Exception $ex) {
            $this->tranApi->log(__METHOD__ . ' Error in search customers ' . $ex->getMessage());
            return null;
        }

        return null;
    }

    /**
     * New addrerss for add customer
     * @param array $customer
     * @return array
     */
    private function getCustomerAddress(array $customer): array
    {
        return array(
            'FirstName' => $customer['FirstName'],
            'LastName' => $customer['LastName'],
            'Company' => $customer['Company'] ?? 'N/A',
            'Address1' => $customer['Address'],
            'Address2' => $customer['Address2'],
            'City' => $customer['City'],
            'State' => $customer['State'],
            'ZipCode' => $customer['Zip'],
            'Country' => $customer['Country'],
            'Phone' => $customer['Phone'],
            'Fax' => $customer['Fax'],
            'Email' => $customer['Email']
        );
    }

    /**
     * Adding object for using in transaction
     *
     * @param AbstractModel $object
     * @return AbstractModel|null
     */
    private function beginSave(AbstractModel $object)
    {
        $this->objects[] = $object;

        try {
            $object->getResource()->beginTransaction();
            return $object->save();

        } catch (\Exception $e) {
            $this->tranApi->log($e->getMessage());
            $this->rollbackTransaction($e->getMessage());
        }
        return null;
    }

    /**
     * Rollback customer objects
     *
     * @return void|null
     */
    private function rollbackTransaction($errorMessage = false)
    {
        foreach ($this->objects as $object) {
            $object->getResource()->rollBack();
        }
        $this->objects = [];
        if ($errorMessage) {
            $this->output->writeln('Customer save reverted. Exception: ' . $errorMessage);
        }
        return null;
    }

    /**
     * Commit transaction for all customer resources
     *
     * @return $this
     */
    private function commitTransaction()
    {
        foreach ($this->objects as $object) {
            $object->getResource()->commit();
        }
        $this->newCustomerCounter++;
        $this->objects = [];
        return $this;
    }
}

