<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * Date: 8/16/21
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Symfony\Component\Console\Input\InputOption;
use \Magento\Framework\App\State;

/**
 * Import subscriptions with CLI command from CSV file
 *
 * Class SubscriptionImport
 * @package Ebizcharge\Ebizcharge\Console\Command
 */
class SubscriptionImport extends Command
{
    const NAME = 'file';

    /**
     * @var Data
     */
    private $ebizData;

    /**
     * @var TranApi
     */
    private $tranApi;
    protected $appState;

    public function __construct(TranApi $tranApi, State $state)
    {
        parent::__construct('subscription:import');

        $this->tranApi = $tranApi;
        $this->appState = $state;
    }

    protected function configure()
    {
        $options = [
            new InputOption(
                self::NAME,
                null,
                InputOption::VALUE_REQUIRED,
                'Name of the CSV file with file type required'
            )
        ];

        $this->setName('subscription:import')
            ->setDescription('Import subscriptions with from CSV file')
            ->setDefinition($options);

        parent::configure();
    }

    /**
     * Executes the current command.
     *
     * This method is not abstract because you can use this class
     * as a concrete class. In this case, instead of defining the
     * execute() method, you set the code to execute by passing
     * a Closure to the setCode() method.
     *
     * @see setCode()
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_FRONTEND);

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->ebizData = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');

        try {
            if ($fileName = $input->getOption(self::NAME)) {

                $dataToImport = $this->getDataFromCsvFile($fileName);

                if (is_array($dataToImport) && !empty($dataToImport)) {

                    foreach ($dataToImport as $subscription) {
                        $message = $this->addSubscription($subscription);
                        $output->writeln($message);
                    }
                }

            }
        } catch (\Exception $e) {
            echo "An error occurred while processing your file: " . $e->getMessage();
        }
        return $this;
    }

    private function getDataFromCsvFile($fileName)
    {
        if (($input_handle = fopen($fileName, "r")) !== false) {

            $csv_in = array_map('str_getcsv', file($fileName));
            array_walk($csv_in, function (&$a) use ($csv_in) {
                $a = array_combine($csv_in[0], $a);
            });
            array_shift($csv_in); // remove column header
        }
        fclose($input_handle);
        return $csv_in;
    }

    private function addSubscription($csv)
    {
        $customerId = $csv['mage_cust_id'] ?? '';

        $customerInternalId = $this->ebizData->getMappedAndAddCustomer($customerId, true);
        $customerId = $this->ebizData->getMappedAndAddCustomer($customerId);

        $ebizCustomerId = $this->tranApi->getCustomerToken($customerId);

        if (!empty($ebizCustomerId)) {
            try {
                $paymentMethods = $this->tranApi->getCustomerPaymentMethods($ebizCustomerId);

                foreach ($paymentMethods as $paymentMethod) {
                    $paymentMethodId = $paymentMethod->MethodID;
                    $paymentMethodName = $paymentMethod->MethodName;
                }
            } catch (\Exception $ex) {
                return 'Exception: ' . $ex->getMessage();
            }
        } else {
            return 'Customer ' . $ebizCustomerId . ' not found';
        }

        if (!empty($paymentMethodId) && !empty($customerInternalId)) {

            $ueSecurityToken = $this->tranApi->getUeSecurityToken();

            try {
                $shippingMethod = $csv['shipping_method'];
                $productId = $csv['mage_item_id'];
                $productPrice = $this->ebizData->getProductPriceById($productId);
                $productName = $this->ebizData->getProductNameById($productId);
                $amountGross = ($productPrice * $csv['qty_ordered']);
                $amount = number_format((float)$amountGross, 2, '.', '');

                $schedule = strtolower(trim($csv['eb_rec_frequency'] ?? ''));
                $recIndefinitely = isset($csv['rec_indefinitely']) ? 1 : 0;
                $qty = $csv['qty_ordered'];
                $start = $csv['eb_rec_start_date'] ?? '';
                $expire = $csv['eb_rec_end_date'] ?? '';
                $scheduleName = $productId . '-' . $customerId . '-' . $schedule . '-' . $paymentMethodId;

                if (empty($qty)) {
                    $qty = 1;
                }

                if (!empty($start)) {
                    $start = date("Y-m-d", strtotime($start));
                }

                if ($recIndefinitely == 1) {
                    $expire = date('Y-m-d', strtotime('+10 years'));
                } else {
                    $recIndefinitely = 0;

                    if (!empty($expire)) {
                        $expire = date("Y-m-d", strtotime($expire));
                    } else {
                        $expire = date('Y-m-d', strtotime('+10 years'));
                    }
                }

                $recurringBilling = array(
                    'Amount' => $amount,
                    'Enabled' => true,
                    'Start' => $start,
                    'Expire' => $expire,
                    'Next' => $expire,
                    'Schedule' => $schedule,
                    'ScheduleName' => $scheduleName,
                    'ReceiptNote' => 'Item [' . $productId . '-' . $productName . '] recurring payment added.',
                    'ReceiptTemplateName' => false,
                    'SendCustomerReceipt' => true
                );

                $addRecurrParameters = array(
                    'securityToken' => $ueSecurityToken,
                    'customerInternalId' => $customerInternalId,
                    'paymentMethodProfileId' => $paymentMethodId,
                    'recurringBilling' => $recurringBilling
                );

                $transaction = $this->tranApi->soapClient->ScheduleRecurringPayment($addRecurrParameters);
                $scheduledPaymentInternalId = $transaction->ScheduleRecurringPaymentResult;

                if (!empty($scheduledPaymentInternalId)) {
                    $this->tranApi->log('Recurring Payment added for Item #[' . $productId . ']-' . $scheduledPaymentInternalId);

                    $recurringDates = $this->tranApi->getRecurringScheduledDates($scheduledPaymentInternalId);
                    $recurringDatesSerialize = serialize($recurringDates);
                    $ebzRecurringTotal = count($recurringDates);

                    $insertQueryParameters = array(
                        'option' => 'insert',
                        'tableName' => 'ebizcharge_recurring',
                        'data' => array(
                            'rec_status' => 0,
                            'rec_indefinitely' => $recIndefinitely,
                            'mage_cust_id' => trim($csv['mage_cust_id'] ?? ''),
                            'mage_order_id' => '0',
                            'mage_item_id' => $productId,
                            'mage_parent_item_id' => $productId,
                            'mage_item_name' => $productName,
                            'qty_ordered' => $qty,
                            'eb_rec_start_date' => $start,
                            'eb_rec_end_date' => $expire,
                            'eb_rec_frequency' => $schedule,
                            'eb_rec_method_id' => $paymentMethodId,
                            'eb_rec_scheduled_payment_internal_id' => $scheduledPaymentInternalId,
                            'eb_rec_total' => $ebzRecurringTotal,
                            'eb_rec_processed' => 0,
                            'eb_rec_next' => $this->tranApi->getNextRecurringDate($recurringDates),
                            'eb_rec_remaining' => $ebzRecurringTotal,
                            'eb_rec_due_dates' => $recurringDatesSerialize,
                            'billing_address_id' => $csv['addressBill'],
                            'shipping_address_id' => $csv['addressShip'],
                            'amount' => $amount,
                            'payment_method_name' => $paymentMethodName,
                            'shipping_method' => $shippingMethod
                        )
                    );

                    $recurringId = $this->tranApi->runInsertQuery($insertQueryParameters);

                    $this->tranApi->insertScheduleDates($recurringId, $recurringDates);

                    return 'Subscription successfully saved. ID: ' . $recurringId;
                } else {
                    return 'Unable to save subscription.';
                }

            } catch (\Exception $ex) {
                return 'Exception: ' . $ex->getMessage();
            }
        } else {
            return 'Unable to find payment methodID.';
        }
    }

}
