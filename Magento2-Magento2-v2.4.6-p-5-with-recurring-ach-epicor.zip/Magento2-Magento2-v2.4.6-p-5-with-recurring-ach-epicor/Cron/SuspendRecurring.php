<?php

namespace Ebizcharge\Ebizcharge\Cron;

class SuspendRecurring
{   
    public function __construct(
		\Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
	 	\Ebizcharge\Ebizcharge\Model\Token $token,
	 	\Ebizcharge\Ebizcharge\Model\Config $config
	)
    {
		$this->_tran = $tranApi;
		$this->_token = $token;
		$this->config = $config;
    }
    public function execute() 
	{ 
		$this->_tran->cronlog('CreateOrder Cron has been run successfully. The time is ' . date("Y-m-d h:i:sa"));
		$objectManager = $this->config->getObjectManagerInstance();
        $dataclass = $objectManager->get('Ebizcharge\Ebizcharge\Block\Admin\RecurringsAdmin');
		// As per recent(30/05/21) discussion with Frank, we don't need suspend recurring
        //$value = $dataclass->checkTransactionStatus();
    }
}