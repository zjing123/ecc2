<?php

namespace Ebizcharge\Ebizcharge\Cron;

class CheckItemStock
{   
    public function __construct(
		\Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
	 	\Ebizcharge\Ebizcharge\Model\Token $token,
	 	\Ebizcharge\Ebizcharge\Model\Config $config
	)
    {
		$this->_tran = $tranApi;
		$this->_token = $token;
		$this->config = $config;
    }
    public function execute() 
	{
		$this->_tran->cronlog('CheckItemStock Cron has been started. The time is ' . date("Y-m-d h:i:sa"));
		$objectManager = $this->config->getObjectManagerInstance();
        $dataclass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
        $value = $dataclass->checkItemsStock();

        $this->_tran->cronlog('CheckItemStock Cron has been completed. The time is ' . date("Y-m-d h:i:sa"));
    }
}
