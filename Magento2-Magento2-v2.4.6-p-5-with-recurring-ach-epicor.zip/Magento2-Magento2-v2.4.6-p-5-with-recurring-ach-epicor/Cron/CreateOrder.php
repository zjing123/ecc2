<?php

namespace Ebizcharge\Ebizcharge\Cron;

use Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings\CreateOrderAction;
use Ebizcharge\Ebizcharge\Model\Config;
use Ebizcharge\Ebizcharge\Model\TranApi;

/**
 * This cron creates orders
 *
 * Class CreateOrder
 * @package Ebizcharge\Ebizcharge\Cron
 */
class CreateOrder
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var CreateOrderAction
     */
    private $createOrderAction;

    /**
     * @var TranApi
     */
    private $tranApi;

    public function __construct(
        Config $config,
        CreateOrderAction $createOrderAction,
        TranApi $tranApi
    )
    {
        $this->config = $config;
        $this->createOrderAction = $createOrderAction;
        $this->tranApi = $tranApi;
    }

    public function execute()
    {
        if ($this->config->isEbizchargeActive() == 0 || $this->config->isRecurringEnabled() == 0) {
            return true;
        }

        $this->tranApi->cronlog('Cron: CreateOrder start. The time is ' . date("Y-m-d h:i:sa"));



        $startDate = date('Y-m-d');
        $this->createOrderAction->checkRecurringOrders($startDate);

        $this->tranApi->cronlog('------------------Cron: end create orders---------------');

        return true;
    }
}
