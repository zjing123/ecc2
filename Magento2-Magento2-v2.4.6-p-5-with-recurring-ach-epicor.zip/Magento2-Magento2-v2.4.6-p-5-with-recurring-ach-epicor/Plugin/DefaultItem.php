<?php

namespace Ebizcharge\Ebizcharge\Plugin;

use Magento\Quote\Model\Quote\Item;

class DefaultItem
{
    protected $tranApi;
    protected $config;
    protected $_tran;

    /**
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Ebizcharge\Ebizcharge\Model\Config $config
     */
    public function __construct(
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Ebizcharge\Ebizcharge\Model\Config  $config
    )
    {
        $this->_tran = $tranApi;
        $this->config = $config;
    }

    public function aroundGetItemData($subject, \Closure $proceed, Item $item)
    {
        $data = $proceed($item);
        $productData = $this->getItemSubscriptionDetails($item);
        return array_merge($data, $productData);
    }

    /**
     * Get subscription data from quotation
     *
     * @return array
     */
    public function getSubscribedQuoteItemsDatadb($quote_custom_options_id, $quote_product_id)
    {
        $selectQueryParameters = array(
            'option' => 'select',
            'tableName' => 'quote_item_option',
            'tableFields' => '*',
            'whereKey' => 'item_id',
            'whereValue' => $quote_custom_options_id,
            'whereKey2' => 'product_id',
            'whereValue2' => $quote_product_id
        );

        $recurringDataEntries = $this->_tran->runSelectQueryTwoFields($selectQueryParameters);
        return $recurringDataEntries;
    }

    /**
     * @param $item
     * @return array
     */
    public function getItemSubscriptionDetails($item)
    {
        try {
            $_item = $item;
            $quote_id = $_item->getQuoteId();
            $quote_custom_options_id = $_item->getItemId();
            $quote_product_id = $_item->getProductId();
            $quote_qty = $_item->getQty();

            $recurringDataDb = $this->getSubscribedQuoteItemsDatadb($quote_custom_options_id, $quote_product_id);
            $recurringDataJson = $recurringDataDb[0]['value'];
            $jasonDecodeRecurringData = json_decode($recurringDataJson, true);
            $jasonDecodeRecurringQty = $jasonDecodeRecurringData['qty'];
            $jasonDecodeRecurringDataArray = $jasonDecodeRecurringData['recurring'];

            if ((!empty($jasonDecodeRecurringDataArray)) && ($jasonDecodeRecurringDataArray['rec_activate'] == 1)) {
                $rec_activate = $jasonDecodeRecurringDataArray['rec_activate'];
                $rec_frequency = $jasonDecodeRecurringDataArray['rec_frequency'];
                $sdate = $jasonDecodeRecurringDataArray['sdate'];
                if (!empty($jasonDecodeRecurringDataArray['edate'])) {
                    $edate = $jasonDecodeRecurringDataArray['edate'];
                } else {
                    $edate = 'Recur indefinitely';
                }

                $atts = array(
                    "product_subscribed" => 'Subscribed to product(s)',
                    "product_frequency" => $rec_frequency,
                    "product_qty_subscribed" => $jasonDecodeRecurringQty,
                    "product_sdate" => $sdate,
                    "product_edate" => $edate
                );

            } else {
                $atts = array("product_subscribed" => '');
            }

        } catch (\Exception $ex) {
            $atts = array("product_subscribed" => '');
        }

        return $atts;
    }
}