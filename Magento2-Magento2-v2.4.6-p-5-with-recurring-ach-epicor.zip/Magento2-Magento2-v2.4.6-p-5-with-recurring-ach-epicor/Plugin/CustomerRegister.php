<?php
declare(strict_types=1);
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 24/1/22
 */

namespace Ebizcharge\Ebizcharge\Plugin;

use Magento\Customer\Controller\Account\CreatePost;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Response\RedirectInterface as RedirectInterface;
use Magento\Framework\Url\DecoderInterface;

/**
 * This class is used to redirect back to product page
 * after customer create success
 *
 * Class CustomerRegister
 * @package Ebizcharge\Ebizcharge\Plugin
 */
class CustomerRegister
{
    /**
     * @var Session
     */
    private $customerSession;

    /**
     * @var DecoderInterface
     */
    private $urlDecode;

    /**
     * @var RedirectInterface
     */
    private $redirect;

    /**
     * CustomerRegister constructor.
     * @param Session $customerSession
     * @param DecoderInterface $urlDecode
     * @param RedirectInterface $redirect
     */
    public function __construct(
        Session $customerSession,
        DecoderInterface $urlDecode,
        RedirectInterface $redirect
    ) {
        $this->customerSession = $customerSession;
        $this->urlDecode = $urlDecode;
        $this->redirect = $redirect;
    }

    /**
     * This function adds product referer url to customer create success
     *
     * @param CreatePost $subject
     */
    public function beforeExecute(CreatePost $subject)
    {
        $url = $this->redirect->getRedirectUrl();

        $refererEncode = explode('referer', $url)[1] ?? null;

        if ($refererEncode) {
            $refererEncodeUrl = explode('/', $refererEncode)[1] ?? null;

            if ($refererEncodeUrl) {
                $refererUrl = $this->urlDecode->decode($refererEncodeUrl);

                $this->customerSession->setBeforeAuthUrl($refererUrl);
            }
        }
    }
}
