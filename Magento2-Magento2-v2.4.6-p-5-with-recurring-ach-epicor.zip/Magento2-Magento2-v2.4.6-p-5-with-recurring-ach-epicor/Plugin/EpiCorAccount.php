<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Plugin;

use Magento\Backend\Model\View\Result\Page;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Controller\Adminhtml\Index\Edit;
use Magento\Framework\App\RequestInterface;

/**
 * Update customer erp account id, if epiCor is installed
 *
 * Class EpiCorAccount
 * @package Ebizcharge\Ebizcharge\Plugin
 */
class EpiCorAccount
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var \Ebizcharge\Ebizcharge\Observer\EpiCoreAccount
     */
    private $erpCustomer;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @param RequestInterface $request
     * @param CustomerRepositoryInterface $customerRepository
     * @param \Ebizcharge\Ebizcharge\Observer\EpiCoreAccount $erpCustomer
     */
    public function __construct(
        RequestInterface $request,
        CustomerRepositoryInterface $customerRepository,
        \Ebizcharge\Ebizcharge\Observer\EpiCoreAccount $erpCustomer
    ) {
        $this->request = $request;
        $this->erpCustomer = $erpCustomer;
        $this->customerRepository = $customerRepository;
    }

    /**
     * @param Edit $subject
     * @param Page $result
     * @return Page
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function afterExecute(Edit $subject, Page $result): Page
    {
        $customerId = (int)$this->request->getParam('id');
        if($customerId) {
          $customer = $this->customerRepository->getById($customerId);
          $this->erpCustomer->processErpCustomer($customer);
        }
        return $result;
    }
}
