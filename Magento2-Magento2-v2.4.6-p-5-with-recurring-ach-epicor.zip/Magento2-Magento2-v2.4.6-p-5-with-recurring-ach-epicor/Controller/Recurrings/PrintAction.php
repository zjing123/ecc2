<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Recurrings;

use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;

class PrintAction extends \Magento\Framework\App\Action\Action
{
    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @param Context $context
     * @param TranApi $tranApi
     */
    public function __construct(
        Context $context,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
    ) {
        parent::__construct($context);
        $this->tranApi = $tranApi;
    }

    /**
     * @return int
     */
    public function execute()
    {
        $ueSecurityToken = $this->tranApi->getUeSecurityToken();
        $client = $this->tranApi->soapClient;

        $tid = $this->_request->getParam('tid');
        $rid = $this->_request->getParam('rid');

        if (!empty($tid)) {
            try {
                $params = [
                    'securityToken' => $ueSecurityToken,
                    'transactionRefNum' => $tid,
                    'receiptRefNum' => $rid,
                    'contentType' => 'html',
                ];

                $GetRenderReceipt = $client->RenderReceipt($params);

                $GetRenderReceiptResult = $GetRenderReceipt->RenderReceiptResult;

                return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $GetRenderReceiptResult]);

            } catch (\Exception $ex) {
                $this->messageManager->addException($ex, __('No Receipt Found on Server to Print.'));
            }
        }

        return 0;
    }
}
