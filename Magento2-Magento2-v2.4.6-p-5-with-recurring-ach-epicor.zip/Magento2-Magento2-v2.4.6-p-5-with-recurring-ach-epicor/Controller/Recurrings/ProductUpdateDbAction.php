<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;

class ProductUpdateDbAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    ) {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    public function getSubscribedQuoteItemsDatadb($quote_custom_options_id, $quote_product_id)
    {
        $selectQueryParameters = [
            'option' => 'select',
            'tableName' => 'quote_item_option',
            'tableFields' => '*',
            'whereKey' => 'item_id',
            'whereValue' => $quote_custom_options_id,
            'whereKey2' => 'product_id',
            'whereValue2' => $quote_product_id
        ];

        return $this->_tran->runSelectQueryTwoFields($selectQueryParameters);
    }

    /**
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     * {"rec_activate":"1","rec_frequency":"daily","sdate":"2021-02-21","edate":"2021-02-22"},"currentpid":"","qty":"3"}
     * {"rec_activate":"0","rec_frequency":"","sdate":"","edate":""},"currentpid":"","qty":"1"}
     */
    public function execute()
    {
        $this->_tran->log('Product update db action ' . __METHOD__);

        $active = 0;
        if (!empty($_POST['active'])) {
            $active = $_POST['active'];
        }

        $frequency = '';
        if (!empty($_POST['frequency'])) {
            $frequency = $_POST['frequency'];
        }

        $sdate = '';
        if (!empty($_POST['sdate'])) {
            $sdate = $_POST['sdate'];
        }

        $edate = '';
        if (!empty($_POST['edate'])) {
            $edate = $_POST['edate'];
        }

        $qty = 1;
        if (isset($_POST['qty'])) {
            $qty = $_POST['qty'];
        }

        $cartItemId = '';
        if (!empty($_POST['cartItemID'])) {
            $cartItemId = $_POST['cartItemID'];
        }

        $cartProductId = '';
        if (!empty($_POST['cartProductID'])) {
            $cartProductId = $_POST['cartProductID'];
        }

        // get existing values
        $recurringDataDb = $this->getSubscribedQuoteItemsDatadb($cartItemId, $cartProductId);
        $recurringDataJson = $recurringDataDb[0]['value'];
        //json decode
        $jasonDecodeRecurringData = json_decode($recurringDataJson, true);

        // updating with new values
        $jasonDecodeRecurringData['qty'] = $qty;
        $jasonDecodeRecurringData['recurring']['rec_activate'] = $active;
        $jasonDecodeRecurringData['recurring']['rec_frequency'] = $frequency;
        $jasonDecodeRecurringData['recurring']['sdate'] = $sdate;
        $jasonDecodeRecurringData['recurring']['edate'] = $edate;
        //json encode
        $jasonDecodeRecurringDataEncode = json_encode($jasonDecodeRecurringData, true);

        $updateQueryParameters = [
                'option' => 'update',
                'tableName' => 'quote_item_option',
                'data' => [
                    'value' => $jasonDecodeRecurringDataEncode
                ],
                'where' => [
                    'item_id = ?' => $cartItemId,
                    'product_id = ?' => $cartProductId
                ]
            ];

        $this->_tran->runUpdateQuery($updateQueryParameters);
    }

}
