<?php
/**
* Deletes the customer's saved payment method.
*
* @author      Century Business Solutions <support@centurybizsolutions.com>
* @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
*/
namespace Ebizcharge\Ebizcharge\Controller\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\ResultFactory;

class ProductAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;
	//-----------------
	private $checkoutSession;

    protected $responseFactory;
    protected $url;



    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
		//-----------------------
		\Ebizcharge\Ebizcharge\Model\Token $token,
		\Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
		//\Ebizcharge\Ebizcharge\Model\Config $config,
		\Magento\Checkout\Model\Session $checkoutSession
	)
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
		$this->_scopeConfig = $scopeConfig;
		$this->responseFactory = $responseFactory;
        $this->url = $url;
		//-----------------------
        $this->token = $token;
        $this->_tran = $tranApi;
		//$this->config = $config;
		$this->checkoutSession = $checkoutSession;
        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }
		
	/**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
		$this->_tran->log(__METHOD__);
		
		if (isset($_POST['productid']))
		{
			$productid = $_POST['productid'];
		}
		
		if (isset($_POST['productparentid']))
		{
			$productparentid = $_POST['productparentid'];
		}
		
		if (isset($_POST['customerId']))
		{
			$customerId = $_POST['customerId'];
		}
		
		if (isset($_POST['newSdate']))
		{
			$newSdate = $_POST['newSdate'];
		}
		else
		{
			$newSdate = '';
		}

		$selectQueryParameters = array(
			'option' => 'select',
			'tableName' => 'ebizcharge_recurring',
			'tableFields' => '*', 
			'whereKey' => 'mage_item_id',
			'whereValue' => $productid,
			'whereKey2' => 'mage_cust_id',
			'whereValue2' => $customerId
		);
		
		$recurringDataEntries = $this->_tran->runSelectQueryMultiple($selectQueryParameters);
		
		if (!empty($productid))
		{
			$checkExistiningItemAction = $this->checkQuoteItems($productid);
			
			if ($checkExistiningItemAction == 'exist')
			{
				$resultJSON = $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $checkExistiningItemAction]);
        		return $resultJSON;
			}
			
		}
		
		if (!empty($newSdate))
		{
			if (!empty($recurringDataEntries))
			{
				foreach ($recurringDataEntries as $recurringData)
				{
					$productID = $recurringData['mage_item_id'];
					$oldRecurringStartDate = date('Y-m-d', strtotime($recurringData['eb_rec_start_date']));
					$oldRecurringEndDate = date('Y-m-d', strtotime($recurringData['eb_rec_end_date']));
					$newRecurringDate = date('Y-m-d', strtotime($newSdate));

					$this->_tran->log("Item #".$productID);

					if (($newRecurringDate >= $oldRecurringStartDate) && ($newRecurringDate <= $oldRecurringEndDate))
					{
						$action = 'disable';
						$this->_tran->log('Recurring against this product already exists between selected dates.');
						$resultJSON = $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $action]);
        				return $resultJSON;
					}
					else
					{
						$action = 'enable';
						$this->_tran->log('Can be subscribed.');
					}
					
				}
			}
			else
			{
				$action = 'enable';
				$this->_tran->log('No active recurringDataEntries found.');
			}
		}
		else
		{
			$action = 'enable';
			$this->_tran->log('No newSdate selected.');
		}
		
		$resultJSON = $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $action]);
        return $resultJSON;
    }

	public function checkQuoteItems($productid)
	{
		$this->_tran->log(__METHOD__);

		if ($this->checkoutSession->getQuote()->hasProductId($productid))
		{
			//product is available in the cart
			$this->_tran->log($productid.' product already in the cart');
			$action = 'exist';
		}
		else
		{
			$this->_tran->log($productid.' product new to the cart');
			$action = 'enable';
		}
		return $action;

	}

}
