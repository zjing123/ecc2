<?php
/**
 * Updates the details of the edited payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Recurrings;

use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\RegionInterface;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Customer\Model\Session;
use Magento\Directory\Helper\Data as HelperData;
use Magento\Directory\Model\RegionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\ForwardFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\View\Result\PageFactory;

use Magento\Framework\App\Bootstrap;
use Magento\framework\Exception\ValidatorException;


class UpdateAction extends \Magento\Customer\Controller\Address
{
    protected $regionFactory;
    protected $helperData;
    protected $token;
    protected $_tran;
    protected $_scopeConfig;
    protected $_paymentconfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param FormKeyValidator $formKeyValidator
     * @param FormFactory $formFactory
     * @param AddressRepositoryInterface $addressRepository
     * @param AddressInterfaceFactory $addressDataFactory
     * @param RegionInterfaceFactory $regionDataFactory
     * @param DataObjectProcessor $dataProcessor
     * @param DataObjectHelper $dataObjectHelper
     * @param ForwardFactory $resultForwardFactory
     * @param PageFactory $resultPageFactory
     * @param RegionFactory $regionFactory
     * @param HelperData $helperData
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        FormKeyValidator $formKeyValidator,
        FormFactory $formFactory,
        AddressRepositoryInterface $addressRepository,
        AddressInterfaceFactory $addressDataFactory,
        RegionInterfaceFactory $regionDataFactory,
        DataObjectProcessor $dataProcessor,
        DataObjectHelper $dataObjectHelper,
        ForwardFactory $resultForwardFactory,
        PageFactory $resultPageFactory,
        RegionFactory $regionFactory,
        HelperData $helperData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Config $paymentconfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi)
    {
        $this->regionFactory = $regionFactory;
        $this->helperData = $helperData;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->_scopeConfig = $scopeConfig;
        $this->_paymentconfig = $paymentconfig;
        parent::__construct(
            $context,
            $customerSession,
            $formKeyValidator,
            $formFactory,
            $addressRepository,
            $addressDataFactory,
            $regionDataFactory,
            $dataProcessor,
            $dataObjectHelper,
            $resultForwardFactory,
            $resultPageFactory);

    }

    /**
     * Saves the updated payment information.
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
        $redirectUrl = null;

        $recurringId = $this->getRequest()->getParam('table_rec_id');
        $cid = $this->getRequest()->getParam('cid');
        $paymentMethodId = $this->getRequest()->getParam('method_id');
        $oldMethodId = $this->getRequest()->getParam('eb_rec_method_id');
        $schedulePaymentInternalId = !empty($this->getRequest()->getParam('mid')) ? trim($this->getRequest()->getParam('mid')) : '';
        $custIntId = $this->getRequest()->getParam('custIntId');
        $paymentErrorReturnUrl = '/cid/' . $cid . '/mid/' . $schedulePaymentInternalId . '/';
        $paymentMethodName = !empty($this->getRequest()->getParam('payment_method_name')) ? trim($this->getRequest()->getParam('payment_method_name')) : '';

        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/listaction');
        }

        $addNewForm = $this->getRequest()->getParam('payment');

        if ((isset($addNewForm['add_new'])) || (!empty($addNewForm['add_new']))) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $paymentTypes = $objectManager->get('\Magento\Payment\Model\Config')->getCcTypes();

            $cardType = $addNewForm['cc_type'];

            foreach ($paymentTypes as $code => $text) {
                if ($code == $addNewForm['cc_type']) {
                    $cardType = $text;
                }
            }

            $cardExpiration = $addNewForm['cc_exp_year'] . "-" . $addNewForm['cc_exp_month'];

            if ((isset($addNewForm['cc_cid'])) || (!empty($addNewForm['cc_cid']))) {
                $cc_cid = $addNewForm['cc_cid'];
            } else {
                $cc_cid = '';
            }

            $paymentMethodName = $cardType . ' ' . substr($addNewForm['cc_number'], -4) . ' - ' . $addNewForm['cc_owner'];
            $paymentParameters = array(
                'MethodName' => $paymentMethodName,
                'AccountHolderName' => $addNewForm['cc_owner'],
                'SecondarySort' => 1,
                'Created' => date('Y-m-d\TH:i:s'),
                'Modified' => date('Y-m-d\TH:i:s'),
                'CardCode' => $cc_cid,
                'CardExpiration' => $cardExpiration,
                'CardNumber' => $addNewForm['cc_number'],
                'CardType' => $addNewForm['cc_type'],
                'Balance' => 0,
                'MaxBalance' => 0,
            );

            $paymentMethodId = $this->addCustomerPaymentMethod($custIntId, $paymentParameters, $paymentErrorReturnUrl);
        }

        if ($schedulePaymentInternalId) {
            $ueSecurityToken = $this->_tran->getUeSecurityToken();
            $client = $this->_tran->soapClient;

            try {
                $amount = $this->getRequest()->getParam('amount');
                $schedule = $this->getRequest()->getParam('schedule');
                $enabled = $this->getRequest()->getParam('enabled');
                $rec_indefinitely = $this->getRequest()->getParam('rec_indefinitely');
                $qty = $this->getRequest()->getParam('qty');
                $start = $this->getRequest()->getParam('start_date');
                $expire = $this->getRequest()->getParam('expire_date');
                $repeatCount = $this->getRequest()->getParam('repeatcount');
                $scheduleName = $this->getRequest()->getParam('schedulename');
                $sendCustomerReceipt = $this->getRequest()->getParam('sendcustomerreceipt');
                $receiptNote = $this->getRequest()->getParam('receiptnote');

                if ($qty == 0)
                    $qty = 1;

                if (!empty($start)) {
                    $start = date("Y-m-d", strtotime($start));
                }

                if ($rec_indefinitely == 1) {
                    $expire = date('Y-m-d', strtotime('+10 years'));
                } else {
                    $rec_indefinitely = 0;

                    if (!empty($expire)) {
                        $expire = date("Y-m-d", strtotime($expire));
                    } else {
                        $expire = date('Y-m-d', strtotime('+10 years'));
                    }
                }

                // update payment method only when there is a changes
                $paymentMethodProfileStatus = 1;
                if (!empty($methodId) && $oldMethodId !== $paymentMethodId) {
                    $paymentMethodProfileStatus = $this->_tran->modifyRecurringPaymentMethod($paymentMethodId, $schedulePaymentInternalId);
                }

                $amount = number_format((float)trim($amount * $qty), 2, '.', '');

                $recurringBilling = array(
                    'Amount' => $amount,
                    'Enabled' => true,
                    'Start' => trim($start),
                    'Expire' => trim($expire),
                    'Next' => trim($expire),
                    'Schedule' => trim($schedule),
                    'ScheduleName' => trim($scheduleName),
                    'ReceiptNote' => $receiptNote,
                    'ReceiptTemplateName' => false,
                    'SendCustomerReceipt' => true

                );
                $recurringObject = array(
                    'securityToken' => $ueSecurityToken,
                    'scheduledPaymentInternalId' => $schedulePaymentInternalId,
                    'recurringBilling' => $recurringBilling
                );

                $modifyScheduled = $client->ModifyScheduledRecurringPayment_RecurringBilling($recurringObject);

                if (isset($modifyScheduled->ModifyScheduledRecurringPayment_RecurringBillingResult) && $paymentMethodProfileStatus == 1) {
                    $this->messageManager->addSuccess(__('Subscription changes successfully saved.'));
                    $url = $this->_buildUrl('*/*/listaction', ['_secure' => true]);

                    ///////////////// update table/////////////
                    $recurringDates = $this->_tran->getRecurringScheduledDates($schedulePaymentInternalId);

                    $recurringDatesSerialize = serialize($recurringDates);
                    $totalRecurrings = count($recurringDates);

                    $nextRecurringDate = $this->_tran->getNextRecurringDate($recurringDates);

                    $resource = \Magento\Framework\App\ObjectManager::getInstance()
                        ->get('Magento\Framework\App\ResourceConnection');
                    $connection = $resource->getConnection();

                    $negotiateTable = $resource->getTableName('ebizcharge_recurring');

                    $sqlu = "update " . $negotiateTable . " set
					rec_indefinitely = " . $rec_indefinitely . ",
					eb_rec_frequency = '" . $schedule . "',
					qty_ordered = $qty,
					eb_rec_start_date = '" . trim($start) . "',
					eb_rec_end_date = '" . trim($expire) . "',
					eb_rec_method_id = $paymentMethodId,
					eb_rec_total = $totalRecurrings,
					eb_rec_processed = '0',
					eb_rec_next = '$nextRecurringDate',
					eb_rec_remaining = $totalRecurrings,
					eb_rec_due_dates = '$recurringDatesSerialize' ,
					amount = $amount,
					payment_method_name = '".$paymentMethodName."'
					WHERE eb_rec_scheduled_payment_internal_id = '" . $schedulePaymentInternalId . "'";

                    $result1 = $connection->query($sqlu);

                    $this->_tran->insertScheduleDates($recurringId, $recurringDates);

                    return $this->resultRedirectFactory->create()->setUrl($this->_redirect->success($url));
                } else {
                    $this->messageManager->addError(__('Unable to update changes.'));
                }
            } catch (\Exception $ex) {
                $this->messageManager->addException($ex, __('Unable to update subscription.'));
            }
        } else {
            $this->messageManager->addError(__('Unable to update subscription.'));
        }

        $url = $this->_buildUrl('*/*/listaction');
        return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error($url));
    }

    private function addCustomerPaymentMethod($customerInternalId, $parameters, $paymentErrorReturnUrl)
    {
        try {
            $paymentMethodId = $this->_tran->addCustomerPaymentMethod($customerInternalId, $parameters);

            if ($paymentMethodId !== null) {
                $this->messageManager->addSuccess(__('Payment method successfully saved.'));
                return $paymentMethodId;
            } else {
                //return null;
                $this->messageManager->addError(__('Unable to save the payment method.'));
                $url = $this->_buildUrl('*/*/editaction' . $paymentErrorReturnUrl);
            }

        } catch (\Exception $ex) {
            $this->messageManager->addError(__('Exception: ' . $ex->getMessage()));
            $url = $this->_buildUrl('*/*/editaction' . $paymentErrorReturnUrl);
        }
        return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error($url));
    }

    /**
     * Updates region data.
     *
     * @param array $attributeValues
     * @return void
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function updateRegionData(&$attributeValues)
    {
        if (!empty($attributeValues['region_id'])) {
            $newRegion = $this->regionFactory->create()->load($attributeValues['region_id']);
            $attributeValues['region_code'] = $newRegion->getCode();
            $attributeValues['region'] = $newRegion->getDefaultName();
        }

        $regionData = [
            RegionInterface::REGION_ID => !empty($attributeValues['region_id']) ? $attributeValues['region_id'] : null,
            RegionInterface::REGION => !empty($attributeValues['region']) ? $attributeValues['region'] : null,
            RegionInterface::REGION_CODE => !empty($attributeValues['region_code'])
                ? $attributeValues['region_code']
                : null];

        array_merge($attributeValues, $regionData);
    }
}
