<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Cards;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;

class DeleteAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi)
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    /**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
        $request = $this->_request;

        if (!$request instanceof Http) {
            return $this->createErrorResponse(self::WRONG_REQUEST);
        }

        if (!$this->fkValidator->validate($request)) {
            return $this->createErrorResponse(self::WRONG_REQUEST);
        }

        $cid = $this->getRequest()->getParam('cid');
        $mid = $this->getRequest()->getParam('mid');
        $cust_id = $this->getRequest()->getParam('cust_id');

        if ($cid === null || $mid === null) {
            return $this->createErrorResponse(self::WRONG_TOKEN);
        }

        try {

            $resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
            $connection = $resources->getConnection();
            $negotiateTable = $resources->getTableName('ebizcharge_recurring');

            $sql = "select eb_rec_scheduled_payment_internal_id from  " . $negotiateTable . " where mage_cust_id =" . $cust_id . " and eb_rec_method_id = '" . $mid . "' and rec_status = 0";
            $result = $connection->fetchall($sql);
            if (count($result) > 0) {
                $scheduledPaymentInternalId = $result[0]['eb_rec_scheduled_payment_internal_id'];
                $params = array(
                    'securityToken' => $this->_tran->getUeSecurityToken(),
                    'scheduledPaymentInternalId' => $scheduledPaymentInternalId,
                    'statusId' => 1,
                );

                $res = $this->_tran->soapClient->ModifyScheduledRecurringPaymentStatus($params);

                $ModifyScheduledRecurringPaymentStatusResult = $res->ModifyScheduledRecurringPaymentStatusResult;

                if ($ModifyScheduledRecurringPaymentStatusResult->StatusCode == 1) {

                    $sqlUpdate = "update " . $negotiateTable . " set
						rec_status =1 WHERE eb_rec_scheduled_payment_internal_id = '" . $scheduledPaymentInternalId . "'";
                    $result = $connection->query($sqlUpdate);
                }

            }

            $params = array(
                'securityToken' => $this->_tran->getUeSecurityToken(),
                'customerToken' => $cid,
                'paymentMethodId' => $mid,
            );

            $this->_tran->soapClient->deleteCustomerPaymentMethodProfile($params);


        } catch (\Exception $e) {
            $this->_tran->log(__METHOD__ . $e->getMessage());
            return $this->createErrorResponse(self::ACTION_EXCEPTION);
        }

        return $this->createSuccessMessage();
    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(
            $this->errorsMap[$errorCode]);

        return $this->_redirect('ebizcharge/cards/listaction');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage()
    {
        $this->messageManager->addSuccessMessage(__('Credit card was successfully removed.'));
        return $this->_redirect('ebizcharge/cards/listaction');
    }
}