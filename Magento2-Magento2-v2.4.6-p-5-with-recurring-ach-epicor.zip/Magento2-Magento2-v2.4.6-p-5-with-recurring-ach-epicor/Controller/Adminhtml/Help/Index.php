<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Help;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action implements HttpGetActionInterface
{
    /**
     * @var PageFactory
     */
    private $pageFactory;

    public function __construct(
        Context $context,
        PageFactory $pageFactory
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
    }

    /**
     * Help and contact us page
     * @return ResultInterface|Page
     */
    public function execute()
    {
        $resultPage =  $this->pageFactory->create();
        $resultPage->setActiveMenu('Ebizcharge_Ebizcharge::feedback');
        $resultPage->getConfig()->getTitle()->prepend(__('EBizCharge Help & Contact Us'));
        return $resultPage;
    }

}
