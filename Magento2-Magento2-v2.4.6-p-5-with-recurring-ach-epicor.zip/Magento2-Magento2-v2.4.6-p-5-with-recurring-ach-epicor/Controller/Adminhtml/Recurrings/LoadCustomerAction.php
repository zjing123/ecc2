<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\ResultFactory;

class LoadCustomerAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;
    protected $responseFactory;
    protected $url;


    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Ebizcharge\Ebizcharge\Model\Token $token
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Magento\Framework\App\ResponseFactory $responseFactory
     * @param \Magento\Framework\UrlInterface $url
     */
    public function __construct(
        Context                                            $context,
        Session                                            $customerSession,
        JsonFactory                                        $jsonFactory,
        Validator                                          $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token                 $token,
        \Ebizcharge\Ebizcharge\Model\TranApi               $tranApi,
        \Magento\Framework\App\ResponseFactory             $responseFactory,
        \Magento\Framework\UrlInterface                    $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')
        ];
    }

    public function execute()
    {
        $post = $this->getRequest()->getPost();
        $customerId = isset($post['customer_id']) ? $post['customer_id'] : '';
        $ebizCustomerId = $this->_tran->getCustomerToken($customerId);
        $selectedMethodType = isset($post['ebizs_option']) ? $post['ebizs_option'] : '';

        if (!empty($ebizCustomerId)) {
            try {

                $paymentMethods = $this->_tran->getCustomerPaymentMethods($ebizCustomerId);
                $method = "";

                foreach ($paymentMethods as $paymentMethod) {
                    if ($paymentMethod->MethodType == $selectedMethodType) {
                        $method .= "<option value='" . $paymentMethod->MethodID . "'>" . $paymentMethod->MethodName . "</option>";
                    }
                }

                return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $method]);

            } catch (Exception $ex) {
                $method = "<option value=''>No payment method found</option>";
                return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $method]);
            }
        } else {
            $method = "<option value=''>Invalid Customer ID</option>";
            return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $method]);
        }
    }

}