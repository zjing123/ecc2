<?php
namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Index
 */
class EditAction extends Action implements HttpGetActionInterface
{
   // const MENU_ID = 'Ebizcharge_Ebizcharge::greetings_helloworld';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);

        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Load the page defined in view/adminhtml/layout/exampleadminnewpage_helloworld_index.xml
     *
     * @return Page
     */
    public function execute()
    {
       $mid = $this->getRequest()->getParam('mid');
		
		if ($mid)
        {			
		   $resultPage = $this->resultPageFactory->create();
           $resultPage->getConfig()->getTitle()->prepend(__('Manage Subscription Payment History'));

           return $resultPage;
		}
        else
        {
			$this->messageManager->addError(__('Unable to update recurrings payment.'));
		}
		
		//$url = $this->_buildUrl('*/*/listaction');

		return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error());
	}
}