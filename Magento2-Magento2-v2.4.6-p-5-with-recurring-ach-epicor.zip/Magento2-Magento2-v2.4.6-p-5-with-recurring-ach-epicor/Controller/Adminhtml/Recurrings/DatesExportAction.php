<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Framework\Controller\ResultFactory;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;

class DatesExportAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    /**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
        $resources = \Magento\Framework\App\ObjectManager::getInstance()
            ->get('Magento\Framework\App\ResourceConnection');
        $connection = $resources->getConnection();
        $recurringTable = $resources->getTableName('ebizcharge_recurring');
        $recurringDateTable = $resources->getTableName('ebizcharge_recurring_dates');
        $customerTableName = $resources->getTableName('customer_entity');


        $id = $this->getRequest()->getParam('mid');

        if (!empty($id)) {
            try {

                $sql = "Select r.mage_cust_id, r.mage_item_name,r.eb_rec_frequency, r.rec_status,
                        c.firstname, c.lastname, c.email, rd.recurring_date, r.amount
                        FROM " . $recurringTable . " r
                        INNER JOIN  $recurringDateTable rd on rd.recurring_id = r.rec_id
                        INNER JOIN " . $customerTableName . " as c on r.mage_cust_id = c.entity_id
                        WHERE eb_rec_scheduled_payment_internal_id = '" . $id . "'
                        ORDER BY rd.recurring_date ASC";

                $result = $connection->fetchall($sql);

                if (!empty($result)) {
                    $delimiter = ",";
                    $filename = $result[0]['mage_cust_id'] . '_' . $result[0]['mage_item_name'] . ".csv";
                    $f = fopen('php://memory', 'w');
                    $fields = array('Due Date', 'Item Name', 'Customer Id', 'Customer Name', 'Customer Email', 'Frequency', 'Amount');
                    fputcsv($f, $fields, $delimiter);

                    foreach ($result as $recurring) {
                        $customerName = $recurring['firstname'] . ' ' . $recurring['lastname'];
                        $lineData = array(
                            $recurring['recurring_date'], $recurring['mage_item_name'], $recurring['mage_cust_id'],
                            $customerName, $recurring['email'], ucfirst($recurring['eb_rec_frequency']), $recurring['amount']
                        );

                        fputcsv($f, $lineData, $delimiter);
                    }

                    fseek($f, 0);
                    header('Content-Type: text/csv');
                    header('Content-Disposition: attachment; filename="' . $filename . '"');
                    fpassthru($f);
                    exit;

                }

            } catch (\Exception $ex) {
                //return $this->createErrorResponse(self::ACTION_EXCEPTION);
                return $this->createErrorResponse('Exception: ' . $ex->getMessage());
            }
        } else {
            return null;
        }

    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage($this->errorsMap[$errorCode]);
        return $this->_redirect('ebizcharge/recurrings/listaction');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage()
    {
        $this->messageManager->addSuccessMessage(__('Subscription(s) successfully Deleted.'));
        return $this->_redirect('ebizcharge/recurrings/listaction');
    }
}
