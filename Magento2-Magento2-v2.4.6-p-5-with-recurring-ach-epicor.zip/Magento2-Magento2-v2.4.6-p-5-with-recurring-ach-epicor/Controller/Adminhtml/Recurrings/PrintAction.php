<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Ebizcharge\Ebizcharge\Model\TranApi;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class PrintAction
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings
 */
class PrintAction extends \Magento\Framework\App\Action\Action
{
    /**
     * @var TranApi
     */
    private $_tran;

    /**
     * @param Context $context
     * @param TranApi $tranApi
     */
    public function __construct(
        Context $context,
        TranApi $tranApi
    ) {
        parent::__construct($context);
        $this->_tran = $tranApi;
    }

    /**
     * @return int
     */
    public function execute()
    {
        $tid = $this->_request->getParam('tid');
        $rid = $this->_request->getParam('rid');

        if (!empty($tid)) {
            $params = [
                'securityToken' => $this->_tran->getUeSecurityToken(),
                'transactionRefNum' => $tid,
                'receiptRefNum' => $rid,
                'contentType' => 'html',
            ];
            try {

                $renderReceipt = $this->_tran->soapClient->RenderReceipt($params);
                $GetRenderReceiptResult = $renderReceipt->RenderReceiptResult;

                $receipt_html = base64_decode($GetRenderReceiptResult);

                return $this->resultFactory->create(ResultFactory::TYPE_JSON)->setData(['html_data' => $receipt_html]);

            } catch (\Exception $e) {
                $this->_tran->log($e->getMessage());
            }
        }

        return 0;
    }
}
