<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Framework\Controller\ResultFactory;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;

class ExportAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    /**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
        $ueSecurityToken = $this->_tran->getUeSecurityToken();
        $client = $this->_tran->soapClient;

        $resource = \Magento\Framework\App\ObjectManager::getInstance()
            ->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        if (isset($_POST['tid'])) {

            $etype = $_POST['etype'];

            if ($etype == 'csv') {

                $response = $client->SearchScheduledRecurringPayments(
                    array(
                        'securityToken' => $ueSecurityToken,
                        'start' => 0,
                        'limit' => 900,
                    ));

                $recurringBillingDetails = $response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails;

                if (!empty($recurringBillingDetails)) {

                    $delimiter = ",";
                    $filename = "subscription_shedule" . date('Y-m-d') . ".csv";
                    $f = fopen('php://memory', 'w');
                    $fields = array('Cusotmer', 'Cusotmer ID', 'Item Detail', 'Start & End Date', 'Frequency', 'Amount', 'Payment Method', 'Status');
                    fputcsv($f, $fields, $delimiter);

                    foreach ($recurringBillingDetails as $payment) {
                        if ($payment->ScheduleStatus != 3) {

                            $responseGetCustomer = $client->GetCustomer(
                                array(
                                    'securityToken' => $ueSecurityToken,
                                    'customerId' => $payment->CustomerId,
                                ));

                            $GetCustomerResult = $responseGetCustomer->GetCustomerResult;

                            $orgDate = $payment->Start;
                            $start = date("Y-m-d", strtotime($orgDate));

                            $orgDateExpire = $payment->Expire;
                            $expire = date("Y-m-d", strtotime($orgDateExpire));
                            $status = $payment->ScheduleStatus == 0 ? 'On' : 'Off';

                            $negotiateTable = $resource->getTableName('ebizcharge_recurring');

                            $sql = "Select mage_item_name FROM " . $negotiateTable . " WHERE eb_rec_scheduled_payment_internal_id = '" . $payment->ScheduledPaymentInternalId . "'";

                            $result = $connection->fetchall($sql);
                            if (count($result) > 0)
                                $itemName = $result[0]['mage_item_name'];
                            else
                                $itemName = 'N/A';

                            $lineData = array(
                                $GetCustomerResult->FirstName . ' ' . $GetCustomerResult->LastName,
                                $payment->CustomerId,
                                $itemName,
                                $start . ' - ' . $expire,
                                ucfirst($payment->Schedule),
                                $payment->Amount,
                                $payment->PMHolderName,
                                $status
                            );

                            fputcsv($f, $lineData, $delimiter);
                        }
                    }

                    fseek($f, 0);
                    header('Content-Type: text/csv');
                    header('Content-Disposition: attachment; filename="' . $filename . '"');
                    fpassthru($f);
                    exit;
                }
            }

            if ($etype == 'xls') {
                $filename = "subscription_shedule" . date('Y-m-d') . ".xls";

                header("Content-Disposition: attachment; filename=\"$filename\"");
                header("Content-Type: application/vnd.ms-excel");
                ?>
                <table>
                    <tr>
                        <td>Customer</td>
                        <td>Customer ID</td>
                        <td>Item Detail</td>
                        <td>Start & End Date</td>
                        <td>Frequency</td>
                        <td>Amount</td>
                        <td>Payment Method</td>
                        <td>Status</td>
                    </tr>
                    <?php

                    $response = $client->SearchScheduledRecurringPayments(
                        array(
                            'securityToken' => $ueSecurityToken,
                            'fromDateTime' => '2020-12-12',
                            'toDateTime' => date('Y-m-d'),
                            'start' => 0,
                            'limit' => 100,
                        ));

                    $recurringBillingDetails = $response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails;

                    if (!empty($recurringBillingDetails)) {

                        foreach ($recurringBillingDetails as $payment) {
                            if ($payment->ScheduleStatus != 3) {

                                $responseGetCustomer = $client->GetCustomer(
                                    array(
                                        'securityToken' => $ueSecurityToken,
                                        'customerId' => $payment->CustomerId,
                                    ));

                                $GetCustomerResult = $responseGetCustomer->GetCustomerResult;

                                $orgDate = $payment->Start;
                                $start = date("Y-m-d", strtotime($orgDate));

                                $orgDateExpire = $payment->Expire;
                                $expire = date("Y-m-d", strtotime($orgDateExpire));
                                $status = $payment->ScheduleStatus == 0 ? 'On' : 'Off';

                                $negotiateTable = $resource->getTableName('ebizcharge_recurring');

                                $sql = "Select mage_item_name FROM " . $negotiateTable . " WHERE eb_rec_scheduled_payment_internal_id = '" . $payment->ScheduledPaymentInternalId . "'";

                                $result = $connection->fetchall($sql);
                                if (count($result) > 0)
                                    $itemName = $result[0]['mage_item_name'];
                                else
                                    $itemName = 'N/A';

                                $name = $GetCustomerResult->FirstName . ' ' . $GetCustomerResult->LastName;
                                ?>
                                <tr>
                                    <td><?php echo $name ?></td>
                                    <td><?php echo $payment->CustomerId ?></td>
                                    <td><?php echo $itemName ?></td>
                                    <td><?php echo $start . ' - ' . $expire ?></td>
                                    <td><?php echo ucfirst($payment->Schedule) ?></td>
                                    <td><?php echo $payment->Amount ?></td>
                                    <td><?php echo $payment->PMHolderName ?></td>
                                    <td><?php echo $status ?></td>
                                </tr>

                                <?php
                            }
                        }

                        exit;
                    }

                    ?>
                </table>
                <?php
            }

        } else {

            return NULL;
        }

    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage($this->errorsMap[$errorCode]);
        return $this->_redirect('ebizcharge/recurrings/listaction');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage()
    {
        $this->messageManager->addSuccessMessage(__('Subscription(s) successfully Exported.'));
        return $this->_redirect('ebizcharge/recurrings/listaction');
    }
} 
