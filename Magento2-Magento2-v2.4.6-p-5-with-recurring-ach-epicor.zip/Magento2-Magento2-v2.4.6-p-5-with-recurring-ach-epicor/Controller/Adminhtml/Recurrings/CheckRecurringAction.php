<?php
/**
 * check the recurring's saved dates.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Magento\Framework\UrlInterface;


class CheckRecurringAction extends Action
{
    protected $urlBuilder;

    public function __construct(UrlInterface $urlBuilder, Context $context)
    {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context);
    }

    /**
     * @return ResultInterface|ResponseInterface
     */
    public function execute()
    {
        $resources = \Magento\Framework\App\ObjectManager::getInstance()
            ->get('Magento\Framework\App\ResourceConnection');
        $connection = $resources->getConnection();
        $recurringTable = $resources->getTableName('ebizcharge_recurring');

        $customerId = $this->getRequest()->getParam('customer_id');
        $startDate = $this->getRequest()->getParam('start_date');
        $productId = $this->getRequest()->getParam('product_id');
        $recId = $this->getRequest()->getParam('rec_id');
        $cond = '';
        if (!empty($recId)) {
            $cond = ' and rec_id !=' . $recId;
        }

        $sql = "select rec_id, eb_rec_scheduled_payment_internal_id, mage_cust_id from " . $recurringTable . " 
                    WHERE mage_cust_id = '" . trim($customerId) . "' and mage_item_id = '" . trim($productId) . "'  
                    and DATE(eb_rec_end_date) >= '" . $startDate . "' $cond";

        $result = $connection->fetchAll($sql);

        if (!empty($result)) {

            $redirectUrl = $this->urlBuilder->getUrl('ebizcharge_ebizcharge/recurrings/editaction',
                [
                    '_secure' => true,
                    'mid' => $result[0]['eb_rec_scheduled_payment_internal_id'],
                    'magcid' => $result[0]['mage_cust_id']
                ]);

            $recId = $result[0]['rec_id'];
            $response = array(
                'status' => 'E',
                'recid' => $recId,
                'mid' => $result[0]['eb_rec_scheduled_payment_internal_id'],
                'magcid' => $result[0]['mage_cust_id'],
                'message' => "The selected product already subscribed with id <a href='" . $redirectUrl . "'>'" . $recId . "'</a>. Please select a different date range."
            );

        } else {
            $response = array('status' => 'P');
        }

        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($response);

        return $resultJson;
    }
}
