<?php
declare(strict_types=1);
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Ebizcharge\Ebizcharge\Model\Config;
use Ebizcharge\Ebizcharge\Model\Data as DataClass;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Exception;
use Magento\Backend\App\Area\FrontNameResolver;
use Magento\Catalog\Model\ProductFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Area;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\State;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Model\QuoteFactory;
use Magento\Quote\Model\QuoteManagement;
use Magento\Sales\Model\Order;
use Magento\SalesSequence\Model\Manager as SequenceManager;
use Magento\Store\Model\StoreManagerInterface;

class CreateOrderAction extends Action
{
    public $paymentInternalId;

    /**
     * @var TranApi
     */
    private $_tran;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var DataClass
     */
    private $dataClass;

    /**
     * @var QuoteFactory
     */
    private $quote;

    /**
     * @var QuoteManagement
     */
    private $quoteManagement;

    /**
     * @var Validator
     */
    private $fkValidator;

    /**
     * @var \Magento\Framework\App\ResourceConnection|mixed
     */
    private $resource;

    /**
     * created order id
     * @var null|int
     */
    private $orderId = null;

    /**
     * created order entity id
     * @var null|int
     */
    private $orderEntityId = null;


    /**
     * @const FREE_SHIPPING
     */
    const FREE_SHIPPING = 'freeshipping_freeshipping';

    /**
     * @var SequenceManager
     */
    private $sequenceManager;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var StoreManagerInterface
     */
    private $_storeManager;

    /**
     * @var ProductFactory
     */
    private $productFactory;

    /**
     * Fremework App State
     *
     * @var State
     */
    private $_appState;

    /**
     * @var $recurring
     */
    private $recurring;

    /**
     * @var $orderData
     */
    private $orderData;

    /**
     * @var $savedOrderPaymentData
     */
    private $savedOrderPaymentData;

    /**
     * @var $customerData
     */
    private $customerData;

    /**
     * @var $shipmentMethod
     */
    private $shipmentMethod;

    /**
     * Recurrings that have more than one product
     * @var array
     */
    private $bundleRecurrings = [];

    /**
     * If recurring is successfully created
     * @var false
     */
    private $newRecurringOrderCreated = false;

    /**
     *  successfully created orders
     * @var array
     */
    private $orders = [];

    /**
     * failed orders
     * @var array
     */
    private $failedOrders = [];

    /**
     * @param Context $context
     * @param State $appState
     * @param Validator $fkValidator
     * @param Config $config
     * @param TranApi $tranApi
     * @param StoreManagerInterface $storeManager
     * @param ProductFactory $productFactory
     * @param CustomerRepositoryInterface $customerRepository
     * @param QuoteFactory $quote
     * @param QuoteManagement $quoteManagement
     * @param SequenceManager $sequenceManager
     * @param DataClass $dataClass
     */
    public function __construct(
        Context $context,
        State $appState,
        Validator $fkValidator,
        Config $config,
        TranApi $tranApi,
        StoreManagerInterface $storeManager,
        ProductFactory $productFactory,
        CustomerRepositoryInterface $customerRepository,
        QuoteFactory $quote,
        QuoteManagement $quoteManagement,
        SequenceManager $sequenceManager,
        DataClass $dataClass
    ) {
        parent::__construct($context);
        $this->fkValidator = $fkValidator;
        $this->config = $config;
        $this->_tran = $tranApi;
        $this->_storeManager = $storeManager;
        $this->productFactory = $productFactory;
        $this->customerRepository = $customerRepository;
        $this->quote = $quote;
        $this->quoteManagement = $quoteManagement;
        $this->resource = $config->getQueryResourceConnection();
        $this->sequenceManager = $sequenceManager;
        $this->_appState = $appState;
        $this->dataClass = $dataClass;
    }

    /**
     * Deletes customer's payment method.
     *
     * @return bool|void
     * @throws LocalizedException
     */
    public function execute()
    {
        $request = $this->_request;

        if (!$request instanceof Http) {
            return $this->createErrorResponse(__('Failed: Wrong request.'));
        }

        if (!$this->fkValidator->validate($request)) {
            return $this->createErrorResponse(__('Failed: Wrong request.'));
        }

        if ($this->config->isEbizchargeActive() == 0) {
            return $this->createErrorResponse('Failed: EBizCharge module is inactive.');
        }

        if ($this->config->isRecurringEnabled() == 0) {
            return $this->createErrorResponse('Failed: EBizCharge recurring functionality is inactive.');
        }

        $post = $request->getPost();
        $startDate = $post['start_date'];

        $this->_tran->cronlog('CreateOrder run start. The time is ' . date("Y-m-d h:i:sa"));

        $this->checkRecurringOrders($startDate);

        $this->_tran->cronlog('------------------end create orders---------------');

        $this->createSuccessMessage();

        if ($this->_appState->getAreaCode() != FrontNameResolver::AREA_CODE) {
            return true;
        }
    }

    /**
     * Creates an error message, and passes it to the "Manage
     *
     * @param $errorMessage
     * @return mixed
     */
    private function createErrorResponse($errorMessage)
    {
        $this->messageManager->addErrorMessage($errorMessage);
        return true;
    }

    /**
     * @param $startDate
     */
    public function checkRecurringOrders($startDate)
    {
        $this->_tran->cronlog(__METHOD__);

        $objectManager = $this->config->getObjectManagerInstance();
        $this->dataClass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');

        $allRecurrings = $this->getRecurringList($startDate);

        $recurringsToSuspend = [];

        $recurringsToProcess = [];

        foreach ($allRecurrings as $recurring) {

            if ($recurring['eb_rec_remaining'] == 0) {

                $recurringsToSuspend[] = $recurring;

            } else if ($recurring['eb_rec_remaining'] != 0) {

                $recurringsToProcess[] = $recurring;
            }

        }

        $this->suspendRecurrings($recurringsToSuspend);

        $simpleRecurrings = $this->getSimpleRecurrings($recurringsToProcess);

        $recurringOrders = $this->getRecurringOrders($startDate);

        $this->processSimpleRecurrings($simpleRecurrings, $recurringOrders);

        $this->processBunddleRecurrings($this->bundleRecurrings, $recurringOrders);
    }

    protected function getRecurringList($startDate)
    {
        $resource = $this->resource;
        $connection = $resource->getConnection();
        $recurringTable = $resource->getTableName('ebizcharge_recurring');
        $recurringDateTable = $resource->getTableName('ebizcharge_recurring_dates');
        $today = date('Y-m-d');

        $sql = "Select * FROM " . $recurringTable . " r
                INNER JOIN  $recurringDateTable rd on rd.recurring_id = r.rec_id
                WHERE rd.recurring_date BETWEEN '" . $startDate . "' AND  '" . $today . "'
                AND rec_status = 0 ORDER BY rd.recurring_date ASC limit 100";
        return $connection->fetchall($sql);
    }

    public function getRecurringOrders($startDate)
    {
        $connection = $this->resource->getConnection();
        $recurringOrderTable = $this->resource->getTableName('ebizcharge_recurring_order');
        $today = date('Y-m-d');

        $sql = "Select recurring_id, order_date FROM " . $recurringOrderTable . "
                WHERE date(order_date) BETWEEN '" . $startDate . "' AND  '" . $today . "'
                AND status=1 limit 1000";

        $orders = $connection->fetchall($sql);
        $recurringOrders = [];

        foreach ($orders as $order) {
            $orderDate = date('Y-m-d', strtotime($order['order_date']));
            $recurringId = $order['recurring_id'];
            $uniqueKey = $recurringId . '_' . $orderDate;
            $recurringOrders[$uniqueKey] = $recurringId;
        }
        return $recurringOrders;
    }

    public function createMageOrderRecurring($recurring, $orderData, $savedOrderPaymentData, $customerData, $shipmentMethod)
    {
        $this->newRecurringOrderCreated = false;
        $this->_tran->cronlog(__METHOD__);
        // Select 1st active shipping method
        $order = $this->createOrderQuote($recurring, $orderData, $savedOrderPaymentData, $customerData, $shipmentMethod);

        $order->setEmailSent(0);

        // For admin history orders Totals override object start
        /*$order->setBaseGrandTotal($order->getBaseGrandTotal() - $orderData['excludeAmount']);
        $order->setGrandTotal($order->getGrandTotal() - $orderData['excludeAmount']);
        $order->setBaseTotalPaid($order->getBaseGrandTotal());
        $order->setTotalPaid($order->getGrandTotal());
        $order->setBaseTotalInvoiced($order->getBaseGrandTotal());
        $order->setTotalInvoiced($order->getGrandTotal());
        // For admin history orders Totals override object end
        $order->addStatusToHistory($order->getStatus(), 'Order recurring amount <strong>('.$this->getCurrencySymbol().$orderData['excludeAmount'].')</strong> already deducted by gateway.');
        $order->save();*/

        $recurringDate = $recurring['recurring_date'];
        if ($order->getEntityId()) {
            $this->newRecurringOrderCreated = true;

            $this->orderId = $order->getIncrementId();
            $this->orderEntityId = $order->getEntityId();

            $this->_tran->cronlog("New recurring order #" . $order->getIncrementId() . " created in magento.");

            if (!empty($this->paymentInternalId)) {
                // mark this recurring payment as applied
                $this->_tran->markRecurringPaymentAsApplied($this->paymentInternalId);

                // Updating db recurring table start
                $this->updateRecurringTable($recurring);

                // add new order recurring order
                $this->insertInRecurringOrder($recurring, 1, 'Order Added.', $order->getIncrementId(), $order->getEntityId());
            }

            $this->_tran->cronlog('End: Order saved successfully.');
        } else {
            $this->insertInRecurringOrder($recurring, 0, 'Order not saved!');

            $this->_tran->cronlog("Order not saved!");
        }
    }

    /**
     * Create Order Quote
     *
     * @param $recurring
     * @param $orderData
     * @param $savedOrderPaymentData
     * @param $customerData
     * @param $shipmentMethod
     * @return mixed
     * @throws Exception
     */
    public function createOrderQuote($recurring, $orderData, $savedOrderPaymentData, $customerData, $shipmentMethod)
    {
        $this->_tran->cronlog(__METHOD__);
        /** Assigning values of variables */
        $this->recurring = $recurring;
        $this->orderData = $orderData;
        $this->savedOrderPaymentData = $savedOrderPaymentData;
        $this->customerData = $customerData;
        $this->shipmentMethod = $shipmentMethod;

        return $this->_appState->emulateAreaCode(Area::AREA_ADMINHTML, function () {

            try {
                $recurring = $this->recurring;
                $orderData = $this->orderData;
                $savedOrderPaymentData = $this->savedOrderPaymentData;
                $customerData = $this->customerData;
                $shipmentMethod = $this->shipmentMethod;

                $paymentMethodName = (!empty($savedOrderPaymentData['method']))
                    ? $savedOrderPaymentData['method']
                    : $this->dataClass->getPaymentMethods(); // Select Magento 1st active payment method

                $paymentObject = $this->getPaymentInfo($recurring, $savedOrderPaymentData, $customerData, $paymentMethodName, $orderData['excludeAmount']);

                //---------- customer data start ----------

                $storeId = $customerData['store_id'];

                $quote = $this->quote->create(); //Create object of quote
                $quote->setStoreId($storeId); //set store id for which you create quote

                // if you have already buyer id then you can load customer directly
                $customer = $this->customerRepository->getById($customerData['entity_id']);
                $quote->setCurrency();
                $quote->assignCustomer($customer); //Assign quote to customer

                if ($maxReserveId = $this->getMaxReserveId((int)$storeId)) {
                    $quote->setReservedOrderId($maxReserveId);
                }

                //add items in quote
                foreach ($orderData['items'] as $item) {
                    $product = $this->productFactory->create()->load($item['product_id']);
                    $product->setPrice($item['price']);
                    try {
                        $quote->addProduct($product, intval($item['qty']));
                    } catch (\Exception $e) {
                        $this->_tran->cronlog('Exceptions while adding recurring item to cart: ' . $e->getMessage());
                        continue;
                    }
                }

                //Set Address to quote
                $quote->getBillingAddress()->addData($orderData['billing_address']);
                $quote->getShippingAddress()->addData($orderData['shipping_address']);

                $quote->save(); // save before shipping calculation

                // get parent order coupon code if exist.
                //$parentOrderCouponCode = isset($savedOrderPaymentData['coupon_code']) ? $savedOrderPaymentData['coupon_code'] : '';
                $recurringTableCouponCode = isset($recurring['coupon_code']) ? $recurring['coupon_code'] : '';

                // Collect Rates and Set Shipping & Payment Method
                $quote->getShippingAddress()
                    ->setCollectShippingRates(true)
                    ->setShippingMethod($shipmentMethod);
                $quote->setPaymentMethod($paymentMethodName); //payment method
                $quote->collectTotals();

                $quote->setInventoryProcessed(true); // update inventory

                // Now Save quote and your quote is ready, cupon code will be applied if added on parent order or add subscription.
                if (!empty($recurringTableCouponCode)) {
                    $quote->setCouponCode($recurringTableCouponCode)->collectTotals()->save();
                } else {
                    $quote->save();
                }

                // Set Sales Order Payment
                $quote->getPayment()->importData($paymentObject);
                // Collect Totals & Save Quote
                $quote->collectTotals()->save();

                // Create Order From Quote
                $order = $this->quoteManagement->submit($quote);

                return $order;

            } catch (LocalizedException $exception) {
                $this->_tran->cronlog(__('Exception occured during creating recurring order Error:' . $exception->getMessage()));

                return false;
            }
        });
    }

    private function getPaymentInfo($recurring, $savedOrderPaymentData, $customerData, $paymentMethodName, $excludeAmount)
    {
        $paymentMethodId = (!empty($recurring['eb_rec_method_id']))
            ? $recurring['eb_rec_method_id']
            : $savedOrderPaymentData['ebzc_method_id'];

        $customerEntityId = $customerData['entity_id'];
        $additionalData = [
            'method' => $paymentMethodName,
            'ebzc_option' => 'recurring',
            'ebzc_option_new' => 'recurring',
            'ebzc_option_existing' => isset($savedOrderPaymentData['ebzc_option']) ? $savedOrderPaymentData['ebzc_option'] : '',
            'ebzc_cust_id' => $customerData['ec_cust_token'],
            'ebzc_method_id' => $paymentMethodId,
            'ebzc_avs_street' => isset($savedOrderPaymentData['ebzc_avs_street']) ? $savedOrderPaymentData['ebzc_avs_street'] : '',
            'ebzc_avs_zip' => isset($savedOrderPaymentData['ebzc_avs_zip']) ? $savedOrderPaymentData['ebzc_avs_zip'] : '',
            'ebzc_save_payment' => false, //$savedOrderPaymentData['ebzc_save_payment'],
            'mage_cust_id' => $customerData['entity_id'],
            'excludeAmount' => $excludeAmount //$orderData['excludeAmount']
        ];

        if ($paymentMethodName == 'ebizcharge_ebizcharge') {
            $paymentObject = [
                'method' => $paymentMethodName,
                'so_number' => $recurring['mage_order_id'],
                'po_number' => $recurring['mage_order_id'],
                'mage_cust_id' => $customerEntityId,
                'additional_data' => $additionalData
            ];
        } else {
            $paymentObject = [
                'method' => $paymentMethodName,
                'so_number' => $recurring['mage_order_id'],
                'po_number' => $recurring['mage_order_id'],
                'mage_cust_id' => $customerEntityId
            ];
        }

        return $paymentObject;
    }

    /**
     * Get max reserved order id
     *
     * @param int $storeId
     * @return int|false
     */
    private function getMaxReserveId(int $storeId)
    {
        $defaultAdminStoreId = 0;
        try {
            $defaultAdminStoreMaxId = $this->sequenceManager->getSequence(
                Order::ENTITY,
                $defaultAdminStoreId
            )->getNextValue();
            $currentStoreMaxId = $this->sequenceManager->getSequence(
                Order::ENTITY,
                $storeId
            )->getNextValue();

            return $currentStoreMaxId >= $defaultAdminStoreMaxId ? $currentStoreMaxId : $defaultAdminStoreMaxId;

        } catch (Exception $e) {
            return false;
        }
    }

    protected function updateRecurringTable($recurring)
    {
        $recProcessedNew = ((int)$recurring['eb_rec_processed'] + 1);
        $recRemainingNew = ((int)$recurring['eb_rec_remaining'] - 1);
        $recNextDueDateArray = unserialize($recurring['eb_rec_due_dates']);

        $updateQueryParameters = [
            'option' => 'update',
            'tableName' => 'ebizcharge_recurring',
            'data' => [
                'eb_rec_processed' => $recProcessedNew,
                'eb_rec_next' => isset($recNextDueDateArray[$recProcessedNew]) ? $recNextDueDateArray[$recProcessedNew] : '',
                'eb_rec_remaining' => $recRemainingNew
            ],
            'where' => [
                'rec_id = ?' => $recurring['rec_id'],
                'mage_item_id = ?' => $recurring['mage_item_id']
            ]
        ];
        // Updating db recurring table end
        $this->_tran->runUpdateQuery($updateQueryParameters);
    }

    /**
     * @param $recurring
     * @param $status
     * @param $message
     * @param $orderDate
     * @param null $orderId
     * @param null $entityId
     */
    protected function insertInRecurringOrder($recurring, $status, $message, $orderId = null, $entityId = null)
    {
        $orderDate = $recurring['recurring_date'];
        $parameters = array(
            'option' => 'insert',
            'tableName' => 'ebizcharge_recurring_order',
            'data' => array(
                'recurring_id' => $recurring['rec_id'],
                'rec_order_id' => $orderId,
                'created_date' => date('Y-m-d H:i:s'),
                'order_date' => date('Y-m-d', strtotime($orderDate)),
                'status' => $status,
                'message' => $message,
                'order_entity_id' => $entityId
            )
        );

        $this->_tran->runInsertQuery($parameters);

        if ($status == 1) {
            $this->orders[] = $orderId;
        } else {
            $this->failedOrders[] = 0;
            $this->addFailedAttempts($recurring);
        }
    }

    /**
     * if the Subscription fails on the Third time it is put on Suspension.
     * @param $recurring
     */
    private function addFailedAttempts($recurring)
    {
        $failedAttempts = (int)$recurring['failed_attempts'] + 1;

        $updateQueryParameters = array(
            'option' => 'update',
            'tableName' => 'ebizcharge_recurring',
            'data' => array(
                'failed_attempts' => $failedAttempts
            ),
            'where' => array(
                'rec_id = ?' => $recurring['rec_id']
            )
        );

        // Updating db recurring table end
        $this->_tran->runUpdateQuery($updateQueryParameters);

        if ($failedAttempts > 2) {
            $this->_tran->cronlog('This is the 3rd failed attempt of recurring record# ' . $recurring['rec_id'] . ' Suspending subscription.');
            $this->_tran->suspendScheduledRecurringPaymentStatus($recurring, 1);
        }

    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return void
     */
    private function createSuccessMessage()
    {
        $message = 'No new order created';
        $numberOfOrders = count($this->orders);
        $failedOrders = count($this->failedOrders);
        if ($numberOfOrders > 0) {
            $message = $numberOfOrders . ' Order(s) are created successfully';
        }
        if ($failedOrders > 0) {
            $message .= " and $failedOrders order(s) are failed.";
        }
        $this->messageManager->addSuccessMessage($message);
    }

    /**
     * @param $orderIncrementId
     * @return mixed
     */
    public function loadMagentoOrderPaymentData($orderIncrementId)
    {
        $this->_tran->cronlog(__METHOD__);
        $orderFullData = [];

        $order = $this->dataClass->getMagentoDbData('sales_order', '*', 'increment_id', $orderIncrementId);

        if (!empty($order)) {

            $orderPaymentData = $this->dataClass->getMagentoDbData('sales_order_payment', '*', 'parent_id', $order['entity_id']);
            $orderFullData['orderData'] = $order;
            $orderFullData['orderPaymentData'] = $orderPaymentData;

            // apply coupon code: now we are using coupon from recurring table
            /*$ruleIds = isset($order['applied_rule_ids']) ? $order['applied_rule_ids'] : '';
            if (!empty($ruleIds) && !empty($order['coupon_code']) && $this->isCouponValid($ruleIds)) {
                $orderFullData['orderPaymentData']['coupon_code'] = $order['coupon_code'];
                $orderFullData['orderPaymentData']['applied_rule_ids'] = $order['applied_rule_ids'];
            }*/

        }
        return $orderFullData;
    }

    private function isCouponValid($ruleId)
    {
        $objectManager = $this->config->getObjectManagerInstance();
        $rule = $objectManager->create('Magento\SalesRule\Model\Rule')->load($ruleId);
        $currentDate = strtotime(date('Y-m-d'));
        $couponStartDate = (!empty($rule->getFromDate())) ? strtotime($rule->getFromDate()) : 0;
        $couponEndDate = (!empty($rule->getToDate())) ? strtotime($rule->getToDate()) : 0;

        return $rule->getIsActive()
            && (empty($rule->getToDate())
                || ($couponEndDate >= $currentDate) && ($couponStartDate <= $currentDate)
            );
    }

    public function getExistingOrderAddress($orderId)
    {
        $objectManager = ObjectManager::getInstance();
        $order = $objectManager->get('\Magento\Sales\Model\Order')->load($orderId);
        $orderBilling = $order->getBillingAddress()->getData();
        $orderShipping = $order->getShippingAddress()->getData();

        return [
            'billingAddress' => $this->address($orderBilling),
            'shippingAddress' => $this->address($orderShipping)
        ];
    }

    private function address($data)
    {
        return [
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'company' => $data['company'],
            'street' => $data['street'],
            'city' => $data['city'],
            'country_id' => $data['country_id'],
            'region' => $data['region'],
            'region_id' => $data['region_id'],
            'postcode' => $data['postcode'],
            'telephone' => $data['telephone'],
            'save_in_address_book' => 0,
        ];
    }

    /**
     * @param $productType
     * @param $orderShippingMethod
     * @return mixed|string
     */
    private function getShippmentforVirtualProduct($productType, $orderShippingMethod)
    {
        if ($this->isVirtualProduct($productType)) {
            $orderShippingMethod = self::FREE_SHIPPING;
        }

        return $orderShippingMethod;
    }

    /**
     * Check if product is virtual/downloadable or not
     * @param $productType
     * @return bool
     */
    private function isVirtualProduct($productType)
    {
        return in_array($productType, ['virtual', 'downloadable']);
    }

    private function getRecurringBillingAddress($billingAddressId)
    {
        if (!empty($billingAddressId)) {
            $billing = $this->dataClass->getMagentoDbData('customer_address_entity', '*', 'entity_id', $billingAddressId);
            if (!empty($billing)) {
                return $this->address($billing);
            }
        }
        return [];
    }

    private function getRecurringShippingAddress($shippingAddressId)
    {
        if (!empty($shippingAddressId)) {
            $shipping = $this->dataClass->getMagentoDbData('customer_address_entity', '*', 'entity_id', $shippingAddressId);
            if (!empty($shipping)) {
                return $this->address($shipping);
            }
        }
        return [];
    }

    /**
     * Suspend recurrings
     * @param $recurring
     * @return void
     */
    private function suspendRecurrings(array $recurringsToSuspend)
    {
        foreach ($recurringsToSuspend as $recurring) {
            // Suspend subscription on Econnect //0 Active //1 Suspended //2 Expired //3 Canceled
            $this->_tran->suspendScheduledRecurringPaymentStatus($recurring, 1);
            $this->_tran->cronlog('All recurring are completed for ' . $recurring['mage_item_name'] . '. Status is marked as suspended on gateway.');
        }
    }

    /**
     * Get simple recurring items
     * @param array $recurringsToProcess
     * @return array|mixed
     */
    private function getSimpleRecurrings(array $recurringsToProcess)
    {
        $simpleRecurrings = [];

        foreach ($recurringsToProcess as $key => $recurring) {
            if (empty($recurring['simple_recurring'])) {
                $simpleRecurrings[] = $recurring;
            } else {
                $this->bundleRecurrings[$recurring['mage_cust_id']][$recurring['mage_order_id']][$recurring['recurring_date']][] = $recurring;
            }
        }

        return $simpleRecurrings;
    }

    /**
     * Process simple recurring orders
     * @param array $simpleRecurrings
     * @param $recurringOrders
     * @return void
     */
    private function processSimpleRecurrings(array $simpleRecurrings, $recurringOrders)
    {
        foreach ($simpleRecurrings as $recurring) {
            $recurringDate = $recurring['recurring_date'];

            try {
                // if order is already created, skip it
                $orderKey = $recurring['recurring_id'] . '_' . $recurringDate;
                if (array_key_exists($orderKey, $recurringOrders)) {
                    $this->_tran->cronlog('Order is already created for recurring ' . $orderKey);
                    continue;
                }

                $magCustomerId = $recurring['mage_cust_id'];

                $this->paymentInternalId = $this->_tran->searchRecurringPayment(
                    $magCustomerId, $recurring['eb_rec_scheduled_payment_internal_id'], $recurringDate
                );

                if (empty($this->paymentInternalId)) {
                    $msg = 'Payment is not paid or failed.';
                    $this->_tran->cronlog($msg);
                    $this->insertInRecurringOrder($recurring, 0, $msg);
                    continue;
                }

                $customerData = $this->_tran->getMagentoCustomer($magCustomerId, '*');

                if (empty($customerData)) {
                    $msg = 'Error in loading customer ID(' . $magCustomerId . ')  against order (' . $recurring['mage_order_id'] . ')';
                    $this->_tran->cronlog($msg);
                    $this->insertInRecurringOrder($recurring, 0, $msg);
                    continue;
                } else {
                    $customerData = $customerData[0];
                }

                $savedShippingMethod = $recurring['shipping_method'];

                // load existing order info
                if (!empty($recurring['mage_order_id'])) {
                    $savedOrderDetails = $this->loadMagentoOrderPaymentData($recurring['mage_order_id']);
                    $savedOrderData = isset($savedOrderDetails['orderData']) ? $savedOrderDetails['orderData'] : '';
                    $savedOrderPaymentData = isset($savedOrderDetails['orderPaymentData']) ? $savedOrderDetails['orderPaymentData'] : '';

                    if (empty($savedOrderData) || empty($savedOrderPaymentData)) {
                        $msg = 'Error in loading parent saved Order (' . $recurring['mage_order_id'] . ')';
                        $this->_tran->cronlog($msg);
                        $this->insertInRecurringOrder($recurring, 0, $msg);
                        continue;
                    }

                    if (empty($savedShippingMethod)) {
                        $savedShippingMethod = $savedOrderData['shipping_method'];
                    }

                    $orderAddress = $this->getExistingOrderAddress($savedOrderData['entity_id']);
                    $savedBillingAddress = $orderAddress['billingAddress'];
                    $savedShippingAddress = $orderAddress['shippingAddress'];

                } else { // load admin subscription info
                    $savedBillingAddress = $this->getRecurringBillingAddress($recurring['billing_address_id']);
                    $savedShippingAddress = $this->getRecurringShippingAddress($recurring['shipping_address_id']);
                    $savedOrderPaymentData = [];
                }

                if (empty($savedShippingAddress)) {
                    $msg = 'Shipping address is empty or invalid.';
                    $this->_tran->cronlog($msg);
                    $this->insertInRecurringOrder($recurring, 0, $msg);
                    // Suspend subscription on Econnect //0 Active //1 Suspended //2 Expired //3 Canceled
                    //$this->_tran->suspendScheduledRecurringPaymentStatus($recurring, 1);
                    continue;
                }

                $item = $this->dataClass->loadMagentoItem($recurring['mage_item_id']);

                if (empty($item)) {
                    $msg = 'Product not found or has configurable type.';
                    $this->_tran->cronlog($msg);
                    $this->insertInRecurringOrder($recurring, 0, $msg);
                    continue;
                }

                if ((int)$item['QtyOnHand'] < (int)$recurring['qty_ordered']) {
                    $msg = "Product #" . $recurring['mage_item_id'] . ' is out of stock or saleable quantity is zero';
                    $this->insertInRecurringOrder($recurring, 0, $msg);
                    $this->_tran->cronlog($msg);
                    continue;
                }

                if (empty($savedShippingMethod)) {
                    $savedShippingMethod = $this->config->getDefaultShippingMethod($customerData['store_id'] ?? null);
                }

                $shipmentMethodActive = $this->dataClass->shippingMethodStatus($savedShippingMethod, $customerData['store_id'] ?? null);
                $shipmentMethod = $this->getShippmentforVirtualProduct($item['itemType'], $savedShippingMethod);

                if (!$shipmentMethodActive && !$this->isVirtualProduct($item['itemType'])) {
                    $storeName = $this->_storeManager->getStore($customerData['store_id'])->getName();
                    $this->_tran->cronlog('Shipping method (' . $savedShippingMethod . ') is not active in store (' . $storeName . ')');
                    $this->insertInRecurringOrder($recurring, 0, 'Shipping method (' . $savedShippingMethod . ') is not active in store (' . $storeName . ')');
                    continue;
                }

                $excludeAmount = ($recurring['qty_ordered'] * $item['itemPrice']);

                if (!empty($recurring['amount'])) {
                    $excludeAmountDb = $recurring['amount'];
                    if ($excludeAmount != $excludeAmountDb) {
                        $excludeAmount = $excludeAmountDb;
                    }
                }

                $orderData = [
                    'items' => [
                        'item' => [
                            'product_id' => $recurring['mage_item_id'],
                            'qty' => $recurring['qty_ordered'],
                            'price' => $item['itemPrice'],
                            'qtyOnHand' => $item['QtyOnHand'],
                            'itemType' => $item['itemType'],
                            'excludeAmount' => $excludeAmount
                        ]
                    ],
                    'excludeAmount' => $excludeAmount,
                    'custId' => $recurring['mage_cust_id'],
                    'currency_id' => $this->_storeManager->getStore()->getCurrentCurrencyCode(),
                    'email' => $customerData['email'],
                    'billing_address' => $savedBillingAddress,
                    'shipping_address' => $savedShippingAddress

                ];

                $dateToday = date("Y-m-d");
                $recurringDate = date("Y-m-d", strtotime($recurring['recurring_date']));

                $this->_tran->cronlog('Today = ' . $dateToday . ', Recurring due date = ' . $recurringDate);

                if (strtotime($recurringDate) <= strtotime($dateToday)) {

                    if ((int)$item['QtyOnHand'] > (int)$recurring['qty_ordered'] || in_array($item['itemType'], ['downloadable', 'virtual'])) {
                        $this->createMageOrderRecurring($recurring, $orderData, $savedOrderPaymentData, $customerData, $shipmentMethod);
                    }

                } else {
                    $this->_tran->cronlog('No recurring order is due today for recurring product #' . $recurring['mage_item_id']);
                }

            } catch (Exception $ex) {
                $msg = 'Exception: ' . $ex->getMessage();
                $this->_tran->cronlog($msg);
                $this->insertInRecurringOrder($recurring, 0, $msg);
            }

        }
    }

    /**
     * @param array $bundleRecurrings
     * @param $recurringOrder
     * @return void
     */
    private function processBunddleRecurrings(array $bundleRecurrings, $recurringOrders)
    {
        /**
         *  $customerId => recurrings related to a customer
         *  $orderId => products related to a specific order
         *  $date => recurrings related to a specific date
         *  $recurring => a record from `ebizcharge_recurring` table
         *
         * $bundleRecurrings[$customerId][$orderId][$date][]  = $recurring[];
         *
         */

        foreach ($bundleRecurrings as $recurringsforAllCustomers) {

            /** this will iterate over a specific order recurring of a customer */

            foreach ($recurringsforAllCustomers as $customerRecurrings) {

                foreach ($customerRecurrings as $recurrings) {

                    $firstRecurring = current($recurrings);

                    try {

                        $magCustomerId = $firstRecurring['mage_cust_id'];

                        $customerData = $this->_tran->getMagentoCustomer($magCustomerId, '*');

                        if (empty($customerData)) {
                            $msg = 'Error in loading customer ID(' . $magCustomerId . ')  against order (' . $firstRecurring['mage_order_id'] . ')';
                            $this->_tran->cronlog($msg);
                            $this->insertInRecurringOrder($firstRecurring, 0, $msg);
                            continue;
                        } else {
                            $customerData = $customerData[0];
                        }

                        // load existing order info
                        if (!empty($firstRecurring['mage_order_id'])) {
                            $savedOrderDetails = $this->loadMagentoOrderPaymentData($firstRecurring['mage_order_id']);
                            $savedOrderData = $savedOrderDetails['orderData'] ?? '';
                            $savedOrderPaymentData = $savedOrderDetails['orderPaymentData'] ?? '';

                            if (empty($savedOrderData) || empty($savedOrderPaymentData)) {
                                $msg = 'Error in loading parent saved Order (' . $firstRecurring['mage_order_id'] . ')';
                                $this->_tran->cronlog($msg);
                                $this->insertInRecurringOrder($firstRecurring, 0, $msg);
                                continue;
                            }

                            $orderAddress = $this->getExistingOrderAddress($savedOrderData['entity_id']);
                            $savedBillingAddress = $orderAddress['billingAddress'];
                            $savedShippingAddress = $orderAddress['shippingAddress'];

                        } else { // load admin subscription info
                            $savedBillingAddress = $this->getRecurringBillingAddress($firstRecurring['billing_address_id']);
                            $savedShippingAddress = $this->getRecurringShippingAddress($firstRecurring['shipping_address_id']);
                            $savedOrderPaymentData = [];
                        }

                        if (empty($savedShippingAddress)) {
                            $msg = 'Shipping address is empty or invalid.';
                            $this->_tran->cronlog($msg);
                            $this->insertInRecurringOrder($firstRecurring, 0, $msg);
                            // Suspend subscription on Econnect //0 Active //1 Suspended //2 Expired //3 Canceled
                            //$this->_tran->suspendScheduledRecurringPaymentStatus($recurring, 1);
                            continue;
                        }

                        $savedShippingMethod = $firstRecurring['shipping_method'];

                        if (empty($savedShippingMethod)) {
                            $savedShippingMethod = $savedOrderData['shipping_method'];
                        }


                        if (empty($savedShippingMethod)) {
                            $savedShippingMethod = $this->config->getDefaultShippingMethod($customerData['store_id'] ?? null);
                        }

                        $shipmentMethodActive = $this->dataClass->shippingMethodStatus($savedShippingMethod, $customerData['store_id'] ?? null);
                        $shipmentMethod = $savedShippingMethod;

                        if (!$shipmentMethodActive) {
                            $storeName = $this->_storeManager->getStore($customerData['store_id'])->getName();
                            $this->_tran->cronlog('Shipping method (' . $savedShippingMethod . ') is not active in store (' . $storeName . ')');
                            $this->insertInRecurringOrder($firstRecurring, 0, 'Shipping method (' . $savedShippingMethod . ') is not active in store (' . $storeName . ')');
                            continue;
                        }

                        $orderData = [
                            'custId' => $firstRecurring['mage_cust_id'],
                            'currency_id' => $this->_storeManager->getStore()->getCurrentCurrencyCode(),
                            'email' => $customerData['email'],
                            'billing_address' => $savedBillingAddress,
                            'shipping_address' => $savedShippingAddress

                        ];

                        $finalExcludeAmount = 0;

                        $freeShipping = false;

                        $processedRecurrings = [];

                        $productsAvailableForOrder = false;

                        foreach ($recurrings as $key => $recurring) {

                            $recurringDate = $recurring['recurring_date'];
                            // if order is already created, skip it
                            $orderKey = $recurring['recurring_id'] . '_' . $recurringDate;
                            if (array_key_exists($orderKey, $recurringOrders)) {
                                $this->_tran->cronlog('Order is already created for recurring ' . $orderKey);
                                continue;
                            }

                            $item = $this->dataClass->loadMagentoItem($recurring['mage_item_id']);

                            if (empty($item)) {
                                $msg = 'Product not found or has configurable type.';
                                $this->_tran->cronlog($msg);
                                $this->insertInRecurringOrder($recurring, 0, $msg);
                                continue;
                            }

                            if ((int)$item['QtyOnHand'] < (int)$recurring['qty_ordered']) {
                                $msg = "Product #" . $recurring['mage_item_id'] . ' is out of stock or saleable quantity is zero';
                                $this->insertInRecurringOrder($recurring, 0, $msg);
                                $this->_tran->cronlog($msg);
                                continue;
                            }

                            $paymentInternalId = $this->_tran->searchRecurringPayment(
                                $magCustomerId, $recurring['eb_rec_scheduled_payment_internal_id'], $recurring['recurring_date']
                            );

                            if (empty($paymentInternalId)) {
                                $msg = 'Payment is not paid or failed.';
                                $this->_tran->cronlog($msg);
                                $this->insertInRecurringOrder($recurring, 0, $msg);
                                continue;
                            }

                            $recurring['mark_as_applied'] = $paymentInternalId;

                            $processedRecurrings[] = $recurring;


                            if ($freeShipping && $this->isVirtualProduct($item['itemType'])) {
                                $freeShipping = true;
                            } else {
                                $freeShipping = false;
                            }

                            if ((int)$item['QtyOnHand'] > (int)$recurring['qty_ordered'] || in_array($item['itemType'], ['downloadable', 'virtual'])) {

                                $excludeAmount = ($recurring['qty_ordered'] * $item['itemPrice']);

                                if (!empty($recurring['amount'])) {
                                    $excludeAmountDb = $recurring['amount'];
                                    if ($excludeAmount != $excludeAmountDb) {
                                        $excludeAmount = $excludeAmountDb;
                                    }
                                }

                                $finalExcludeAmount = $finalExcludeAmount + $excludeAmount;

                                $orderData['items'][] = [
                                    'product_id' => $recurring['mage_item_id'],
                                    'qty' => $recurring['qty_ordered'],
                                    'price' => $item['itemPrice'],
                                    'qtyOnHand' => $item['QtyOnHand'],
                                    'itemType' => $item['itemType'],
                                    'excludeAmount' => $excludeAmount
                                ];

                                $productsAvailableForOrder = true;

                            }
                        }

                        if ($freeShipping) {
                            $shipmentMethod = self::FREE_SHIPPING;
                        }

                        $orderData['excludeAmount'] = $finalExcludeAmount;

                        try {

                            if ($productsAvailableForOrder) {

                                /** resetting previous iteration values to default for safety purpose */
                                $this->paymentInternalId = false;
                                $this->orderEntityId = null;
                                $this->orderId = null;

                                $this->createMageOrderRecurring($firstRecurring, $orderData, $savedOrderPaymentData, $customerData, $shipmentMethod);

                                if ($this->newRecurringOrderCreated) {
                                    foreach ($processedRecurrings as $recurring) {
                                        $this->updateRecurringTable($recurring);
                                        $this->insertInRecurringOrder($recurring, 1, 'Order Added.', $this->orderId, $this->orderEntityId);
                                        $this->_tran->markRecurringPaymentAsApplied($recurring['mark_as_applied']);
                                    }
                                }

                            }

                        } catch (\Exception $e) {
                            $msg = 'Exception while creating recurring order: ' . $e->getMessage();
                            $this->_tran->cronlog($msg);
                            $this->insertInRecurringOrder($firstRecurring, 0, $msg);
                        }

                    } catch (Exception $ex) {
                        $msg = 'Exception: ' . $ex->getMessage();
                        $this->_tran->cronlog($msg);
                        $this->insertInRecurringOrder($firstRecurring, 0, $msg);
                    }
                }
            }
        }

    }
}
