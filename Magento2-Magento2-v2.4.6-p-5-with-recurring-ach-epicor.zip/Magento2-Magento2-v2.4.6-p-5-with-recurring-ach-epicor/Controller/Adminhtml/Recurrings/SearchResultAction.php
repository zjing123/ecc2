<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;

class SearchResultAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;
    protected $_resources;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\UrlInterface $url
    ) {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;
        $this->_resultFactory = $context->getResultFactory();
        $this->resultPageFactory = $resultPageFactory;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    /**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
        $cid = $this->getRequest()->getParam('cid');
        $sDate = $this->getRequest()->getParam('start_date');
        $eDate = $this->getRequest()->getParam('expire_date');

        try {
            $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
                ->get('Magento\Framework\App\ResourceConnection');
            $connection = $this->_resources->getConnection();
            $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
            $datesTable = $this->_resources->getTableName('ebizcharge_recurring_dates');
            $customerTable = $this->_resources->getTableName('customer_entity');
            $productTable = $this->_resources->getTableName('catalog_product_entity');

            $condition = "";
            $str = "";
            if ($cid != "") {
                $condition .= " and r.mage_cust_id = $cid";
            }

            if ($sDate != "") {
                $condition .= " and d.recurring_date >='" . $sDate . "'";
            }
            if ($eDate != "") {
                $condition .= " and d.recurring_date <='" . $eDate . "'";
            }

            $sql = "Select * FROM " . $recurringTable . " as r
            INNER JOIN " . $datesTable . " as d on d.recurring_id = r.rec_id
            INNER JOIN " . $customerTable . " as c on c.entity_id = r.mage_cust_id
			INNER JOIN " . $productTable . " as p on p.entity_id = r.mage_item_id
            WHERE r.rec_status = 0 $condition ORDER BY d.recurring_date";

            $recurrings = $connection->fetchall($sql);

            if ($recurrings && count($recurrings) > 0) {
                foreach ($recurrings as $recurring) {
                    $parentSubscriptionLink = $this->url->getUrl(
                        'ebizcharge_ebizcharge/recurrings/editaction',
                        [
                        'mid' => $recurring['eb_rec_scheduled_payment_internal_id'],
                        'magcid' => $recurring['mage_cust_id']
                    ]
                    );
                    $linkTag = '<a href="' . $parentSubscriptionLink . '" target="_blank"> Manage </a>';
                    $id = $recurring['mage_cust_id'];
                    $name = $recurring['firstname'] . ' ' . $recurring['lastname'];
                    $email = $recurring['email'];
                    $item = $recurring['mage_item_name'];
                    $status = 'Active';
                    $frequency = ucfirst($recurring['eb_rec_frequency']);

                    $billingAddressId = !empty($recurring['billing_address_id']) ? trim($recurring['billing_address_id']) : '';
                    $shippingAddressId = !empty($recurring['shipping_address_id']) ? trim($recurring['shipping_address_id']) : '';

                    if (!empty($billingAddressId)) {
                        $billingAddress = $this->getCustomerAddress($connection, $billingAddressId);
                        $shippingAddress = $billingAddress;

                        if (!empty($shippingAddressId) && $billingAddressId != $shippingAddressId) {
                            $shippingAddress = $this->getCustomerAddress($connection, $shippingAddressId);
                        }
                    } else {
                        $billingAddress = $this->getOrderAddress($recurring['mage_order_id'], 'billing', $connection);
                        $shippingAddress = $this->getOrderAddress($recurring['mage_order_id'], 'shipping', $connection);
                    }

                    $na = 'N/A';
                    $date = $recurring['recurring_date'];
                    $sku = isset($recurring['sku']) ? $recurring['sku'] : $na;
                    $qty = isset($recurring['qty_ordered']) ? $recurring['qty_ordered'] : $na;
                    $bStreet = isset($billingAddress['street']) ? $billingAddress['street'] : $na;
                    $bCity = isset($billingAddress['city']) ? $billingAddress['city'] : $na;
                    $bRegion = isset($billingAddress['region']) ? $billingAddress['region'] : $na;
                    $bPostCode = isset($billingAddress['postcode']) ? $billingAddress['postcode'] : $na;
                    $sStreet = isset($shippingAddress['street']) ? $shippingAddress['street'] : $na;
                    $sCity = isset($shippingAddress['city']) ? $shippingAddress['city'] : $na;
                    $sRegion = isset($shippingAddress['region']) ? $shippingAddress['region'] : $na;
                    $sPostCode = isset($shippingAddress['postcode']) ? $shippingAddress['postcode'] : $na;

                    $str .= "<tr><td>$linkTag</td><td>$date</td><td>$name</td><td>$id</td><td>$email</td><td>$sku</td>
                            <td>$item</td><td>$frequency</td><td>$qty</td><td>$status</td>
							<td>$bStreet</td><td>$bCity</td><td>$bRegion</td><td>$bPostCode</td>
							<td>$sStreet</td><td>$sCity</td><td>$sRegion</td><td>$sPostCode</td>
							</tr>";
                }
                echo $str;
                die();
            } else {
                $error = 'No Record Found.';
                echo $str = "<tr><td colspan='17' align='center' style='color: red;'>$error</td></tr>";
                die();
            }
        } catch (\Exception $e) {
            $this->_tran->log(__METHOD__ . $e->getMessage());
            //return $this->createErrorResponse(self::ACTION_EXCEPTION);
        }

        return $this->createSuccessMessage();
    }

    private function getCustomerAddress($connection, $addressId)
    {
        $addressCustomerTable = $this->_resources->getTableName('customer_address_entity');
        $sql = "Select entity_id, street, city, postcode, region FROM " . $addressCustomerTable . " WHERE entity_id= " . $addressId;

        return $this->fetchAddress($connection, $sql);
    }

    private function getOrderAddress($orderId, $addressType, $connection)
    {
        $addressTable = $this->_resources->getTableName('sales_order_address');
        $sql = "Select * FROM " . $addressTable . " WHERE address_type = '" . $addressType . "' and parent_id  = " . $orderId;

        return $this->fetchAddress($connection, $sql);
    }

    private function fetchAddress($connection, $sql)
    {
        $address = "N/A";
        $result = $connection->fetchall($sql);
        if (!empty($result) && count($result) > 0) {
            return $result[0];
        }

        return $address;
    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(
            $this->errorsMap[$errorCode]
        );

        return $this->_redirect('ebizcharge_ebizcharge/recurrings/search');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage()
    {
        $this->messageManager->addSuccessMessage(__("Subscription successfully"));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings/search');
    }
}
