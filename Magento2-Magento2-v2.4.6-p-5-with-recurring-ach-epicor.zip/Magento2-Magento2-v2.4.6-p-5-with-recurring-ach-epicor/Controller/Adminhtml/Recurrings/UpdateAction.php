<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;

class UpdateAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    public function execute()
    {
        $redirectUrl = null;
        $recurringId = $this->getRequest()->getParam('table_rec_id');
        $custIntId = $this->getRequest()->getParam('custIntId');
        $schedulePaymentInternalId = $this->getRequest()->getParam('mid');
        $oldMethodId = $this->getRequest()->getParam('eb_rec_method_id');
        $paymentMethodName = !empty($this->getRequest()->getParam('payment_method_name')) ? trim($this->getRequest()->getParam('payment_method_name')) : '';
        $shippingMethod = !empty($this->getRequest()->getParam('shipping_method')) ? trim($this->getRequest()->getParam('shipping_method')) : '';
        $coupon = $this->getRequest()->getParam('coupon');
        $shippingId = !empty($this->getRequest()->getParam('addressShip')) ? trim($this->getRequest()->getParam('addressShip')) : '';
        $billingId = !empty($this->getRequest()->getParam('addressBill')) ? trim($this->getRequest()->getParam('addressBill')) : '';
        $addNewForm = $this->getRequest()->getParam('payment');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        if ((isset($addNewForm['ebzc_option_type'])) || (!empty($addNewForm['ebzc_option_type']))) {
            $paymentTypes = $objectManager->get('\Magento\Payment\Model\Config')->getCcTypes();

            $ebizOptionType = $addNewForm['ebzc_option_type'] ?? '';

            if ($ebizOptionType == 'credit_card') {
                $cardOptionType = $addNewForm['card_option_type'] ?? '';

                if ($cardOptionType == 'card_new') {
                    $cardType = $addNewForm['cc_type'] ?? '';

                    $cardType = $paymentTypes[$cardType] ?? $cardType;

                    $cardExpiration = $addNewForm['cc_exp_year'] . "-" . $addNewForm['cc_exp_month'];

                    if ((isset($addNewForm['cc_cid'])) || (!empty($addNewForm['cc_cid']))) {
                        $cc_cid = $addNewForm['cc_cid'];
                    } else {
                        $cc_cid = '';
                    }

                    $paymentMethodName = $cardType . ' ' . substr($addNewForm['cc_number'], -4) . ' - ' . $addNewForm['cc_owner'];
                    $paymentParameters = array(
                        'MethodName' => $paymentMethodName,
                        'AccountHolderName' => $addNewForm['cc_owner'],
                        'SecondarySort' => 1,
                        'Created' => date('Y-m-d\TH:i:s'),
                        'Modified' => date('Y-m-d\TH:i:s'),
                        'CardCode' => $cc_cid,
                        'CardExpiration' => $cardExpiration,
                        'CardNumber' => $addNewForm['cc_number'],
                        'CardType' => $addNewForm['cc_type'],
                        'Balance' => 0,
                        'MaxBalance' => 0,
                        'AvsStreet' => $addNewForm['avs_street'] ?? '',
                        'AvsZip' => $addNewForm['avs_zip'] ?? ''
                    );

                    $methodId = $this->addCustomerPaymentMethod($custIntId, $paymentParameters);

                } elseif ($cardOptionType == 'card_saved') {
                    $paymentMethodName = $this->getRequest()->getParam('payment_method_name');
                    $methodId = $this->getRequest()->getParam('method_id');
                }

            } elseif ($ebizOptionType == 'ACH') {
                $bankOptionType = $addNewForm['bank_option_type'] ?? '';

                if ($bankOptionType == 'bank_new') {
                    $methodOfPayment = $this->addNewPaymentAccount($custIntId, $addNewForm);
                    $methodId = $methodOfPayment[0] ?? '';
                    $paymentMethodName = $methodOfPayment[1] ?? 'NA';

                } elseif ($bankOptionType == 'bank_saved') {
                    $methodId = $this->getRequest()->getParam('method_id_ach');
                    $paymentMethodName = $this->getRequest()->getParam('payment_method_name');
                }

            } else {
                return $this->createErrorResponse('Unable to add payment method.');
            }
        }

        if ($schedulePaymentInternalId && !empty($methodId)) {
            $ueSecurityToken = $this->_tran->getUeSecurityToken();
            $client = $this->_tran->soapClient;

            try {
                $qty = $this->getRequest()->getParam('qty');
                $customerId = $this->getRequest()->getParam('mageCustId');
                $productId = $this->getRequest()->getParam('item_id');

                // 1st priority - tier price, 2nd - special price, 3rd - orignal price
                $dataClass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
                $tierPrice = $dataClass->getProductPriceWithTierGroup($productId, $customerId, $qty);
                $amount = $tierPrice['productPrice'];

                $schedule = !empty($this->getRequest()->getParam('schedule')) ? $this->getRequest()->getParam('schedule') : '';
                $rec_indefinitely = $this->getRequest()->getParam('rec_indefinitely');

                $start = $this->getRequest()->getParam('start_date');
                $expire = $this->getRequest()->getParam('expire_date');
                $scheduleName = !empty($this->getRequest()->getParam('schedulename')) ? $this->getRequest()->getParam('schedulename') : '';
                $receiptNote = $this->getRequest()->getParam('receiptnote');

                if ($qty == 0) {
                    $qty = 1;
                }

                if (!empty($start)) {
                    $start = date("Y-m-d", strtotime($start));
                }

                if ($rec_indefinitely == 1) {
                    $expire = date('Y-m-d', strtotime('+10 years'));
                } else {
                    $rec_indefinitely = 0;
                    if (!empty($expire)) {
                        $expire = date("Y-m-d", strtotime($expire));
                    } else {
                        $expire = date('Y-m-d', strtotime('+10 years'));
                    }
                }

                // update payment method only when there is a changes
                $paymentMethodProfileStatus = 1;
                if (!empty($methodId) && $oldMethodId !== $methodId) {
                    $paymentMethodProfileStatus = $this->_tran->modifyRecurringPaymentMethod($methodId, $schedulePaymentInternalId);
                }

                $amount = number_format((float)trim($amount * $qty), 2, '.', '');

                $recurringBilling = array(
                    'Amount' => $amount,
                    'Enabled' => true,
                    'Start' => trim($start),
                    'Expire' => trim($expire),
                    'Next' => trim($expire),
                    'Schedule' => trim($schedule),
                    'ScheduleName' => trim($scheduleName),
                    'ReceiptNote' => $receiptNote,
                    'ReceiptTemplateName' => false,
                    'SendCustomerReceipt' => true
                );
                $recurringObject = array(
                    'securityToken' => $ueSecurityToken,
                    'scheduledPaymentInternalId' => trim($schedulePaymentInternalId),
                    'recurringBilling' => $recurringBilling
                );

                $modifyScheduled = $client->ModifyScheduledRecurringPayment_RecurringBilling($recurringObject);

                if (isset($modifyScheduled->ModifyScheduledRecurringPayment_RecurringBillingResult) && $paymentMethodProfileStatus == 1) {
                    ///////////////// update table/////////////
                    $recurringDates = $this->_tran->getRecurringScheduledDates(trim($schedulePaymentInternalId));
                    $recurringDatesSerialize = serialize($recurringDates);
                    $totalRecurrings = count($recurringDates);

                    $nextRecurringDate = $this->_tran->getNextRecurringDate($recurringDates);

                    $resource = \Magento\Framework\App\ObjectManager::getInstance()
                        ->get('Magento\Framework\App\ResourceConnection');
                    $connection = $resource->getConnection();

                    $negotiateTable = $resource->getTableName('ebizcharge_recurring');

                    $sqlu = "update " . $negotiateTable . " set
                    simple_recurring = IF(shipping_method='$shippingMethod' AND shipping_address_id='$shippingId', simple_recurring, 0),
					rec_indefinitely = " . $rec_indefinitely . ",
					eb_rec_frequency = '" . $schedule . "',
					qty_ordered = $qty,
					eb_rec_start_date = '" . trim($start) . "',
					eb_rec_end_date = '" . trim($expire) . "',
					eb_rec_method_id = $methodId,
					eb_rec_total = $totalRecurrings,
					eb_rec_processed = '0',
					eb_rec_next = '$nextRecurringDate',
					eb_rec_remaining = $totalRecurrings,
					eb_rec_due_dates = '$recurringDatesSerialize',
					amount = $amount,
					coupon_code = '$coupon',
					payment_method_name = '" . trim($paymentMethodName) . "',
					shipping_method = '" . $shippingMethod . "',
					billing_address_id = $billingId,
					shipping_address_id = $shippingId
					WHERE eb_rec_scheduled_payment_internal_id = '" . $schedulePaymentInternalId . "'";

                    $result1 = $connection->query($sqlu);

                    $this->_tran->insertScheduleDates($recurringId, $recurringDates);

                    return $this->createSuccessMessage('Subscription changes successfully saved.');
                }

                return $this->createErrorResponse('Unable to update changes.');

            } catch (\Exception $ex) {
                //return $this->createErrorResponse(self::ACTION_EXCEPTION);
                return $this->createErrorResponse('Exception: ' . $ex->getMessage());
            }

        } else {
            return $this->createErrorResponse('Subscription changes successfully not saved. Unable to find the payment method ID.');
        }
    }

    /**
     * @param $customerInternalId
     * @param $addNewForm
     * @return array
     */
    private function addNewPaymentAccount($customerInternalId, $addNewForm)
    {
        $paymentMethodName = $addNewForm['cc_type_ach'] . ' ' . substr($addNewForm['cc_number_ach'], -4) . ' - ' . $addNewForm['cc_owner_ach'];
        $paymentParameters = array(
            'MethodName' => $paymentMethodName,
            'Created' => date('Y-m-d\TH:i:s'),
            'Modified' => date('Y-m-d\TH:i:s'),
            'Account' => $addNewForm['cc_number_ach'],
            'AccountType' => $addNewForm['cc_type_ach'],
            'AccountHolderName' => isset($addNewForm['cc_owner_ach']) ? $addNewForm['cc_owner_ach'] : '',
            'Routing' => $addNewForm['cc_routing_ach'],
            'MethodType' => 'ACH'
        );

        $methodId = $this->addCustomerPaymentMethod($customerInternalId, $paymentParameters);

        return [$methodId, $paymentMethodName];
    }

    /**
     * @param $customerInternalId
     * @param $parameters
     * @return ResponseInterface|string|null
     */
    private function addCustomerPaymentMethod($customerInternalId, $parameters)
    {
        try {
            $paymentMethodId = $this->_tran->addCustomerPaymentMethod($customerInternalId, $parameters);

            if ($paymentMethodId !== null) {
                $this->createSuccessMessage('Payment method successfully saved.');
                return $paymentMethodId;
            } else {
                $this->createSuccessMessage('Unable to save the payment method.');
            }

        } catch (\Exception $ex) {
            return $this->createErrorResponse('Exception: ' . $ex->getMessage());
        }
    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(__($errorCode));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage($type)
    {
        $this->messageManager->addSuccessMessage(__($type));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }
}
