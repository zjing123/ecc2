<?php
declare(strict_types=1);
/**
 * @author  Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Ebizcharge\Ebizcharge\Model\Data;
use Ebizcharge\Ebizcharge\Observer\EpiCoreAccount;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultFactory;

/**
 * Load customer address, process erp account
 * Class EpiCoreAccount
 * @package Ebizcharge\Ebizcharge\Observer\EpiCoreAccount
 */
class LoadCustomerAddressAction extends Action implements HttpPostActionInterface
{
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var EpiCoreAccount
     */
    private $epiCoreAccount;

    /**
     * @var Data
     */
    private $ebizData;

    /**
     * @var JsonFactory
     */
    private $jsonFactory;

    /**
     * @param JsonFactory $jsonFactory
     * @param ResultFactory $resultFactory
     * @param Context $context
     * @param Data $ebizData
     * @param CustomerRepositoryInterface $customerRepository
     * @param EpiCoreAccount $epiCoreAccount
     */
    public function __construct(
        JsonFactory $jsonFactory,
        ResultFactory $resultFactory,
        Context $context,
        Data $ebizData,
        CustomerRepositoryInterface $customerRepository,
        EpiCoreAccount $epiCoreAccount
    ) {
        parent::__construct($context);
        $this->customerRepository = $customerRepository;
        $this->epiCoreAccount = $epiCoreAccount;
        $this->ebizData = $ebizData;
        $this->resultFactory = $resultFactory;
        $this->jsonFactory = $jsonFactory;
    }


    public function execute()
    {
        $post = $this->getRequest()->getPost();
        $customerId = $post['customer_id'] ?? '';
        $addresses = $this->ebizData->getCustomerAddressList($customerId);
        $customer = $this->customerRepository->getById($customerId);
        $this->epiCoreAccount->processErpCustomer($customer);

        return $this->jsonFactory->create()->setData(['html_data' => $addresses]);
    }

}
