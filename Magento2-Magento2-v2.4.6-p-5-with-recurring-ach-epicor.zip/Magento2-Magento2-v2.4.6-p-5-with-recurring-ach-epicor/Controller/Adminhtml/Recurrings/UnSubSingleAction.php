<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\App\RequestInterface;

class UnsubsingleAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    private $token;
    protected $_tran;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Session $customerSession
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param PaymentTokenRepositoryInterface $tokenRepository
     * @param PaymentTokenManagement $paymentTokenManagement
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        JsonFactory $jsonFactory,
        Validator $fkValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->token = $token;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;
        $this->_scopeConfig = $scopeConfig;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Deletion failure. Please try again.')];
    }

    /**
     * Deletes customer's payment method.
     *
     * @return ResultInterface|ResponseInterface
     * @throws NotFoundException
     */
    public function execute()
    {
        $request = $this->_request;
        if (!$request instanceof Http) {
            return $this->createErrorResponse(self::WRONG_REQUEST);
        }

        if (!$this->fkValidator->validate($request)) {
            return $this->createErrorResponse(self::WRONG_REQUEST);
        }

        $mid = $this->getRequest()->getParam('mid');
        $sid = $this->getRequest()->getParam('sid');

        try {
            //0 Active //1 Suspended //2 Expired //3 Canceled

            if (!empty($mid)) {

                $params = array(
                    'securityToken' => $this->_tran->getUeSecurityToken(),
                    'scheduledPaymentInternalId' => $mid,
                    'statusId' => $sid,
                );

                $res = $this->_tran->soapClient->ModifyScheduledRecurringPaymentStatus($params);
                $recurringPaymentStatusResult = $res->ModifyScheduledRecurringPaymentStatusResult;

                if (!empty($recurringPaymentStatusResult))
                    if ($recurringPaymentStatusResult->StatusCode == 1) {
                        $resource = \Magento\Framework\App\ObjectManager::getInstance()
                            ->get('Magento\Framework\App\ResourceConnection');
                        $connection = $resource->getConnection();
                        $negotiateTable = $resource->getTableName('ebizcharge_recurring');
                        $sqlu = "update " . $negotiateTable . " set rec_status =" . $sid . " WHERE eb_rec_scheduled_payment_internal_id = '" . trim($mid) . "'";
                        $result = $connection->query($sqlu);
                    }
            }

        } catch (\Exception $e) {
            return $this->createErrorResponse(self::ACTION_EXCEPTION);
        }

        return $this->createSuccessMessage($sid);
    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(
            $this->errorsMap[$errorCode]);

        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage($id)
    {
        $str = $id == 0 ? "Resubscribed" : "Suspended";

        $this->messageManager->addSuccessMessage(__("Successfully $str."));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }
}
