<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class CustomerSearch extends Action implements HttpPostActionInterface
{
    /**
     * @var \Ebizcharge\Ebizcharge\Block\Admin\RecurringsAdmin
     */
    private $customerSearch;

    /**
     * @var RequestInterface
     */
    private $request;

    private $jsonFactory;

    /**
     * @param RequestInterface $request
     * @param Context $context
     * @param \Ebizcharge\Ebizcharge\Block\Admin\RecurringsAdmin $customerSearch
     */
    public function __construct(
        JsonFactory $jsonFactory,
        RequestInterface $request,
        Context $context,
        \Ebizcharge\Ebizcharge\Block\Admin\RecurringsAdmin $customerSearch
    ) {
        parent::__construct($context);
        $this->customerSearch = $customerSearch;
        $this->request = $request;
        $this->jsonFactory = $jsonFactory;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $searchKeywords['keywords'] = $this->request->getParam('keywords');

        $foundCustomers = $this->customerSearch->getCustomerSuggestions($searchKeywords);
        return $this->jsonFactory->create()->setData(['customers' => $foundCustomers]);

    }
}
