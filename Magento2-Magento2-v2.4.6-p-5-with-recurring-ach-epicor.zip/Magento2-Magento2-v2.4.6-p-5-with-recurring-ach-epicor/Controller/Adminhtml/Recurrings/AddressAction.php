<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\NotFoundException;

class AddressAction extends \Magento\Framework\App\Action\Action
{
    const WRONG_REQUEST = 1;
    const WRONG_TOKEN = 2;
    const ACTION_EXCEPTION = 3;

    private $errorsMap = [];
    private $jsonFactory;
    private $fkValidator;
    protected $_tran;
    protected $responseFactory;
    protected $url;

    /**
     * @param Context $context
     * @param JsonFactory $jsonFactory
     * @param Validator $fkValidator
     * @param \Ebizcharge\Ebizcharge\Model\TranApi $tranApi
     * @param \Magento\Framework\App\ResponseFactory $responseFactory
     * @param \Magento\Framework\UrlInterface $url
     */
    public function __construct(
        Context                                $context,
        JsonFactory                            $jsonFactory,
        Validator                              $fkValidator,
        \Ebizcharge\Ebizcharge\Model\TranApi   $tranApi,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface        $url
    )
    {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->fkValidator = $fkValidator;
        $this->_tran = $tranApi;
        $this->responseFactory = $responseFactory;
        $this->url = $url;

        $this->errorsMap = [
            self::WRONG_TOKEN => __('No token found.'),
            self::WRONG_REQUEST => __('Wrong request.'),
            self::ACTION_EXCEPTION => __('Failure. Please try again.')];
    }


    public function execute()
    {
        $this->_tran->log("Subscription Save Action...");
        $post = $this->getRequest()->getPost();
        $customerId = $post['customerIdAddress'];

        if (!empty($customerId)) {
            try {
                $street = join(' ', array_filter(array($post['ship_address1'], $post['ship_address2'], $post['ship_address3'])));
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $region = $objectManager->create('Magento\Directory\Model\Region')->load($post['ship_region']);
                $shippingAddressQueryParameters = array(
                    'option' => 'insert',
                    'tableName' => 'customer_address_entity',
                    'data' => array(
                        'firstname' => $post['ship_first_name'],
                        'lastname' => $post['ship_last_name'],
                        'company' => $post['ship_company'],
                        'parent_id' => $customerId,
                        'telephone' => $post['ship_phone'],
                        'street' => $street,
                        'city' => $post['ship_city'],
                        'region_id' => $post['ship_region'],
                        'region' => $region->getName(),
                        'postcode' => $post['ship_zipcode'],
                        'country_id' => $post['ship_country']
                    )
                );
                $this->_tran->runInsertQuery($shippingAddressQueryParameters);
                echo '1';
            } catch (\Exception $ex) {
                //return $this->createErrorResponse(self::ACTION_EXCEPTION);
                //return $this->createErrorResponse('Exception: ' . $ex->getMessage());
                echo '0';

            }
        } else {
            //return $this->createErrorResponse('Unable to find Customer');
            echo '0';
        }
    }


    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(__($errorCode));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage($type)
    {
        $this->messageManager->addSuccessMessage(__($type));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }
}
