<?php
/**
 * Deletes the customer's saved payment method.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Recurrings;

use Magento\Framework\App\Action\Context;

class SaveAction extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Ebizcharge\Ebizcharge\Model\TranApi
     */
    private $tranApi;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $productFactory;

    public function __construct(
        Context $context,
        \Ebizcharge\Ebizcharge\Model\TranApi  $tranApi,
        \Magento\Catalog\Model\ProductFactory $productFactory
    ) {
        parent::__construct($context);
        $this->tranApi = $tranApi;
        $this->productFactory = $productFactory;
    }

    private function getNameById($id)
    {
        return $this->productFactory->create()->load($id)->getName();
    }

    public function execute()
    {
        $this->tranApi->log("Subscription Save Action...");

        $post = $this->getRequest()->getPost();

        $customerId = $post['customer_id'] ?? '';

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $dataClass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
        $customerInternalId = $dataClass->getMappedAndAddCustomer($customerId, true);

        if (isset($post['method_id'])) {
            $paymentMethodId = $post['method_id'];
        }

        $paymentMethodName = '';
        if (isset($post['payment_method_name'])) {
            $paymentMethodName = $post['payment_method_name'];
        }

        $addNewForm = $this->getRequest()->getParam('payment');

        if ((isset($addNewForm['ebiz_option'])) || (!empty($addNewForm['ebiz_option'])) && (empty($addNewForm['method_id']))) {

            if (($addNewForm['ebzc_option_type'] == 'credit_card') && ($addNewForm['card_option_type'] == 'card_new')) {
                list($paymentMethodId, $paymentMethodName) = $this->addNewPaymentMethod($customerInternalId, $addNewForm);
            }

            if (($addNewForm['ebzc_option_type'] == 'ACH') && ($addNewForm['bank_option_type'] == 'bank_new')) {
                list($paymentMethodId, $paymentMethodName) = $this->addNewPaymentAccount($customerInternalId, $addNewForm);
            }
        }

        if (!empty($paymentMethodId) && !empty($customerInternalId)) {

            $ueSecurityToken = $this->tranApi->getUeSecurityToken();

            try {
                $shippingMethod = $post['shipping_method'];
                $productId = $post['product_id'];
                // 1st priority - tier price, 2nd - special price, 3rd - orignal price
                $tierPrice = $dataClass->getProductPriceWithTierGroup($productId, $customerId, $post['qty']);
                $productPrice = $tierPrice['productPrice'];
                $productName = $this->getNameById($productId);
                $amountGross = ($productPrice * $post['qty']);
                $amount = number_format((float)$amountGross, 2, '.', '');

                $schedule = $post['schedule'];
                $recIndefinitely = isset($post['rec_indefinitely']) ? 1 : 0;
                $qty = $post['qty'];
                $start = $post['start_date'] ?? '';
                $expire = $post['expire_date'] ?? '';
                $scheduleName = $productId . '-' . $customerId . '-' . $schedule . '-' . $paymentMethodId;

                if (empty($qty)) {
                    $qty = 1;
                }

                if (!empty($start)) {
                    $start = date("Y-m-d", strtotime($start));
                }

                if ($recIndefinitely == 1) {
                    $expire = date('Y-m-d', strtotime('+10 years'));
                } else {
                    $recIndefinitely = 0;

                    if (!empty($expire)) {
                        $expire = date("Y-m-d", strtotime($expire));
                    } else {
                        $expire = date('Y-m-d', strtotime('+10 years'));
                    }
                }

                $recurringBilling = array(
                    'Amount' => $amount,
                    'Enabled' => true,
                    'Start' => $start,
                    'Expire' => $expire,
                    'Next' => $expire,
                    'Schedule' => $schedule,
                    'ScheduleName' => $scheduleName,
                    'ReceiptNote' => 'Item [' . $productId . '-' . $productName . '] recurring payment added.',
                    'ReceiptTemplateName' => false,
                    'SendCustomerReceipt' => true
                );

                $addRecurrParameters = array(
                    'securityToken' => $ueSecurityToken,
                    'customerInternalId' => $customerInternalId,
                    'paymentMethodProfileId' => $paymentMethodId,
                    'recurringBilling' => $recurringBilling
                );

                $transaction = $this->tranApi->soapClient->ScheduleRecurringPayment($addRecurrParameters);
                $scheduledPaymentInternalId = $transaction->ScheduleRecurringPaymentResult;

                if (!empty($scheduledPaymentInternalId)) {
                    $this->tranApi->log('Recurring Payment added for Item #[' . $productId . ']-' . $scheduledPaymentInternalId);

                    $recurringDates = $this->tranApi->getRecurringScheduledDates($scheduledPaymentInternalId);
                    $recurringDatesSerialize = serialize($recurringDates);
                    $ebzRecurringTotal = count($recurringDates);

                    $insertQueryParameters = array(
                        'option' => 'insert',
                        'tableName' => 'ebizcharge_recurring',
                        'data' => array(
                            'rec_status' => 0,
                            'rec_indefinitely' => $recIndefinitely,
                            'mage_cust_id' => $customerId,
                            'mage_order_id' => '0',
                            'mage_item_id' => $productId,
                            'mage_parent_item_id' => $productId,
                            'mage_item_name' => $productName,
                            'qty_ordered' => $qty,
                            'eb_rec_start_date' => $start,
                            'eb_rec_end_date' => $expire,
                            'eb_rec_frequency' => $schedule,
                            'eb_rec_method_id' => $paymentMethodId,
                            'eb_rec_scheduled_payment_internal_id' => $scheduledPaymentInternalId,
                            'eb_rec_total' => $ebzRecurringTotal,
                            'eb_rec_processed' => 0,
                            'eb_rec_next' => $this->tranApi->getNextRecurringDate($recurringDates),
                            'eb_rec_remaining' => $ebzRecurringTotal,
                            'eb_rec_due_dates' => $recurringDatesSerialize,
                            'billing_address_id' => $post['addressBill'],
                            'shipping_address_id' => $post['addressShip'],
                            'amount' => $amount,
                            'coupon_code' => $post['coupon'] ? $post['coupon'] : '',
                            'payment_method_name' => $paymentMethodName,
                            'shipping_method' => $shippingMethod
                        )
                    );

                    $recurringId = $this->tranApi->runInsertQuery($insertQueryParameters);

                    $this->tranApi->insertScheduleDates($recurringId, $recurringDates);

                    return $this->createSuccessMessage('Successfully saved.');
                } else {
                    return $this->createErrorResponse('Unable to save subscription.');
                }

            } catch (\Exception $ex) {
                //return $this->createErrorResponse(self::ACTION_EXCEPTION);
                return $this->createErrorResponse('Exception: ' . $ex->getMessage());
            }
        } else {
            return $this->createErrorResponse('Unable to find payment methodID.');
        }
    }

    /**
     * @param $customerInternalId
     * @param $addNewForm
     * @return array
     */
    private function addNewPaymentAccount($customerInternalId, $addNewForm)
    {
        $paymentMethodName = $addNewForm['cc_type_ach'] . ' ' . substr($addNewForm['cc_number_ach'] ?? '', -4) . ' - ' . $addNewForm['cc_owner_ach'];
        $paymentParameters = array(
            'MethodName' => $paymentMethodName,
            'Created' => date('Y-m-d\TH:i:s'),
            'Modified' => date('Y-m-d\TH:i:s'),
            'Account' => $addNewForm['cc_number_ach'],
            'AccountType' => $addNewForm['cc_type_ach'],
            'AccountHolderName' => $addNewForm['cc_owner_ach'] ?? '',
            'Routing' => $addNewForm['cc_routing_ach'],
            'MethodType' => 'ACH'
        );

        $methodId = $this->addCustomerPaymentMethod($customerInternalId, $paymentParameters);

        return [$methodId, $paymentMethodName];
    }

    private function addNewPaymentMethod($customerInternalId, $addNewForm)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $paymentTypes = $objectManager->get('\Magento\Payment\Model\Config')->getCcTypes();

        $cardType = $addNewForm['cc_type'];

        foreach ($paymentTypes as $code => $text) {
            if ($code == $addNewForm['cc_type']) {
                $cardType = $text;
                break;
            }
        }

        $cardExpiration = $addNewForm['cc_exp_year'] . "-" . $addNewForm['cc_exp_month'];

        if ((isset($addNewForm['cc_cid'])) || (!empty($addNewForm['cc_cid']))) {
            $cardCode = $addNewForm['cc_cid'];
        } else {
            $cardCode = '';
        }

        $paymentMethodName = $cardType . ' ' . substr($addNewForm['cc_number'] ?? '', -4) . ' - ' . $addNewForm['cc_owner'];
        $paymentParameters = array(
            'MethodName' => $paymentMethodName,
            'AccountHolderName' => $addNewForm['cc_owner'],
            'SecondarySort' => 1,
            'Created' => date('Y-m-d\TH:i:s'),
            'Modified' => date('Y-m-d\TH:i:s'),
            'CardCode' => $cardCode,
            'CardExpiration' => $cardExpiration,
            'CardNumber' => $addNewForm['cc_number'],
            'CardType' => $addNewForm['cc_type'],
            'Balance' => 0,
            'MaxBalance' => 0,
            'AvsStreet' => $addNewForm['avs_street'] ?? '',
            'AvsZip' => $addNewForm['avs_zip'] ?? ''
        );

        $methodId = $this->addCustomerPaymentMethod($customerInternalId, $paymentParameters);

        return [$methodId, $paymentMethodName];
    }

    /**
     * @param $customerInternalId
     * @param $parameters
     */
    private function addCustomerPaymentMethod($customerInternalId, $parameters)
    {
        try {
            $paymentMethodId = $this->tranApi->addCustomerPaymentMethod($customerInternalId, $parameters);

            if ($paymentMethodId !== null) {
                $this->createSuccessMessage('Payment method successfully saved.');
                return $paymentMethodId;
            }

            $this->createErrorResponse('Unable to save the payment method.');

        } catch (\Exception $ex) {
            return $this->createErrorResponse('Exception: ' . $ex->getMessage());
        }
    }

    /**
     * Creates an error message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @param int $errorCode
     * @return ResponseInterface
     */
    private function createErrorResponse($errorCode)
    {
        $this->messageManager->addErrorMessage(__($errorCode));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }

    /**
     * Creates a success message, and passes it to the "Manage
     * My Payment Methods" page.
     *
     * @return ResponseInterface
     */
    private function createSuccessMessage($type)
    {
        $this->messageManager->addSuccessMessage(__($type));
        return $this->_redirect('ebizcharge_ebizcharge/recurrings');
    }
}
