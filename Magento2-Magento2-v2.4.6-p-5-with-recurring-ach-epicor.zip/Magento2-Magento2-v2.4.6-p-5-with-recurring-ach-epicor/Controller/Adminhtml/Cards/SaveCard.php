<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/9/21
 * Time: 3:01 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Cards;

use Ebizcharge\Ebizcharge\Model\Data;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Message\Manager;
use Magento\Payment\Model\Config as PaymentConfig;

/**
 * Save/delete customer payment card
 *
 * Class SaveCard
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Cards
 */
class SaveCard extends Action implements HttpPostActionInterface, HttpGetActionInterface
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var PaymentConfig
     */
    private $paymentConfig;

    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var RedirectFactory
     */
    private $redirectFactory;

    /**
     * @var Data
     */
    private $ebizData;

    public function __construct(
        RedirectFactory $redirectFactory,
        Manager $messageManager,
        TranApi $tranApi,
        PaymentConfig $paymentConfig,
        Data $ebizData,
        RequestInterface $request,
        Context $context
    ) {
        parent::__construct($context);
        $this->request = $request;
        $this->paymentConfig = $paymentConfig;
        $this->tranApi = $tranApi;
        $this->messageManager = $messageManager;
        $this->redirectFactory = $redirectFactory;
        $this->ebizData = $ebizData;
    }

    /**
     * @inheridoc
     */
    public function execute()
    {
        $customerId = $this->request->getParam('customer_id');

        if ($this->request->getParam('action') == 'del') {
            $this->deleteCard();
        } elseif ($this->request->getParam('action') == 'edit') {
            $paymentCard = $this->getRequest()->getParam('payment');
            $this->updateCard($paymentCard);
        } else {
            $customerInternalId = $this->ebizData->getMappedAndAddCustomer($customerId, true);

            $paymentCard = $this->getRequest()->getParam('payment');

            $this->addNewPaymentMethod($customerInternalId, $paymentCard);
        }

        return $this->redirectFactory->create()->setPath('customer/index/edit/', ['id' => $customerId]);
    }

    private function addNewPaymentMethod($customerInternalId, $addNewForm)
    {
        $paymentTypes = $this->paymentConfig->getCcTypes();

        $cardType = $addNewForm['cc_type'];

        foreach ($paymentTypes as $code => $text) {
            if ($code == $addNewForm['cc_type']) {
                $cardType = $text;
                break;
            }
        }

        $cardExpiration = $addNewForm['cc_exp_year'] . "-" . $addNewForm['cc_exp_month'];

        $cardCode = '';

        if (!empty($addNewForm['cc_cid'])) {
            $cardCode = $addNewForm['cc_cid'];
        }

        $paymentMethodName = $cardType . ' ' . substr($addNewForm['cc_number'], -4) . ' - ' . $addNewForm['cc_owner'];
        $paymentParameters = [
            'MethodName' => $paymentMethodName,
            'AccountHolderName' => $addNewForm['cc_owner'],
            'SecondarySort' => isset($addNewForm['is_default']) ? 0 : 1,
            'Created' => date('Y-m-d\TH:i:s'),
            'Modified' => date('Y-m-d\TH:i:s'),
            'CardCode' => $cardCode,
            'CardExpiration' => $cardExpiration,
            'CardNumber' => $addNewForm['cc_number'],
            'CardType' => $addNewForm['cc_type'],
            'Balance' => 0,
            'MaxBalance' => 0,
            'AvsStreet' => $addNewForm['avs_street'] ?? 'N/A',
            'AvsZip' => $addNewForm['avs_zip'] ?? ''
        ];

        $this->addCustomerPaymentMethod($customerInternalId, $paymentParameters);
    }

    /**
     * @param $customerInternalId
     * @param $parameters
     * @return void
     */
    private function addCustomerPaymentMethod($customerInternalId, $parameters)
    {
        try {
            $paymentMethodId = $this->tranApi->addCustomerPaymentMethod($customerInternalId, $parameters);

            if ($paymentMethodId !== null) {
                if ($parameters['SecondarySort'] == 0) {
                    $this->setDefaultPaymentMethod(
                        $this->request->getParam('customer_id'),
                        $paymentMethodId
                    );
                }

                $this->messageManager->addSuccessMessage('Payment method successfully saved.');
            } else {
                $this->messageManager->addErrorMessage('Unable to save the payment method.');
            }
        } catch (\Exception $ex) {
            $this->tranApi->log($ex->getMessage());
            $this->messageManager->addExceptionMessage($ex);
        }
    }

    private function deleteCard()
    {
        $customerToken = $this->request->getParam('cid');
        $paymentMethodId = $this->request->getParam('mid');

        if ($this->tranApi->deleteCustomerPaymentMethod($customerToken, $paymentMethodId)) {
            $this->messageManager->addSuccessMessage('Payment method deleted successfully');
        } else {
            $this->messageManager->addErrorMessage('Unable to delete payment method: Please try again!');
        }
    }

    private function updateCard($paymentCard)
    {
        $cid = $paymentCard['cid'];
        $mid = $paymentCard['mid'];

        $cardType = $paymentCard['method_type'];

        try {
            $paymentMethod = $this->tranApi->getCustomerPaymentMethodProfile($cid, $mid);

            $paymentMethod->AccountHolderName = $paymentCard['cc_owner'];
            $paymentMethod->MethodName = $cardType . ' ' . substr($paymentMethod->CardNumber, -4) . ' - ' . $paymentCard['cc_owner'];
            $paymentMethod->CardExpiration = $paymentCard['cc_exp_year'] . '-' . $paymentCard['cc_exp_month'];
            $paymentMethod->AvsStreet = $paymentCard['avs_street'];
            $paymentMethod->AvsZip = $paymentCard['avs_zip'];
            $paymentMethod->SecondarySort = isset($paymentCard['is_default']) ? 0 : $paymentMethod->SecondarySort;

            $this->tranApi->updatePaymentMethod($cid, $paymentMethod);

            if ($paymentMethod->SecondarySort == 0) {
                $this->setDefaultPaymentMethod(
                    $this->request->getParam('customer_id'),
                    $mid
                );
            }

            $this->messageManager->addSuccessMessage('Payment card updated successfully');
        } catch (\Exception $e) {
            $this->tranApi->log($e->getMessage());
            $this->messageManager->addExceptionMessage($e);
        }
    }

    /**
     * Set payment method as default
     * @param $customerId
     * @param $methodId
     * @return bool
     */
    private function setDefaultPaymentMethod($customerId, $methodId)
    {
        $customerToken = $this->tranApi->getCustomerToken($customerId);

        $setDefaultMethod = $this->tranApi->soapClient->SetDefaultCustomerPaymentMethodProfile(
            [
                'securityToken' => $this->tranApi->getUeSecurityToken(),
                'customerToken' => $customerToken,
                'paymentMethodId' => $methodId
            ]
        );

        if (isset($setDefaultMethod->SetDefaultCustomerPaymentMethodProfileResult)) {
            return true;
        }

        return false;
    }
}
