<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/9/21
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Cards;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

/**
 * Add customer payment card
 *
 * Class Add
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Cards
 */
class Add extends Action implements HttpGetActionInterface
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * @return Page
     */
    public function execute()
    {
        $pageTitle = 'Add New Card';

        $resultPage = $this->resultPageFactory->create();

        if ($this->_request->getParam('action') == 'edit') {
            $pageTitle = 'Update Customer Card';
        }

        $resultPage->getConfig()->getTitle()->prepend(__($pageTitle));
        return $resultPage;
    }
}
