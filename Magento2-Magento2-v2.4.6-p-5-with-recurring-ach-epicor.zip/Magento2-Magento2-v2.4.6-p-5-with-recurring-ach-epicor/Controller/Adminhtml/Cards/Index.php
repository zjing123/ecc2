<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/6/21
 * Time: 12:30 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\Cards;

class Index extends \Magento\Customer\Controller\Adminhtml\Index
{
    public function execute()
    {
        return $this->resultLayoutFactory->create();
    }

}
