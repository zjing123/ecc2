<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\ACH;

use Magento\Framework\App\ResponseInterface;

/**
 * Bank accounts listing
 * Class Index
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Ach
 */
class Index extends \Magento\Customer\Controller\Adminhtml\Index
{

    public function execute()
    {
        return $this->resultLayoutFactory->create();
    }
}
