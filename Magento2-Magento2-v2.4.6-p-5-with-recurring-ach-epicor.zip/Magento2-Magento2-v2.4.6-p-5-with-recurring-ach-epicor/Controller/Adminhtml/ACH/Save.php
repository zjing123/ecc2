<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\ACH;

use Ebizcharge\Ebizcharge\Model\Data;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect as Redirect;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;

/**
 * Class Add
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Ach
 */
class Save extends Action implements HttpPostActionInterface
{
    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var Data
     */
    private $ebizData;

    /**
     * @var RedirectFactory
     */
    private $redirectFactory;

    /**
     * Index constructor.
     *
     * @param Data $ebizData
     * @param TranApi $tranApi
     * @param Context $context
     * @param RedirectFactory $redirectFactory
     */
    public function __construct(
        Data $ebizData,
        TranApi $tranApi,
        Context $context,
        RedirectFactory $redirectFactory
    ) {
        parent::__construct($context);
        $this->tranApi = $tranApi;
        $this->ebizData = $ebizData;
        $this->redirectFactory = $redirectFactory;
    }

    /**
     * @return Redirect|ResponseInterface|ResultInterface
     */
    public function execute()
    {
        $customerId = $this->_request->getParam('customerId');

        $achRoute = $this->getRequest()->getParam('achRoute');
        $achType = $this->getRequest()->getParam('achType');
        $achNumber = $this->getRequest()->getParam('achNumber');
        $achHolder = $this->getRequest()->getParam('accountHolder');
        $isDefaultMethod = $this->getRequest()->getParam('isDefault');
        $isDefaultMethod = $isDefaultMethod !== null ? 0 : 1;

        $customerInternalId = $this->ebizData->getMappedAndAddCustomer($customerId, true);

        if ($this->_request->getParam('action') == 'edit') {
            $this->updateAccount();
        } else {
            $paymentMethod = [
                'MethodName' => $achType . ' ' . substr($achNumber, -4) . ' - ' . $achHolder,
                'Created' => date('Y-m-d\TH:i:s'),
                'Modified' => date('Y-m-d\TH:i:s'),
                'Account' => $achNumber,
                'AccountType' => $achType,
                'AccountHolderName' => $achHolder ?? '',
                'SecondarySort' => $isDefaultMethod,
                'Routing' => $achRoute,
                'MethodType' => 'ACH'
            ];
            $this->addCustomerPaymentMethod($customerInternalId, $paymentMethod);
        }

        return $this->redirectFactory->create()->setPath('customer/index/edit/', ['id' => $customerId]);
    }

    /**
     * @param $customerInternalId
     * @param $parameters
     * @return void
     */
    private function addCustomerPaymentMethod($customerInternalId, $parameters)
    {
        try {
            $paymentMethodId = $this->tranApi->addCustomerPaymentMethod($customerInternalId, $parameters);

            if ($paymentMethodId !== null) {
                if ($parameters['SecondarySort'] == '0') {
                    $this->setDefaultPaymentMethod(
                        $this->_request->getParam('customerId'),
                        $paymentMethodId
                    );
                }

                $this->messageManager->addSuccessMessage('Bank account successfully saved.');
            } else {
                $this->messageManager->addErrorMessage('Unable to save the bank account.');
            }
        } catch (\Exception $ex) {
            $this->tranApi->log($ex->getMessage());
            $this->messageManager->addExceptionMessage($ex);
        }
    }

    /**
     * Set payment method as default
     * @param $customerId
     * @param $methodId
     * @return bool
     */
    private function setDefaultPaymentMethod($customerId, $methodId)
    {
        $customerToken = $this->tranApi->getCustomerToken($customerId);

        return $this->tranApi->setDefaultPaymentMethod($customerToken, $methodId);
    }

    private function updateAccount()
    {
        $cid = $this->_request->getParam('cid');
        $mid = $this->_request->getParam('mid');

        try {
            $paymentMethod = $this->tranApi->getCustomerPaymentMethodProfile($cid, $mid);

            $achType = $this->getRequest()->getParam('achType');
            $accountHolder = $this->getRequest()->getParam('accountHolder');
            $isDefault = $this->getRequest()->getParam('isDefault');

            $isDefault = $isDefault !== null ? 0 : $paymentMethod->SecondarySort;

            $paymentMethod->AccountType = $achType;
            $paymentMethod->AccountHolderName = $accountHolder;
            $paymentMethod->MethodName = $achType . ' ' . substr($paymentMethod->Account, -4) . ' - ' . $accountHolder;
            $paymentMethod->Modified = date('Y-m-d\TH:i:s');
            $paymentMethod->SecondarySort = $isDefault;

            $this->tranApi->updatePaymentMethod($cid, $paymentMethod);

            if ($paymentMethod->SecondarySort == '0') {
                $this->setDefaultPaymentMethod(
                    $this->_request->getParam('customerId'),
                    $mid
                );
            }

            $this->messageManager->addSuccessMessage('Bank account updated successfully');
        } catch (\Exception $e) {
            $this->tranApi->log($e->getMessage());
            $this->messageManager->addExceptionMessage($e);
        }
    }
}
