<?php


namespace Ebizcharge\Ebizcharge\Controller\Adminhtml\ACH;


use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class Add
 * @package Ebizcharge\Ebizcharge\Controller\Adminhtml\Ach
 */
class Add extends Action implements HttpGetActionInterface
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * Index constructor.
     *
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * @return Page
     */
    public function execute()
    {
        $pageTitle = 'Add New Bank Account';

        $resultPage = $this->resultPageFactory->create();

        if ($this->_request->getParam('action') == 'edit') {
            $pageTitle = 'Update Bank Account';
        }

        $resultPage->getConfig()->getTitle()->prepend(__($pageTitle));
        return $resultPage;
    }


}
