<?php
/**
 * Override cart item block in custom module
 */
namespace Ebizcharge\Ebizcharge\Block\Cart;

class AbstractCart
{
	public function afterGetItemRenderer(\Magento\Checkout\Block\Cart\AbstractCart $subject, $result)
    {
        $result->setTemplate('Ebizcharge_Ebizcharge::cart/item/default.phtml');
        return $result;
    }
}
