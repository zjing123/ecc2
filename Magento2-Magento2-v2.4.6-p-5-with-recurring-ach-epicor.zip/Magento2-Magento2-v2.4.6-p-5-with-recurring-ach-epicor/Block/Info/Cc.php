<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Ebizcharge\Ebizcharge\Block\Info;

/**
 * Credit card generic payment info
 *
 * @api
 * @since 100.0.2
 */
class Cc extends \Magento\Payment\Block\Info\Cc
{

    /**
     * Prepare credit card related payment info
     *
     * @param \Magento\Framework\DataObject|array $transport
     * @return \Magento\Framework\DataObject
     */
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $transport = get_parent_class(get_parent_class($this))::_prepareSpecificInformation($transport);
        $data = [];

        if ($this->getCcTypeName() == 'ACH')
		{
            if ($ccType = $this->getCcTypeName()) {
                $data[(string)__('Payment Type')] = $ccType;
            }

            if ($this->getInfo()->getCcLast4()) {
                $data[(string)__('Account Number')] = sprintf('xxxx%s', substr($this->getInfo()->getCcLast4(), -4));
            }
            if ($ccType = $this->getCcTypeName()) {
                $data[(string)__('Account Type')] = ucfirst($this->getInfo()->getAdditionalInformation()['ach_type'] ?: 'Checking | Saving');
            }
        } else {
            if ($ccType = $this->getCcTypeName()) {
                $data[(string)__('Credit Card Type')] = $ccType;
            }

            if ($this->getInfo()->getCcLast4()) {
                $data[(string)__('Credit Card Number')] = sprintf('xxxx-%s', substr($this->getInfo()->getCcLast4(), -4));
            }
        }

        if (!$this->getIsSecureMode()) {
            if ($ccSsIssue = $this->getInfo()->getCcSsIssue()) {
                $data[(string)__('Switch/Solo/Maestro Issue Number')] = $ccSsIssue;
            }
            $year = $this->getInfo()->getCcSsStartYear();
            $month = $this->getInfo()->getCcSsStartMonth();
            if ($year && $month) {
                $data[(string)__('Switch/Solo/Maestro Start Date')] = $this->_formatCardDate($year, $month);
            }
        }
        return $transport->setData(array_merge($data, $transport->getData()));
    }
}
