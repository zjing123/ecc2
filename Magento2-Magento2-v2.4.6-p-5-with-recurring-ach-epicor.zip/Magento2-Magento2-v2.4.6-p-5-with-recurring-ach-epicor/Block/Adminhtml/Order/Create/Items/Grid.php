<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ebizcharge\Ebizcharge\Block\Adminhtml\Order\Create\Items;

use Magento\Catalog\Helper\Data as CatalogHelper;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\StockStateInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;

class Grid extends \Magento\Sales\Block\Adminhtml\Order\Create\Items\Grid
{
    /**
     * @var StockStateInterface
     */
    protected $stockState;
    protected $_tran;
    protected $config;
    protected $backendUrlManager;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Model\Session\Quote $sessionQuote,
        \Magento\Sales\Model\AdminOrder\Create $orderCreate,
        PriceCurrencyInterface $priceCurrency, \Magento\Wishlist\Model\WishlistFactory $wishlistFactory,
        \Magento\GiftMessage\Model\Save $giftMessageSave, \Magento\Tax\Model\Config $taxConfig,
        \Magento\Tax\Helper\Data $taxData,
        \Magento\GiftMessage\Helper\Message $messageHelper,
        StockRegistryInterface $stockRegistry,
        StockStateInterface $stockState,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Ebizcharge\Ebizcharge\Model\Config $config,
        \Magento\Backend\Model\Url $backendUrlManager,
        array $data = [],
        ?CatalogHelper $catalogHelper = null
    ) {
        $this->_tran = $tranApi;
        $this->config = $config;
        $this->backendUrlManager  = $backendUrlManager;
        parent::__construct($context, $sessionQuote, $orderCreate, $priceCurrency, $wishlistFactory, $giftMessageSave, $taxConfig, $taxData, $messageHelper, $stockRegistry, $stockState, $data, $catalogHelper);
    }

    public function getEbizActive()
    {
        return $this->config->getEbizActive() == 1;
    }

    public function isRecurringActive()
    {
        return $this->config->isRecurringActive() == 1;
    }

    public function getRecurringFrequencyOptions($selectedFrequency = null)
    {
        echo $this->config->getRecurringFrequencyOptions($selectedFrequency);
    }

    public function getRecurringCheckUrl()
    {
        return $this->backendUrlManager->getUrl('ebizcharge_ebizcharge/recurrings/checkrecurringproduct');
    }
}