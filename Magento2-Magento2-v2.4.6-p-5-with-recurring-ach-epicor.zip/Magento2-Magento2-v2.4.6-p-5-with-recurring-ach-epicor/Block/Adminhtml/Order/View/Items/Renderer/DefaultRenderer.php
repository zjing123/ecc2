<?php
/**
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\Order\View\Items\Renderer;

use Magento\Framework\DataObject;

/**
 * Adminhtml sales order item/subscription renderer
 *
 * @api
 * @since 100.0.2
 */
class DefaultRenderer extends \Magento\Sales\Block\Adminhtml\Order\View\Items\Renderer\DefaultRenderer
{
    /**
     * Get column html for subscribed item
     * @param DataObject $item
     * @param $column
     * @param $field
     * @return string
     */
    public function getColumnHtml(DataObject $item, $column, $field = null)
    {
        if ($column == 'subscribed') {
            return $this->getItemSubscription();
        }
        return parent::getColumnHtml($item, $column, $field);
    }

    /**
     * Show subscription in order detail page
     *
     * @return string
     */
    public function getItemSubscription()
    {
        try {
            $order = $this->getItem()->getOrder();
            $rawData = $this->getItem()->getData();
            $orderItemId = $rawData['product_id'];

            if (!empty($rawData['product_options']['info_buyRequest'])) {
                $infoBuyRequest = $rawData['product_options']['info_buyRequest'];
                $infoBuyRequestParentItemId = !empty($infoBuyRequest['item']) ? $infoBuyRequest['item'] : '';
                $infoBuyRequestChildItemId = !empty($infoBuyRequest['currentpid']) ? $infoBuyRequest['currentpid'] : '';
            } else {
                $infoBuyRequestParentItemId = '';
                $infoBuyRequestChildItemId = '';
            }

            $recurring = $this->getSubscribedItemsData($order->getIncrementId(), $orderItemId, $infoBuyRequestParentItemId, $infoBuyRequestChildItemId);

            if (!empty($recurring)) {
                $sdate = date('Y-m-d', strtotime($recurring['eb_rec_start_date']));

                if ($recurring['rec_indefinitely'] == 1) {
                    $edate = 'Recur indefinitely';
                } else {
                    $edate = date('Y-m-d', strtotime($recurring['eb_rec_end_date']));
                }

                $finalString = '<div class="ordersub">Status: <strong>Subscribed</strong></div>';
                $finalString .= '<div class="ordersub">Frequency: <strong>' . ucfirst($recurring['eb_rec_frequency']) . '</strong></div>';
                $finalString .= '<div class="ordersub">Qty Subscribed: <strong>' . $recurring['qty_ordered'] . '</strong></div>';
                $finalString .= '<div class="ordersub">Start Date: <strong>' . $sdate . '</strong></div>';
                $finalString .= '<div class="ordersub">End Date: <strong>' . $edate . '</strong></div>';

            } else {
                $finalString = '<div class="ordersub">Not subscribed</div>';
            }

            return $finalString;

        } catch (\Exception $ex) {
            $finalString = '<div class="ordersub">No record found!</div>';
            return $finalString;
        }
    }


    /**
     * subscription details for an item
     *
     * @param $orderId
     * @param $orderMainItemId
     * @param $infoBuyRequestParentItemId
     * @param $infoBuyRequestChildItemId
     * @return array
     */
    public function getSubscribedItemsData($orderId, $orderMainItemId, $infoBuyRequestParentItemId, $infoBuyRequestChildItemId)
    {
        if (!empty($infoBuyRequestParentItemId)) {
            $orderMainItemId = $infoBuyRequestParentItemId;
        }

        if (!empty($infoBuyRequestChildItemId)) {
            if ($infoBuyRequestChildItemId == $orderMainItemId) {
                $infoBuyRequestChildItemId = $orderMainItemId;
            }
        } else {
            $infoBuyRequestChildItemId = $orderMainItemId;
        }

        $recurring = [];
        $selectQueryParameters = array(
            'option' => 'select',
            'tableName' => 'ebizcharge_recurring',
            'tableFields' => '*',
            'whereKey' => 'mage_order_id',
            'whereValue' => $orderId,
            'whereKey2' => 'mage_parent_item_id',
            'whereValue2' => $orderMainItemId,
            'whereKey3' => 'mage_item_id',
            'whereValue3' => $infoBuyRequestChildItemId
        );

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $tran = $objectManager->get(\Ebizcharge\Ebizcharge\Model\TranApi::class);
        $recurringData = $tran->runSelectQueryMultipleInput($selectQueryParameters, 3);

        if (isset($recurringData[0]) && !empty($recurringData[0])) {
            $recurring = $recurringData[0];

        } else {
            // else check in recurring_order
            $selectQueryParameters = array(
                'option' => 'select',
                'tableName' => 'ebizcharge_recurring_order',
                'tableFields' => '*',
                'whereKey' => 'rec_order_id',
                'whereValue' => $orderId
            );

            $recurringOrder = $tran->runSelectQuery($selectQueryParameters);

            if (isset($recurringOrder[0]) && !empty($recurringOrder[0])) {
                $recurringOrder = $recurringOrder[0];
                $selectQueryParameters = array(
                    'option' => 'select',
                    'tableName' => 'ebizcharge_recurring',
                    'tableFields' => '*',
                    'whereKey' => 'rec_id',
                    'whereValue' => $recurringOrder['recurring_id']
                );

                $recurringData = $tran->runSelectQuery($selectQueryParameters);

                if (isset($recurringData[0]) && !empty($recurringData[0])) {
                    $recurring = $recurringData[0];
                }
            }
        }

        return $recurring;
    }

}
