<?php

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\Grid;

/**
 * Class AddBankAccount
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\Grid
 */
class AddBankAccount extends \Magento\Backend\Block\Widget\Form\Container
{

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * Initialize Bank Account Edit Block.
     */
    protected function _construct()
    {
        $this->_objectId = 'row_id';
        $this->_blockGroup = 'Ebizcharge_Ebizcharge';
        $this->_controller = 'adminhtml_grid';
        parent::_construct();

        $this->buttonList->update('save', 'label', __('Save'));
        $this->buttonList->update(
            'back',
            'onclick',
            "setLocation('" . $this->getUrl('customer/index/edit/', [
                'id' => $this->_request->getParam('id')
            ]) . "')"
        );

        $this->buttonList->remove('reset');
    }

    /**
     * Retrieve text for header element
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        return __('Bank Account Information');
    }

    /**
     * Get form action URL.
     *
     * @return string
     */
    public function getFormActionUrl()
    {
        return $this->getUrl('*/*/save');
    }
}
