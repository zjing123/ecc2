<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\Grid\Edit;

use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Framework\View\Helper\SecureHtmlRenderer;

/**
 * Adminhtml Add bank account form
 * Class Form
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\Grid\Edit
 */
class Form extends Generic
{
    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var SecureHtmlRenderer
     */
    private $secureRenderer;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        TranApi $tranApi,
        SecureHtmlRenderer $secureRenderer,
        array $data = []
    )
    {
        parent::__construct($context, $registry, $formFactory, $data);
        $this->tranApi = $tranApi;
        $this->secureRenderer = $secureRenderer;
    }

    /**
     * Prepare bank account form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        $form = $this->_formFactory->create(
            [
                'data' => [
                    'id' => 'edit_form',
                    'enctype' => 'multipart/form-data',
                    'action' => $this->getData('action'),
                    'method' => 'post'
                ]
            ]
        );

        $form->setHtmlIdPrefix('ebizId_');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Bank Account Information'), 'class' => 'fieldset-wide']
        );

        $fieldset->addField(
            'action',
            'hidden',
            [
                'name' => 'action',
                'id' => 'action',
            ]
        );
        $fieldset->addField(
            'cid',
            'hidden',
            [
                'name' => 'cid',
                'id' => 'cid',
            ]
        );
        $fieldset->addField(
            'mid',
            'hidden',
            [
                'name' => 'mid',
                'id' => 'mid',
            ]
        );

        $fieldset->addField(
            'customerId',
            'hidden',
            [
                'name' => 'customerId',
                'id' => 'customerId',
            ]
        );

        $fieldset->addField(
            'accountHolder',
            'text',
            [
                'name' => 'accountHolder',
                'label' => __('Account Holder'),
                'id' => 'accountHolder',
                'title' => __('Account Holder'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );

        $fieldset->addField(
            'achNumber',
            'text',
            [
                'name' => 'achNumber',
                'label' => __('Account Number'),
                'id' => 'achNumber',
                'title' => __('Please enter a valid bank account number'),
                'class' => $this->_request->getParam('action') == 'edit'
                    ? ' disabled'
                    : ' required-entry validate-digits validate-zero-or-greater validate-digits-range digits-range-100000000-99999999999999',
                'maxlength' => '14',
                'required' => true,
            ]
        );

        $fieldset->addField(
            'achRoute',
            'text',
            [
                'name' => 'achRoute',
                'label' => __('Routing Number'),
                'id' => 'achRoute',
                'title' => __('Routing Number'),
                'class' => $this->_request->getParam('action') == 'edit' ? ' disabled'
                    : ' required-entry validate-digits validate-digits-range digits-range-000000000-999999999',
                'maxlength' => '9',
                'required' => true,
            ]
        );

        $fieldset->addField(
            'achType',
            'select',
            [
                'name' => 'achType',
                'label' => __('Account Type'),
                'id' => 'achType',
                'title' => __('Account Type'),
                'values' => $this->getAccountTypes(),
                'class' => 'status',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'isDefault',
            'checkbox',
            [
                'name' => 'isDefault',
                'label' => __('Default Account'),
                'id' => 'isDefault',
                'title' => __('Default Account'),
                'class' => 'status',
                'after_element_html' => $this->secureRenderer->renderTag(
                    'script',
                    [],
                    'require(["jquery"], function ($) {

                         $("#ebizId_isDefault").val() == 1 && $( "#ebizId_isDefault" ).prop( "checked", true ) && $( "#ebizId_isDefault" ).prop( "disabled", true );

                        $(document).on("click", "#save", function(){
                          if($("#edit_form").valid()) {
                                $("body").trigger("processStart");
                          }
                         });

                    });',
                    false
                ),
                'required' => false,
            ]
        );

        $form->setValues($this->getFormData());

        $form->setUseContainer(true);

        $this->setForm($form);

        return parent::_prepareForm();
    }

    private function getAccountTypes()
    {
        return [
            'checking' => __('Checking'),
            'saving' => __('Saving')
        ];
    }

    private function getFormData()
    {
        $customerId = $this->_request->getParam('id');
        $formData = ['customerId' => $customerId];

        if ($this->_request->getParam('action') == 'edit') {
            $formData['action'] = 'edit';

            $ebzcCustomerId = $this->_request->getParam('cid');
            $ebzcMethodId = $this->_request->getParam('mid');

            $formData['cid'] = $ebzcCustomerId;
            $formData['mid'] = $ebzcMethodId;

            $bankAccount = $this->tranApi->getCustomerPaymentMethodProfile($ebzcCustomerId, $ebzcMethodId);

            if ($bankAccount) {
                $formData['achType'] = $bankAccount->AccountType ?? null;
                $formData['accountHolder'] = $bankAccount->AccountHolderName ?? '';
                $formData['achRoute'] = $bankAccount->Routing ?? '';
                $formData['achNumber'] = $bankAccount->Account ?? '';
                $formData['isDefault'] = $bankAccount->SecondarySort == 0 ? 1 : null;
            }
        }

        return $formData;
    }
}
