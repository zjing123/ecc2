<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/28/21
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\Sales\Transaction;

use Ebizcharge\Ebizcharge\Model\CardTypeTrait;
use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\DataObject;

/**
 * Payment card type
 *
 * Class CardType
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\Sales\Transaction
 */
class CardType extends AbstractRenderer
{
    use CardTypeTrait;

    public function render(DataObject $row)
    {
        $cardLast4Digit = $row->getOrder()->getPayment()->getCcLast4();
        $ccType = $row->getOrder()->getPayment()->getCcType();
        $ccOwners = $row->getOrder()->getPayment()->getCcOwner();

        if (!empty($cardLast4Digit)) {
            $cardLast4Digit = str_replace('X', '', $cardLast4Digit);

            $checkingOrSaving = '';
            if ($ccType == 'ACH') {
                $checkingOrSaving = 'ACH';

                if (empty($ccOwners)) {
                    $checkingOrSaving = $row->getOrder()->getPayment()->getAdditionalInformation()['ach_type'] ?: 'ACH';
                } else {

                    stristr($ccOwners, 'Checking') !== false && $checkingOrSaving = 'Checking';
                    stristr($ccOwners, 'Savings') !== false && $checkingOrSaving = 'Savings';
                }

                $checkingOrSaving = ucfirst($checkingOrSaving);
            }

            $cardLast4Digit = $checkingOrSaving . ' ending in ' . $cardLast4Digit;
        }

        $cardType = $row->getOrder()->getPayment()->getCcType();

        if (empty($cardType)) {
            return $cardLast4Digit;
        }

        $imagePath = $this->getCardImagePath($cardType);

        $imagePathUrl = $this->getViewFileUrl($imagePath);

        $cardName = $imagePath == '' ? $this->getCardName($cardType) : ' ';

        $imageFor = 'card';

        strtolower($cardType) == 'ach' && $imageFor = 'ach';

        return $this->getImageTag($imagePathUrl, $imageFor) . ' ' . $cardName . ' ' . $cardLast4Digit;
    }
}
