<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/6/21
 * Time: 11:45 AM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab;

use Magento\Backend\Block\Template;
use Magento\Customer\Controller\RegistryConstants;
use Magento\Framework\Registry;
use Magento\Ui\Component\Layout\Tabs\TabInterface as TabInterface;

/**
 * Customer payment methods
 *
 * Class PaymentMethods
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab
 */
class PaymentMethods extends Template implements TabInterface
{
    /**
     * URL Path for cards listing
     */
    const CARDS_TAB_PATH = 'ebizcharge_ebizcharge/cards/index';

    /**
     * URL Path for bank accounts listing
     */
    const BANK_ACCOUNTS_TAB_PATH = 'ebizcharge_ebizcharge/ach/index';

    /**
     * @var Registry
     */
    protected $_coreRegistry;

    /**
     * PaymentMethods constructor.
     * @param Template\Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    public function getCustomerId()
    {
        return $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
    }

    /**
     * @inheritDoc
     */
    public function getTabLabel()
    {
        return __($this->getData('tab_label'));
    }

    /**
     * @return string
     */
    public function getTabTitle()
    {
        return __($this->getData('tab_label'));
    }

    /**
     * @inheritDoc
     */
    public function getTabClass()
    {
        return '';
    }

    /**
     * @inheritDoc
     */
    public function getTabUrl()
    {
        return $this->getUrl($this->getTabPath(), ['_current' => true]);
    }

    /**
     * @inheritDoc
     */
    public function isAjaxLoaded()
    {
        return true;
    }

    /**
     * @inheritDoc
     */
    public function canShowTab()
    {
        return $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
    }

    /**
     * @inheritDoc
     */
    public function isHidden()
    {
        return false;
    }
}
