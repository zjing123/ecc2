<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/6/21
 * Time: 12:01 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View;

use Ebizcharge\Ebizcharge\Model\Token;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Grid\Extended as Extended;
use Magento\Backend\Helper\Data;
use Magento\Customer\Model\CustomerIdProvider as CustomerIdProvider;
use Magento\Customer\Model\ResourceModel\CustomerRepository;
use Magento\Framework\Data\Collection;
use Magento\Framework\Data\CollectionFactory;
use Magento\Framework\DataObjectFactory as DataObjectFactory;
use Magento\Framework\Registry;

/**
 * Customer payment methods listing
 *
 * Class PaymentMethods
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View
 */
class PaymentMethods extends Extended
{
    /**
     * Card add path url
     */
    const CARD_ADD_PATH = 'ebizcharge_ebizcharge/cards/add/';

    /**
     * Bank account add path url
     */
    const BANK_ACCOUNT_ADD_PATH = 'ebizcharge_ebizcharge/ach/add/';

    /**
     * @var Registry|null
     */
    protected $_coreRegistry = null;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var TranApi
     */
    private $tranApi;

    /**
     * @var Token
     */
    private $ebizToken;

    /**
     * @var DataObjectFactory
     */
    private $dataObjectFactory;

    /**
     * @var CustomerIdProvider
     */
    private $customerIdProvider;

    /**
     * @var CustomerRepository
     */
    private $customerRepository;

    public function __construct(
        CustomerRepository $customerRepository,
        CustomerIdProvider $customerIdProvider,
        DataObjectFactory $dataObjectFactory,
        Token $ebizToken,
        TranApi $tranApi,
        Context $context,
        Data $backendHelper,
        CollectionFactory $collectionFactory,
        Registry $coreRegistry,
        array $data = []
    ) {
        parent::__construct($context, $backendHelper, $data);
        $this->_coreRegistry = $coreRegistry;
        $this->_collectionFactory = $collectionFactory;
        $this->tranApi = $tranApi;
        $this->ebizToken = $ebizToken;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->customerIdProvider = $customerIdProvider;
        $this->customerRepository = $customerRepository;
    }

    protected function _construct()
    {
        parent::_construct();
        $this->setId($this->getData('block_name'));
        $this->setSortable(false);
        $this->setPagerVisibility(false);
        $this->setFilterVisibility(false);
    }

    protected function _prepareCollection()
    {
        $this->setCollection($this->getCollection());
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        foreach ($this->getGridColumns() as $columnId => $columnData) {
            $this->addColumn($columnId, $columnData);
        }

        $this->addExportType($this->getAddButtonUrl() . $this->customerIdProvider->getCustomerId() . '/', $this->getAddButtonTitle());
        return parent::_prepareColumns();
    }

    public function getHeadersVisibility()
    {
        return $this->getCollection()->getSize() >= 0;
    }

    public function getRowUrl($row)
    {
        return '';
    }

    public function getEbizCustId()
    {
        return $this->ebizToken->getCollection()
            ->addFieldToFilter('mage_cust_id', $this->customerIdProvider->getCustomerId())
            ->getFirstItem()
            ->getEbzcCustId();
    }

    /**
     * Get collection object
     *
     * @return \Magento\Framework\Data\Collection
     */
    public function getCollection()
    {
        /**
         * @var Collection $collection
         */
        $collection = $this->_collectionFactory->create();

        $paymentMethods = $this->tranApi->getCustomerPaymentMethods($this->getEbizCustId());

        $bankAccount = true;

        $this->getData('block_name') == 'customer_cards_tab' && $bankAccount = false;

        if ($paymentMethods != null) {
            return $this->getPaymentMethodsCollection($collection, $paymentMethods, $bankAccount);
        }

        return $collection;
    }

    public function getCustomerPaymentMethods()
    {
        return $this->tranApi->getCustomerPaymentMethods($this->getEbizCustId());
    }

    /**
     * Get payment methods collection
     *
     * @param Collection $collection
     * @param $paymentCards
     * @param bool $bankAccount
     * @return mixed
     * @throws \Exception
     */
    private function getPaymentMethodsCollection(Collection $collection, $paymentCards, bool $bankAccount)
    {
        foreach ($paymentCards as $paymentCard) {
            if (!$bankAccount && $paymentCard->MethodType == 'cc') {
                $collection->addItem($this->getCardDataObject($paymentCard));
            } elseif ($bankAccount && $paymentCard->MethodType == 'check') {
                $collection->addItem($this->getBankAccountDataObject($paymentCard));
            }
        }
        return $collection;
    }

    private function getCardDataObject($paymentCard)
    {
        return $this->dataObjectFactory->create()->setData(
            [
                'cardHolder' => $paymentCard->AccountHolderName,
                'cardNumber' => $paymentCard->CardNumber,
                'cardType' => $paymentCard->CardType,
                'expirationDate' => $paymentCard->CardExpiration,
                'methodId' => $paymentCard->MethodID,
                'methodName' => $paymentCard->MethodName,
                'isDefault' => !$paymentCard->SecondarySort ? 'Yes' : 'No',
                'ebizCustId' => $this->getEbizCustId(),
                'customerId' => $this->customerIdProvider->getCustomerId(),
            ]
        );
    }

    private function getBankAccountDataObject($paymentCard)
    {
        return $this->dataObjectFactory->create()->setData(
            [
                'accountHolder' => $paymentCard->AccountHolderName,
                'accountType' => ucfirst($paymentCard->AccountType) . ' ' . $paymentCard->Account,
                'methodId' => $paymentCard->MethodID,
                'methodName' => $paymentCard->MethodName,
                'isDefault' => !$paymentCard->SecondarySort ? 'Yes' : 'No',
                'ebizCustId' => $this->getEbizCustId(),
                'customerId' => $this->customerIdProvider->getCustomerId(),
            ]
        );
    }

    /**
     * Generate export button
     *
     * @return string
     */
    public function getExportButtonHtml()
    {
        $style = '
                    <style> #' . $this->getData('block_name') . '_export { display: none;} .admin__control-support-text { display: none;}  </style>';
        $html =  $this->getLayout()->createBlock(\Magento\Backend\Block\Widget\Button::class)->setData(
            [
                'label' => __($this->getAddButtonTitle()),
                'onclick' => $this->getJsObjectName() . '.doExport()',
                'class' => 'task',
            ]
        )->toHtml();
        return $html . ' ' . $style;
    }

    /**
     * Get grid columns
     * @return array|array[]
     */
    private function getGridColumns()
    {
        if ($this->getData('block_name') == 'customer_cards_tab') {
            return $this->getCustomerCardColumns();
        }
        return $this->getBankAccountColumns();
    }

    /**
     * Get customer cards grid columns
     * @return array[]
     */
    private function getCustomerCardColumns(): array
    {
        return [
            'cardHolder' => [
                'index' => 'cardHolder',
                'header' => __('Card Holder')
            ],
            'cardType' => [
                'header' => __('Card Type & Number'),
                'index' => 'cardType',
                'renderer' => CardType::class,
                'class' =>'photo',
            ],
            'expirationDate' => [
                'header' => __('Expiration Date'),
                'index' => 'expirationDate',
            ],
            'isDefault' => [
                'header' => __('Default'),
                'index' => 'isDefault',
            ],
            'actions' => [
                'header' => __('Actions'),
                'type' => 'select',
                'renderer' => ActionColumn::class,
                'resizeEnabled' => true,
                'resizeDefaultWidth' => 10,
                'is_system' => true,
                'filter' => false,
                'sortable' => false,
                'header_css_class' => 'col-select',
                'column_css_class' => 'col-select',
            ]
        ];
    }

    /**
     * Get customer bank account grid columns
     * @return array[]
     */
    private function getBankAccountColumns(): array
    {
        return [
            'accountHolder' => [
                'header' => __('Account Holder'),
                'index' => 'accountHolder',
            ],
            'accountType' => [
                'header' => __('Account Type & Number'),
                'index' => 'accountType'
            ],
            'isDefault' => [
                'header' => __('Default'),
                'index' => 'isDefault',
            ],
            'actions' => [
                'header' => __('Actions'),
                'type' => 'select',
                'renderer' => ActionColumn::class,
                'resizeEnabled' => true,
                'resizeDefaultWidth' => 10,
                'is_system' => true,
                'filter' => false,
                'sortable' => false,
                'header_css_class' => 'col-select',
                'column_css_class' => 'col-select',
            ]
        ];
    }
}
