<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/9/21
 * Time: 6:46 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\DataObject;
use Ebizcharge\Ebizcharge\Model\CardTypeTrait;


/**
 * Card type and card image
 *
 * Class CardType
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View
 */
class CardType extends AbstractRenderer
{
    use CardTypeTrait;

    /**
     * Renders grid column
     *
     * @param DataObject $row
     * @return  string
     */
    public function render(DataObject $row)
    {
        $cardNumber = $row->getData('cardNumber');
        $cardType = $row->getData('cardType');

        $imagePath = $this->getCardImagePath($cardType);

        $imagePath = $this->getViewFileUrl($imagePath);

        return $this->getImageTag($imagePath) . ' ' . $cardNumber;
    }

}
