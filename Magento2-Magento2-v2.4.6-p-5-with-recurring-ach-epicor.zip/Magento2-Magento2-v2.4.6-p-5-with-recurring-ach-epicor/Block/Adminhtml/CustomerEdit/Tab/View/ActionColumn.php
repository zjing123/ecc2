<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/6/21
 * Time: 4:02 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\Select;
use Magento\Framework\DataObject;

/**
 * Payment methods column edit/delete action
 *
 * Class ActionColumn
 * @package Ebizcharge\Ebizcharge\Block\Adminhtml\CustomerEdit\Tab\View
 */
class ActionColumn extends Select
{

    /**
     * @param DataObject $row
     * @return string
     */
    public function render(DataObject $row): string
    {
        $mid = $row->getData('methodId');
        $cid = $row->getData('ebizCustId');
        $customer_id = $row->getData('customerId');

        return '<a href="' . $this->getUrl('ebizcharge_ebizcharge/*/add', [
                '_secure' => true,
                'id' => $customer_id,
                'action' => 'edit',
                'cid' => $cid,
                'mid' => $mid
            ]) . '"> Edit</a>&nbsp;&nbsp;&nbsp;<a href="' . $this->getUrl('ebizcharge_ebizcharge/cards/saveCard', [
                '_secure' => true,
                'customer_id' => $customer_id,
                'action' => 'del',
                'cid' => $cid,
                'mid' => $mid
            ]) . '" id="deleteCard">Delete</a>';
    }

}
