<?php
/**
 * Accesses data to pass to the 'Manage My Payment Method' pages.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Block\Customer\Account;

use Ebizcharge\Ebizcharge\Model\CardTypeTrait;
use Ebizcharge\Ebizcharge\Model\Token;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;

class Cards extends Template
{
    private $customerTokenManagement;
    protected $_mage_cust_id;
    protected $_ebzc_cust_id;
    protected $_customerSession;
    protected $_tran;
    protected $_paymentConfig;
    protected $_myConfig;

    use CardTypeTrait;

    /**
     * epicor customer account
     * @var \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount
     */
    private $epiCorCustomer;

    public function __construct(
        Template\Context $context,
        Token $customerTokenManagement,
        TranApi $tranApi,
        Session $session,
        \Magento\Payment\Model\Config $paymentConfig,
        \Ebizcharge\Ebizcharge\Model\Config $config,
        \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount $epiCorCustomer,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->customerTokenManagement = $customerTokenManagement;
        $this->_tran = $tranApi;
        $this->_customerSession = $session;
        $this->_paymentConfig = $paymentConfig;
        $this->_myConfig = $config;

        $customer = $this->_customerSession->getCustomer();
        $this->_mage_cust_id = $customer->getId();

        $this->_tran->achStatus = $this->_myConfig->isAchActive();

        $this->epiCorCustomer = $epiCorCustomer;

        $this->erpCustomerProcess($customer);
    }

    public function getAchStatus()
    {
        return $this->_tran->achStatus;
    }

    public function getEbzcCustId()
    {
        return $this->_ebzc_cust_id;
    }

    public function getMageCustId()
    {
        return $this->_mage_cust_id;
    }

    public function getEbzcMethodId()
    {
        $mid = $this->getRequest()->getParam('mid');
        return $mid;
    }

    public function getMethodName()
    {
        $method = $this->getRequest()->getParam('method');
        return urldecode($method);
    }

    public function getBackUrl()
    {
        return $this->getUrl('customer/account/');
    }

    public function getAddCardUrl()
    {
        return $this->getUrl('ebizcharge/cards/addaction/');
    }

    public function getSaveUrl()
    {
        return $this->_urlBuilder->getUrl('ebizcharge/cards/saveaction', ['_secure' => true]);
    }

    public function getPaymentCards()
    {
        $collection = $this->customerTokenManagement->getCollection()
            ->addFieldToFilter('mage_cust_id', $this->_customerSession->getCustomerId());

        return $collection;
    }

    public function getConfig($path)
    {
        return $this->_myConfig->getConfig($path);
    }

    public function getCcTypes()
    {
        return $this->_paymentConfig->getCcTypes();
    }

    // for user account payment methods listing
    public function getPaymentMethods()
    {
        return $this->_tran->getCustomerPaymentMethods($this->_ebzc_cust_id);
    }

    public function getCustomerPaymentMethod()
    {
        $mid = $this->getRequest()->getParam('mid');
        $cid = $this->getRequest()->getParam('cid');

        return $this->_tran->getCustomerPaymentMethodProfile($cid, $mid);
    }

    /**
     * Returns month html select
     *
     * @param string $selectedMonth
     * @return string
     */
    public function getMonthSelect(string $selectedMonth = '01'): string
    {
        $monthOptions = [];

        $monthNames = array_values($this->_paymentConfig->getMonths());

        foreach ($monthNames as $key => $value) {
            $month = explode('-', $value);
            $month0 = $month[0] ?? '';
            $month1 = $month[1] ?? '';
            $monthOptions[trim($month0)] = trim($month1);
        }

        try {
            return $this->getLayout()->createBlock(
                \Magento\Framework\View\Element\Html\Select::class
            )->setName(
                'cc_exp_month'
            )->setTitle(
                __('Expiration Date')
            )->setId(
                'cc_exp_month'
            )->setClass(
                'select month required-entry'
            )->setValue(
               $selectedMonth
            )->setOptions(
                $monthOptions
            )->setExtraParams(
                'data-validate="{\'validate-cc-exp\':\'#cc_exp_year\'}"'
            )->getHtml();
        } catch (\Exception $e) {
            return '';
        }
    }

    private function erpCustomerProcess($customer)
    {
        if ($customer->getEccErpaccountId() > 0) {
            if ($internalId = $this->epiCorCustomer->getCustomerInternalId($customer)) {
                $this->_ebzc_cust_id = $internalId;
            } else {
                $ebizCustomer = $this->_tran->getCustomer($customer->getId());
                $ebzc_cust_id = $ebizCustomer->CustomerToken;
                $this->epiCorCustomer->updateErpCustomer($customer, $ebzc_cust_id);
                $this->_ebzc_cust_id = $ebzc_cust_id;
            }

        } else {
            $this->_ebzc_cust_id = $this->customerTokenManagement->getCollection()
                ->addFieldToFilter('mage_cust_id', $customer->getId())
                ->getFirstItem()
                ->getEbzcCustId();
        }

    }

}
