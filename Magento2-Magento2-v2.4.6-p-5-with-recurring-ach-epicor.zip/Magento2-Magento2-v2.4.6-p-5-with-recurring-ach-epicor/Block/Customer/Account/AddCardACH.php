<?php
/**
 * Accesses data to pass to the 'Add New Credit Card' page.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Block\Customer\Account;

use Magento\Framework\App\ObjectManager;

class AddCardACH extends \Magento\Customer\Block\Address\Edit
{

    public function getSaveUrl()
    {
        return $this->_urlBuilder->getUrl('ebizcharge/*/saveaction', ['_secure' => true]);
    }

    public function getCcTypes()
    {
        return ObjectManager::getInstance()->get(\Magento\Payment\Model\Config::class)->getCcTypes();
    }

    public function getCustomerBillingAddress()
    {
        return $this->_customerSession->getCustomer()->getDefaultBillingAddress();
    }

    /**
     * Returns month html select
     *
     * @param string $selectedMonth
     * @return string
     */
    public function getMonthSelect(string $selectedMonth = '01'): string
    {
        $monthOptions = [];
        $months = ObjectManager::getInstance()->get(\Magento\Payment\Model\Config::class)->getMonths();
        $monthNames = array_values($months);

        foreach ($monthNames as $key => $value) {
            $month = explode('-', $value);
            $month0 = $month[0] ?? '';
            $month1 =  $month[1] ?? '';
            $monthOptions[trim($month0)] = trim($month1);
        }

        try {
            return $this->getLayout()->createBlock(
                \Magento\Framework\View\Element\Html\Select::class
            )->setName(
                'cc_exp_month'
            )->setTitle(
                __('Expiration Date')
            )->setId(
                'cc_exp_month'
            )->setClass(
                'select month required-entry'
            )->setValue(
                $selectedMonth
            )->setOptions(
                $monthOptions
            )->setExtraParams(
                'data-validate="{\'validate-cc-exp\':\'#cc_exp_year\'}"'
            )->getHtml();
        } catch (\Exception $e) {
            return '';
        }
    }

}
