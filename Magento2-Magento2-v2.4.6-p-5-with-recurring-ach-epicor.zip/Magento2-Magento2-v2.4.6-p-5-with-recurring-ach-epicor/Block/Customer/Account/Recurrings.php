<?php
/**
 * Accesses data to pass to the 'Manage My Payment Method' pages.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Block\Customer\Account;

use Ebizcharge\Ebizcharge\Model\Token;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;
use Ebizcharge\Ebizcharge\Model\CardTypeTrait;

class Recurrings extends Template
{
    private $customerTokenManagement;
    protected $_mage_cust_id;
    protected $_ebzc_cust_id;
    protected $_customerSession;
    protected $_tran;
    protected $_paymentConfig;
    protected $_myConfig;
    protected $_ebiz_internal_id;
    use CardTypeTrait;

    /**
     * @var \Magento\Customer\Model\AddressFactory
     */
    private $_addressFactory;

    /**
     * @var \Magento\Framework\App\ResourceConnection|mixed
     */
    private $_resources;

    public function __construct(
        Template\Context $context,
        Token $customerTokenManagement,
        TranApi $tranApi,
        Session $session,
        \Magento\Payment\Model\Config $paymentConfig,
        \Ebizcharge\Ebizcharge\Model\Config $config,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->customerTokenManagement = $customerTokenManagement;
        $this->_tran = $tranApi;
        $this->_customerSession = $session;
        $this->_paymentConfig = $paymentConfig;
        $this->_myConfig = $config;
        $this->_addressFactory = $addressFactory;

        $customer = $this->_customerSession->getCustomer();

        $this->_mage_cust_id = $customer->getId();
        $this->_ebzc_cust_id = $this->customerTokenManagement->getCollection()
            ->addFieldToFilter('mage_cust_id', $customer->getId())
            ->getFirstItem()
            ->getEbzcCustId();

        $customerData = $customer->getData(); //get all data of customers
        $this->_ebiz_internal_id = $customerData['ec_cust_internalid'];
        $this->_mage_cust_id = $customer->getId();

        $this->_resources = $config->getQueryResourceConnection();
    }

    public function getEbzcCustInternalId()
    {
        return $this->_ebiz_internal_id;
    }

    public function getEbzcCustId()
    {
        return $this->_ebzc_cust_id;
    }

    public function getMageCustId()
    {
        return $this->_mage_cust_id;
    }

    public function getEbzcMethodId()
    {
        return $this->getRequest()->getParam('mid');
    }
    public function first4digit($string)
    {
        $nums = explode(" ", $string);
        foreach ($nums as $num) {
            $number = $num ?? '';
            if ((strlen($number) == 4) && (preg_match_all('!\d+!', $num))) {
                return $num;
            }
        }
    }
    public function lastFourDigit($string)
    {
        if (!empty($string)) {
            $nums = explode(" ", $string);
            return !empty($nums[0]) ? substr($nums[0], -4) : null;
        } else {
            return null;
        }
    }
    public function getMID()
    {
        return $this->getRequest()->getParam('mid');
    }
    public function getPaymentIcons($cardType)
    {
        $imagePath = $this->getCardImagePath($cardType);
        $imagePath = $this->getViewFileUrl($imagePath);
        return $this->getImageTag($imagePath);
    }

    public function getMethodName()
    {
        $method = $this->getRequest()->getParam('method');
        return urldecode($method);
    }

    public function getBackUrl()
    {
        return $this->getUrl('customer/account/');
    }

    public function getAddCardUrl()
    {
        return $this->getUrl('ebizcharge/cards/addaction/');
    }

    public function getSaveUrl()
    {
        return $this->_urlBuilder->getUrl('ebizcharge/recurrings/saveaction', ['_secure' => true]);
    }

    public function getPaymentCards()
    {
        return $this->customerTokenManagement->getCollection()
            ->addFieldToFilter('mage_cust_id', $this->_customerSession->getCustomerId());
    }

    public function getPaymentMethods()
    {
        return $this->_tran->getCustomerPaymentMethods($this->_ebzc_cust_id);
    }

    public function getConfig($path)
    {
        return $this->_myConfig->getConfig($path);
    }

    public function getCcTypes()
    {
        return $this->_paymentConfig->getCcTypes();
    }

    public function getScheduleRecurringPaymentFiltered($recurringDetail)
    {
        if (!empty($recurringDetail)) {
            $connection = $this->_resources->getConnection();

            $negotiateTable = $this->_resources->getTableName('ebizcharge_recurring');

            $sql = "Select eb_rec_scheduled_payment_internal_id FROM   " . $negotiateTable . " WHERE rec_status != 3";
            $result = $connection->fetchall($sql);
            if (!empty($result)) {
                $keys = [];
                foreach ($result as $row) {
                    $mid = $row['eb_rec_scheduled_payment_internal_id'];
                    $key = array_search($mid, array_column($recurringDetail, 'ScheduledPaymentInternalId'));

                    if (is_numeric($key)) {
                        $keys[] = $key;
                    }
                }

                return $keys;
            }
        }

        return [];
    }

    public function getAllSearchRecurringPayments($customerId = null)
    {
        return $this->_tran->getSearchTransactions($customerId);
    }

    public function getLoggedInCustomerId()
    {
        $objectManager = $this->_myConfig->getObjectManagerInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');

        return $customerSession->getCustomer()->getId();
    }

    public function getCustomerDetail($customerID)
    {
        if (!empty($customerID)) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            return $objectManager->create('Magento\Customer\Model\Customer')->load($customerID);
        }

        return null;
    }

    public function getSearchScheduledRecurringPayments()
    {
        return $this->_tran->getSearchScheduledRecurringPayments(
            $this->getEbzcCustInternalId(),
            $this->getRequest()->getParam('mid')
        );
    }

    public function getReceiptRefNumber()
    {
        return $this->_tran->getReceiptRefNumber();
    }

    /* Add new payment functions */
    public function getRequestCardCode()
    {
        if ($this->_myConfig->getRequestCardCode() == 1) {
            return true;
        } else {
            return false;
        }
    }

    public function saveCardEnabled()
    {
        return $this->_myConfig->saveCard();
    }

    public function getPaymentCctypes()
    {
        return explode(',', $this->_myConfig->getPaymentCctypes());
    }

    public function getCcAvailableTypes()
    {
        $applicableTypes = $this->getPaymentCctypes();
        $types = $this->_paymentConfig->getCcTypes();

        foreach (array_keys($types) as $code) {
            if (!in_array($code, $applicableTypes)) {
                unset($types[$code]);
            }
        }

        return $types;
    }

    public function getCcMonths()
    {
        $months = $this->getData('cc_months');

        if ($months === null) {
            $months = $this->_myConfig->getMonths();
            $this->setData('cc_months', $months);
        }

        return $months;
    }

    public function getCcYears()
    {
        $years = $this->getData('cc_years');

        if ($years === null) {
            $years = $this->_paymentConfig->getYears();
            $years = [0 => __('Year')] + $years;
            $this->setData('cc_years', $years);
        }

        return $years;
    }

    public function getPaymentSavePayment()
    {
        return $this->_myConfig->getPaymentSavePayment();
    }

    /**
     * @param $orderId
     * @param null $shippingAddressId
     * @return |null
     */
    public function getCustomerShippingAddress($orderId, $shippingAddressId = null)
    {
        try {
            $connection = $this->_resources->getConnection();

            if (empty($orderId) || !empty($shippingAddressId)) {
                // fetch customer shipping address
                $addressCustomerTable = $this->_resources->getTableName('customer_address_entity');
                $sql = "Select * FROM " . $addressCustomerTable . " WHERE entity_id   = " . $shippingAddressId;
                $result = $connection->fetchall($sql);
            } else {
                $salesOrderTable = $this->_resources->getTableName('sales_order');
                $orderAddressTable = $this->_resources->getTableName('sales_order_address');
                $sql = "Select entity_id FROM " . $salesOrderTable . " WHERE increment_id  = '" . $orderId . "'";
                $row = $connection->fetchall($sql);

                $sql = "Select * FROM " . $orderAddressTable . " WHERE address_type = 'shipping' and  parent_id = '" . $row[0]['entity_id'] . "'";
                $result = $connection->fetchall($sql);
            }

            return $result[0] ?? null;

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @return array
     */
    public function getRecurring()
    {
        try {
            $paymentInternalId = $this->getMID();
            $connection = $this->_resources->getConnection();
            $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
            $sql = "Select * FROM   " . $recurringTable . " WHERE eb_rec_scheduled_payment_internal_id = '" . $paymentInternalId . "'";
            $recurring = $connection->fetchall($sql);
            if (isset($recurring[0])) {
                return $recurring[0];
            }
            return [];
        } catch (\Exception $e) {
            $this->_tran->log(__METHOD__ . $e->getMessage());
            return [];
        }
    }

    public function getRecurrings()
    {
        $connection = $this->_resources->getConnection();
        $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
        $customerTable = $this->_resources->getTableName('customer_entity');
        $productTable = $this->_resources->getTableName('catalog_product_entity');

        $sql = "Select * FROM " . $recurringTable . " as r
            INNER JOIN " . $customerTable . " as c on c.entity_id = r.mage_cust_id
			INNER JOIN " . $productTable . " as p on p.entity_id = r.mage_item_id
			WHERE mage_cust_id = " . $this->getMageCustId() . " AND rec_status != 3
            ORDER BY rec_id DESC limit 1000";

        return $connection->fetchall($sql);
    }

    public function getConfiguredFrequencies($selectedFrequency = null)
    {
        $this->_myConfig->getRecurringFrequencyOptions($selectedFrequency);
    }

    /**
     * if indefinite recurring is enabled in config
     *
     * @return bool
     */
    public function indefiniteRecurring(): bool
    {
        return $this->_myConfig->indefiniteRecurring();
    }
}
