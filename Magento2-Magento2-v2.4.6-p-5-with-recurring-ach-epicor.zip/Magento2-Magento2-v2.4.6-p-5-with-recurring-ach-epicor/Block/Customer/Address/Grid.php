<?php
namespace Ebizcharge\Ebizcharge\Block\Customer\Address;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Customer\Model\ResourceModel\Address\CollectionFactory as AddressCollectionFactory;
use Magento\Directory\Model\CountryFactory;

class Grid extends \Magento\Customer\Block\Address\Grid
{
    protected $_tran;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer,
        AddressCollectionFactory $addressCollectionFactory,
        CountryFactory $countryFactory,
        TranApi $tranApi,
        array $data = []
    )
    {
        parent::__construct($context, $currentCustomer, $addressCollectionFactory, $countryFactory, $data);

        $this->_tran = $tranApi;
    }

    public function isShippingAddressUsedInSubscription($shippingAddressId)
    {
        $queryParameters = array(
            'option' => 'select',
            'tableName' => 'ebizcharge_recurring',
            'tableFields' => 'shipping_address_id',
            'whereKey' => 'shipping_address_id',
            'whereValue' => $shippingAddressId
        );

        $recurringData = $this->_tran->runSelectQuery($queryParameters);
        $recurringData = reset($recurringData);

        return ($shippingAddressId == ($recurringData['shipping_address_id'] ?? null)) ? 'Yes' : 'No';
    }
}
