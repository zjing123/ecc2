<?php
/**
 * Accesses data to pass to the 'Manage My Payment Method' pages.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Block\Admin;

use Ebizcharge\Ebizcharge\Model\Token;
use Ebizcharge\Ebizcharge\Model\TranApi;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Customer\Model\CustomerIdProvider as AdminCustomerIdProvider;
use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;
use Ebizcharge\Ebizcharge\Model\CardTypeTrait;
use Magento\Customer\Model\ResourceModel\Customer\Collection;

class RecurringsAdmin extends Template
{
    private $customerTokenManagement;
    protected $_mage_cust_id;
    protected $_ebzc_cust_id;
    protected $_customerSession;
    protected $_tran;
    protected $_paymentConfig;
    protected $_myConfig;
    protected $objectManager;
    protected $_resources;
    use CardTypeTrait;

    /**
     * @var AdminCustomerIdProvider
     */
    private $adminCustomerIdProvider;
    private $pageLimit = 50;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\CollectionFactory
     */
    private $regionCollectionFactory;
    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    private $countryCollectionFactory;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $urlBuilder;

    /**
     * @var Collection
     */
    private $customerCollection;

    public function __construct(
        AdminCustomerIdProvider $adminCustomerIdProvider,
        Template\Context $context,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        Token $customerTokenManagement,
        TranApi $tranApi,
        Session $session,
        \Magento\Payment\Model\Config $paymentConfig,
        \Ebizcharge\Ebizcharge\Model\Config $config,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Shipping\Model\Config $shippingConfig,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        Collection $customerCollection,
        \Magento\Framework\UrlInterface $urlBuilder,
        ProductRepositoryInterface $productRepository,
        array $data = []
    )
    {
        $this->_customerFactory = $customerFactory;
        parent::__construct($context, $data);
        $this->customerTokenManagement = $customerTokenManagement;
        $this->_tran = $tranApi;
        $this->_customerSession = $session;
        $this->_paymentConfig = $paymentConfig;
        $this->_myConfig = $config;
        $this->_addressFactory = $addressFactory;
        $this->_resources = $config->getQueryResourceConnection();
        $this->objectManager = $config->getObjectManagerInstance();
        $this->_scopeConfig = $scopeConfig;
        $this->_shippingConfig = $shippingConfig;
        $this->adminCustomerIdProvider = $adminCustomerIdProvider;
        $this->regionCollectionFactory = $regionCollectionFactory;
        $this->countryCollectionFactory = $countryCollectionFactory;
        $this->productRepository = $productRepository;
        $this->urlBuilder = $urlBuilder;
        $this->customerCollection = $customerCollection;
    }

    public function getPaymentIcons($cardType)
    {
        $imagePath = $this->getCardImagePath($cardType);
        $imagePath = $this->getViewFileUrl($imagePath);
        return $this->getImageTag($imagePath);

    }

    public function getCardInfo($recPayment = [])
    {
        $cardInfo = '';
        $cardType = '';
        if (isset($recPayment->CreditCardData->CardType)) {
            $ccType = $recPayment->CreditCardData->CardType;
            if ($ccType == 'A') {
                $cardType = 'American Express';
            } elseif ($ccType == 'M') {
                $cardType = 'Master';
            } elseif ($ccType == 'V') {
                $cardType = 'Visa';
            } elseif ($ccType == 'DS') {
                $cardType = 'Discover';
            } else {
                $cardType = $ccType;
            }
            $accountType = '';
            $cardInfo = $recPayment->CreditCardData->CardNumber . ' - ' . $cardType;

        } else if (isset($recPayment->CheckData->AccountType)) {
            $accountType = $recPayment->CheckData->AccountType;
            $accountNumber = $recPayment->CheckData->Account;
            $cardInfo = $accountNumber . ' - ' . $accountType;
        }
        return $cardInfo;
    }

    public function lastFourDigit($string)
    {
        if (!empty($string)) {
            $nums = explode(" ", $string);
            return !empty($nums[0]) ? substr($nums[0], -4) : null;
        }
        return null;
    }

    public function methodName($string)
    {
        if (!empty($string)) {
            $names = explode(" - ", $string);
            return !empty($names[1]) ? $names[1] : null;
        }
        return null;
    }

    public function getCustomerDetail($customerID)
    {
        if (!empty($customerID)) {
            return $this->objectManager->create('Magento\Customer\Model\Customer')->load($customerID);
        }
        return null;
    }

    public function getOrderEntityId($orderIncrementId)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $collection = $objectManager->create('Magento\Sales\Model\Order');
        $order = $collection->loadByIncrementId($orderIncrementId);
        return $order->getId();
    }

    public function getCustomerAddressList($selectedId = '')
    {
        $dataClass = $this->objectManager->get('Ebizcharge\Ebizcharge\Model\Data');

        return $dataClass->getCustomerAddressList($this->getMageCustId(), $selectedId);
    }

    public function getCustomerCollection($id)
    {
        return $this->_customerFactory->create()->getCollection()
            ->addAttributeToSelect("firstname,lastname")
            ->addAttributeToFilter("entity_id", ["eq" => $id])
            ->load();
    }

    public function getEbzcCustInternalId()
    {
        $customer = $this->getCustomerDetail($this->getMageCustId());

        return isset($customer['ec_cust_internalid']) ? $customer['ec_cust_internalid'] : '';
    }

    public function getEbzcStart()
    {
        return $this->getRequest()->getParam('sid');
    }

    public function getEbzLimit()
    {
        return $this->getRequest()->getParam('limit');
    }

    public function getEbzcCustId()
    {
        return $this->getRequest()->getParam('cid');
    }

    public function getMageCustId()
    {
        return $this->getRequest()->getParam('magcid');
    }

    public function getPageNo()
    {
        return $this->getRequest()->getParam('page');
    }

    public function getEbzcMethodId()
    {
        return $this->getRequest()->getParam('mid');
    }

    public function getMethodName()
    {
        $method = $this->getRequest()->getParam('method');
        return urldecode($method);
    }

    public function getBackUrl()
    {
        return $this->getUrl('customer/account/');
    }

    public function getAddCardUrl()
    {
        return $this->getUrl('ebizcharge/cards/addaction/');
    }

    public function getSaveUrl()
    {
        return $this->_urlBuilder->getUrl('ebizcharge/recurrings/saveaction', ['_secure' => true]);
    }

    public function getPaymentCards()
    {
        return $this->customerTokenManagement->getCollection()
            ->addFieldToFilter('mage_cust_id', $this->_customerSession->getCustomerId());
    }

    public function getConfig($path)
    {
        return $this->_myConfig->getConfig($path);
    }

    public function getCcTypes()
    {
        return $this->_paymentConfig->getCcTypes();
    }

    public function getPaymentMethods()
    {
        $ebizCustomer = $this->_tran->getCustomer($this->getMageCustId());

        if ($ebizCustomer !== null) {
            $profiles = isset($ebizCustomer->PaymentMethodProfiles)
                ? $ebizCustomer->PaymentMethodProfiles->PaymentMethodProfile ?? []
                : [];

            if (is_object($profiles)) {
                $paymentMethods[] = $profiles;
            } else {
                $paymentMethods = $profiles;
            }
            return $paymentMethods;
        }

        return [];
    }

    // used for suspend recurring cronjob
    // Todo: Fix logic
    public function checkTransactionStatus()
    {
        $wsdl = $this->_tran->getWsdlUrl();
        $ueSecurityToken = $this->_tran->getUeSecurityToken();
        $client = new \Zend\Soap\Client($wsdl, $this->_tran->soapParams());

        $response = $client->SearchRecurringPayments(
            [
                'securityToken' => $ueSecurityToken,
                'fromDateTime' => '2020-12-01',
                'toDateTime' => date('Y-m-d'),
                'start' => 0,
                'limit' => 1000,
            ]
        );

        $recurringPayments = $response->SearchRecurringPaymentsResult->Payment;

        $declineTransactions = [];

        if (!empty($recurringPayments)) {

            foreach ($recurringPayments as $payment) {

                $responseGetTransactionDetails = $client->GetTransactionDetails(
                    [
                        'securityToken' => $ueSecurityToken,
                        'transactionRefNum' => $payment->RefNum,
                    ]
                );

                $transactionResult = $responseGetTransactionDetails->GetTransactionDetailsResult;
                $paymentRes = $transactionResult->Response;

                if ($paymentRes->ResultCode == 'D') {
                    $declineTransactions[$payment->ScheduledPaymentInternalId][] = 1;
                }
            }
        }

        if (!empty($declineTransactions)) {
            $this->_tran->log('Declined Found  ' . date("Y-m-d h:i:sa"));

            foreach ($declineTransactions as $scheduledPaymentInternalId => $val) {
                if (count($val) > 2) {
                    // suspend recurring
                    $params = [
                        'securityToken' => $ueSecurityToken,
                        'scheduledPaymentInternalId' => $scheduledPaymentInternalId,
                        'statusId' => 1,
                    ];

                    $client->ModifyScheduledRecurringPaymentStatus($params);
                }
            }
        }
    }

    public function getSearchScheduledRecurringPayments()
    {
        return $this->_tran->getSearchScheduledRecurringPayments(
            $this->getEbzcCustInternalId(),
            $this->getRequest()->getParam('mid')
        );
    }

    public function getAllSearchRecurringPayments($start = 0, $limit = 10)
    {
        return $this->_tran->getSearchTransactions(null, $start, $limit);
    }

    public function getCurrentPageCount()
    {
        return (($this->getCurrentPageNumber() - 1) * $this->pageLimit) + 1;
    }

    public function getPageLimit()
    {
        return $this->pageLimit;
    }

    public function getRecurrings()
    {
        $connection = $this->_resources->getConnection();
        $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
        $customerTable = $this->_resources->getTableName('customer_entity');
        $productTable = $this->_resources->getTableName('catalog_product_entity');
        $offset = ($this->getCurrentPageNumber() - 1) * $this->pageLimit;

        $where = 'where rec_status != 3 ';

        $searchTerm = $this->getSearchTerm();
        $searchTerm = $searchTerm == '%%' ? 'emp' : $searchTerm;
        if (!empty($searchTerm) && 'emp' != $searchTerm) {
            $searchTerm = "'%$searchTerm%'";
            $where = "AND concat_ws(' ', firstname, lastname, mage_cust_id, email, sku, mage_item_name, qty_ordered, eb_rec_frequency, amount, payment_method_name) like " . $searchTerm;
        }

        $sql = "Select * FROM " . $recurringTable . " as r
         INNER JOIN " . $customerTable . " as c on c.entity_id = r.mage_cust_id
			INNER JOIN " . $productTable . " as p on p.entity_id = r.mage_item_id "
            . $where . " order by rec_id DESC limit " . $this->pageLimit . " offset " . $offset;

        return $connection->fetchall($sql);
    }

    public function getReceiptRefNumber()
    {
        return $this->_tran->getReceiptRefNumber();
    }

    /* Add new payment functions */
    public function getRequestCardCodeAdmin()
    {
        return $this->_myConfig->getRequestCardCodeAdmin() == 1;
    }

    public function saveCardEnabled()
    {
        return $this->_myConfig->saveCard();
    }

    public function getPaymentCctypes()
    {
        return explode(',', $this->_myConfig->getPaymentCctypes());
    }

    public function getCcAvailableTypes()
    {
        $applicableTypes = $this->getPaymentCctypes();
        $types = $this->_paymentConfig->getCcTypes();

        foreach (array_keys($types) as $code) {
            if (!in_array($code, $applicableTypes)) {
                unset($types[$code]);
            }
        }

        return $types;
    }

    public function getCcMonths()
    {
        $months = $this->getData('cc_months');

        if ($months === null) {
            $months = $this->_myConfig->getMonths();

            $this->setData('cc_months', $months);
        }

        return $months;
    }

    public function getCcYears()
    {
        $years = $this->getData('cc_years');

        if ($years === null) {
            $years = $this->_paymentConfig->getYears();
            $years = [0 => __('Year')] + $years;
            $this->setData('cc_years', $years);
        }

        return $years;
    }

    public function getPaymentSavePayment()
    {
        return $this->_myConfig->getPaymentSavePayment();
    }

    //*********** for add new subscription **************//

    public function getAllItemsList()
    {
        $productCollection = $this->objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');

        $collection = $productCollection->create()
            ->addAttributeToSelect('*')
            ->addAttributeToSort('name')
            ->load();

        foreach ($collection as $product) {
            $itemPrice = (!empty($product->getFinalPrice()))
                ? $product->getFinalPrice()
                : $product->getPrice();

            if (($product->getTypeId() != 'configurable') && ($product->getTypeId() != 'grouped') && ($itemPrice > 0)) {
                $productId = $product->getId();
                ?>
                <option value="<?php echo $productId; ?>">
                    <?php echo $productId . ' - ' . $product->getName() . ' [' . $product->getSku() . '] ' ?>
                    (<?php echo "Price: " . number_format((float)$itemPrice, 2, '.', ''); ?>)
                </option>
                <?php
            }
        }
    }

    public function getAllActiveCustomersListWithSubscription()
    {
        $connection = $this->_resources->getConnection();
        $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
        $customerTableName = $this->_resources->getTableName('customer_entity');

        $sql = "SELECT DISTINCT r.mage_cust_id, c.entity_id, c.firstname, c.lastname, c.email
                FROM " . $recurringTable . " as r
                INNER JOIN " . $customerTableName . " as c on r.mage_cust_id = c.entity_id
                WHERE r.rec_status = 0";

        $customerCollection = $connection->fetchall($sql);

        if ($customerCollection && count($customerCollection) > 0) {
            foreach ($customerCollection as $customer) { ?>
                <option value="<?php echo $customer['entity_id']; ?>">
                    <?php echo $customer['firstname'] . ' ' . $customer['lastname']; ?>
                    (<?php echo $customer['email']; ?>)
                </option>
                <?php
            }
        }
    }

    /**
     * @param $orderId
     * @param null $shippingAddressId
     * @return |null
     */
    public function getCustomerShippingAddress($orderId, $shippingAddressId = null)
    {
        try {
            $connection = $this->_resources->getConnection();

            if (empty($orderId) || !empty($shippingAddressId)) {
                // fetch customer shipping address
                $addressCustomerTable = $this->_resources->getTableName('customer_address_entity');
                $sql = "Select * FROM " . $addressCustomerTable . " WHERE entity_id   = " . $shippingAddressId;

                $address = $connection->fetchall($sql);

            } else {
                $salesOrderTable = $this->_resources->getTableName('sales_order');
                $orderAddressTable = $this->_resources->getTableName('sales_order_address');
                $sql = "Select entity_id FROM " . $salesOrderTable . " WHERE increment_id  = '" . $orderId . "'";

                $row = $connection->fetchall($sql);

                $sql = "Select * FROM " . $orderAddressTable . " WHERE address_type = 'shipping' and  parent_id = '" . $row[0]['entity_id'] . "'";
                $address = $connection->fetchall($sql);
            }

            if (isset($address[0])) {
                return $address[0];
            }
            return [];

        } catch (\Exception $e) {
            return null;
        }
    }

    public function getRecurring()
    {
        try {
            $paymentInternalId = $this->getEbzcMethodId();

            $connection = $this->_resources->getConnection();
            $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
            $sql = "Select * FROM   " . $recurringTable . " WHERE eb_rec_scheduled_payment_internal_id = '" . $paymentInternalId . "'";

            $recurring = $connection->fetchall($sql);
            if (isset($recurring[0])) {
                return $recurring[0];
            }
            return [];

        } catch (\Exception $e) {
            $this->_tran->log(__METHOD__ . $e->getMessage());
            return [];
        }
    }

    public function getRecurringOrders($current, $limit)
    {
        try {
            $connection = $this->_resources->getConnection();
            $recurringOrderTable = $this->_resources->getTableName('ebizcharge_recurring_order');
            $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');

            $sql = "Select * FROM " . $recurringOrderTable . " ro
                    INNER JOIN $recurringTable as r ON ro.recurring_id = r.rec_id
                    order by created_date DESC limit $limit OFFSET $current";

            return $connection->fetchall($sql);

        } catch (\Exception $e) {
            $this->_tran->log(__METHOD__ . $e->getMessage());
            return [];
        }
    }

    /**
     * @param null $selectedMethod
     */
    public function getShippingMethods($selectedMethod = null)
    {
        $carriers = $this->_shippingConfig->getAllCarriers();
        foreach ($carriers as $carrierCode => $carrierModel) {
            if ($carrierModel->isActive()) {
                $carrierMethods = $carrierModel->getAllowedMethods();
                if ($carrierMethods) {
                    //$carrierTitle = $this->_scopeConfig->getValue('carriers/' . $carrierCode . '/title',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    foreach ($carrierMethods as $methodCode => $methodTitle) {
                        $value = $carrierCode . '_' . $methodCode;
                        $title = $methodTitle . ' [' . $carrierCode . ']'; ?>
                        <option value="<?php echo $value ?>"<?php if ($value == $selectedMethod) {
                            echo 'selected';
                        } ?>>
                            <?php echo $title ?>
                        </option>

                        <?php
                    }
                }
            }
        }
    }

    public function getConfiguredFrequencies($selectedFrequency = null)
    {
        $this->_myConfig->getRecurringFrequencyOptions($selectedFrequency);
    }

    public function getPriceByTierGroup($productId, $customerId, $qty)
    {
        $dataClass = $this->objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
        return $dataClass->getProductPriceWithTierGroup($productId, $customerId, $qty);
    }

    /**
     * Get count for total number of records
     * @return int
     */
    public function getRecordsCount()
    {
        $connection = $this->_resources->getConnection();
        $recurringTable = $this->_resources->getTableName('ebizcharge_recurring');
        $customerTable = $this->_resources->getTableName('customer_entity');
        $productTable = $this->_resources->getTableName('catalog_product_entity');

        $where = 'where rec_status != 3 ';

        if ('emp' != $searchTerm = $this->getSearchTerm()) {
            $searchTerm = "'%$searchTerm%'";
            $where = " AND concat_ws(' ', firstname, lastname, mage_cust_id, email, sku, mage_item_name, qty_ordered, eb_rec_frequency, amount, payment_method_name) like " . $searchTerm;
        }

        $sql = "Select COUNT(*) FROM " . $recurringTable . " as r
            INNER JOIN " . $customerTable . " as c on c.entity_id = r.mage_cust_id
			INNER JOIN " . $productTable . " as p on p.entity_id = r.mage_item_id " . $where;

        return $connection->fetchOne($sql);
    }

    /**
     * Get total number of pages
     * @return int
     */
    public function getPageCount()
    {
        return ceil($this->getRecordsCount() / $this->pageLimit);
    }

    /**
     * Get current page number, default 1
     * @return string
     */
    public function getCurrentPageNumber()
    {
        return $this->_request->getParam('p', 1);
    }

    /**
     * Get url for next page
     * @return string
     */
    public function getNextPageUrl()
    {
        $nextPage = $this->getCurrentPageNumber();
        if ($this->getCurrentPageNumber() < $this->getPageCount()) {
            $nextPage = $this->getCurrentPageNumber() + 1;
        }
        $searchParam = '/s/emp';
        if ($searchTerm = $this->getSearchTerm()) {
            $searchParam = '/s/' . $searchTerm;
        }
        return $this->getUrl('*/*/index/p/' . $nextPage . $searchParam);
    }

    /**
     * Get url for previous page
     * @return string
     */
    public function getPrevPageUrl()
    {
        $prePage = $this->getCurrentPageNumber();
        if ($this->getCurrentPageNumber() > 1) {
            $prePage = $this->getCurrentPageNumber() - 1;
        }
        $searchParam = '/s/emp';
        if ($searchTerm = $this->getSearchTerm()) {
            $searchParam = '/s/' . $searchTerm;
        }
        return $this->getUrl('*/*/*/p/' . $prePage . $searchParam);
    }

    /**
     * Get the search Term
     * @return string|null
     */
    public function getSearchTerm()
    {
        return $this->_request->getParam('s');
    }

    public function getCustomerIdAdmin()
    {
        return $this->adminCustomerIdProvider->getCustomerId();
    }

    public function getCustomerPaymentMethodProfile()
    {
        $ebzcCustomerId = $this->_request->getParam('cid');
        $ebzcMethodId = $this->_request->getParam('mid');
        return $this->_tran->getCustomerPaymentMethodProfile($ebzcCustomerId, $ebzcMethodId);
    }

    public function getAction()
    {
        return $this->_request->getParam('action');
    }

    public function getAchStatus()
    {
        return $this->_myConfig->isAchActive();
    }

    public function first4digit($string)
    {
        $nums = explode(" ", $string);
        foreach ($nums as $num) {
            $number = $num ?? '';
            if ((strlen($number) == 4) && (preg_match_all('!\d+!', $num))) {
                return $num;
            }
        }
    }

    /**
     * Returns country region html select
     *
     * @return string
     */
    public function getCountryRegionSelect()
    {
        try {
            $options = $this->regionCollectionFactory->create()->addCountryFilter('US')->load()->toOptionArray();

            return $this->getLayout()->createBlock(
                \Magento\Framework\View\Element\Html\Select::class
            )->setName(
                'ship_region'
            )->setTitle(
                __('State/Province')
            )->setId(
                'region_id'
            )->setClass(
                'input-text admin__control-text admin__control-select required-entry validate-state'
            )->setValue(
                null
            )->setOptions(
                $options
            )->getHtml();
        } catch (\Exception $e) {
            return '';
        }
    }

    /**
     * Returns country html select
     *
     * @return string
     */
    public function getCountrySelect()
    {
        try {
            $options = $this->countryCollectionFactory->create()->load()->toOptionArray();

            return $this->getLayout()->createBlock(
                \Magento\Framework\View\Element\Html\Select::class
            )->setName(
                'ship_country'
            )->setTitle(
                __('Country')
            )->setId(
                'country'
            )->setClass(
                'input-text admin__control-text admin__control-select required-entry validate-state'
            )->setValue(
                'US'
            )->setOptions(
                $options
            )->getHtml();
        } catch (\Exception $e) {
            return '';
        }
    }


    /**
     * Get product details
     * @param $productId
     * @return \Magento\Catalog\Api\Data\ProductInterface|false
     */
    public function getProductDetails($productId)
    {
        try {
            return $this->productRepository->getById($productId);
        } catch (\Exception $e) {
            return false;
        }
    }


    /**
     * Get customer suggestions
     *
     * @param $searchParams
     * @return array|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getCustomerSuggestions($searchParams = [])
    {
        $keywords = $searchParams['keywords'] ?? '';
        return $this->customerCollection
            ->addAttributeToSelect('*')
            ->addExpressionAttributeToSelect('full_name', new \Zend_Db_Expr("CONCAT(`firstname`, ' ', `lastname`)"), [])
            ->addFieldToFilter(
                [
                    ['attribute' => 'email', 'like' => '%' . $keywords . '%'],
                    ['attribute' => 'full_name', 'like' => '%' . $keywords . '%'],
                    ['attribute' => 'entity_id', 'like' => '%' . $keywords . '%']
                ]
            )->setPageSize(10)
            ->setCurPage(1)
            ->load()
            ->getData();
    }

    /**
     * customer search url for ajax
     * @return string
     */
    public function getCustomerSearchUrl()
    {
        return $this->urlBuilder->getUrl('ebizcharge_ebizcharge/recurrings/customersearch');
    }

    /**
     * Reset filter url
     * @return string|null
     */
    public function getResetUrl()
    {
        $searchTerm = $this->_request->getParam('s', 'emp');
        if ($searchTerm != 'emp') {
            return $this->urlBuilder->getUrl('ebizcharge_ebizcharge/recurrings/index/p/1/s/emp');
        }
        return null;
    }
}
