<?php
/**
* Declares the block for the EBizCharge payment method - utilized in adminhtml.
*
* @author      Century Business Solutions <support@centurybizsolutions.com>
* @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
*/
namespace Ebizcharge\Ebizcharge\Block\Form;

use Magento\Catalog\Helper\Data;

class Recurring extends \Magento\Payment\Block\Form
{
    protected $_template = 'Ebizcharge_Ebizcharge::recurring.phtml';

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Ebizcharge\Ebizcharge\Model\TranApi $tranApi,
        \Ebizcharge\Ebizcharge\Model\Token $token,
        \Ebizcharge\Ebizcharge\Model\Config $config,
        Data $helper,
        array $data = []
    )
    {
        parent::__construct($context, $data);
        $this->_tran = $tranApi;
        $this->_token = $token;
        $this->config = $config;
        $this->helper = $helper;
    }

    public function isEbizChargeActive()
    {
        return $this->config->isActive();
    }

    public function isRecurringEnabled()
    {
        return $this->config->isRecurringEnabled() == 1;
    }

    public function showRecurringForm()
    {
        return $this->isEbizchargeActive() && $this->isRecurringEnabled();
    }

    public function isCustomerLoggedIn()
    {
        $objectManager = $this->config->getObjectManagerInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        return $customerSession->isLoggedIn();
    }

    public function getLoggedInCustomerId()
    {
        $objectManager = $this->config->getObjectManagerInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        return $customerSession->getCustomer()->getId();
    }

    public function getConfiguredFrequencies($selectedFrequency = null)
    {
        $this->config->getRecurringFrequencyOptions($selectedFrequency);
    }

    /**
     * if indefinite recurring is enabled in config
     *
     * @return bool
     */
    public function indefiniteRecurring(): bool
    {
        return $this->config->indefiniteRecurring();
    }
}
