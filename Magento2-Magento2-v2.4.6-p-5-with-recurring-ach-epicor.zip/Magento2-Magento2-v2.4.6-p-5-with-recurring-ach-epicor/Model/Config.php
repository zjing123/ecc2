<?php
/**
 * Provides access to the admin settings for Ebizcharge.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Model;

use Ebizcharge\Ebizcharge\Model\Source\RecurringFrequencyType;
use Magento\Framework\App\Area;
use Magento\Framework\Locale\Bundle\DataBundle;
use Magento\Framework\Locale\ResolverInterface as ResolverInterface;
use Magento\Store\Model\ScopeInterface;

class Config
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfigInterface;
    protected $customerSession;
    protected $appState;
    protected $storeManager;
    protected $urlBuilder;
    protected $frequencyType;

    const KEY_ACTIVE = 'active';

    /**
     * @var EbizCustomLogger
     */
    private $ebizCustomLogger;
    /**
     * @var ResolverInterface
     */
    private $localeResolver;

    /**
     * @var \Magento\Backend\Model\Session\Quote
     */
    private $sessionQuote;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $configInterface
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Backend\Model\Session\Quote $sessionQuote
     * @param \Magento\Framework\App\State $appState
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param RecurringFrequencyType $frequencyType
     * @param EbizCustomLogger $ebizCustomLogger
     * @param ResolverInterface $localeResolver
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $configInterface,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Backend\Model\Session\Quote $sessionQuote,
        \Magento\Framework\App\State $appState,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlBuilder,
        RecurringFrequencyType $frequencyType,
        EbizCustomLogger $ebizCustomLogger,
        ResolverInterface $localeResolver
    ) {
        $this->_scopeConfigInterface = $configInterface;
        $this->customerSession = $customerSession;
        $this->sessionQuote = $sessionQuote;
        $this->appState = $appState;
        $this->storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder;
        $this->frequencyType = $frequencyType;
        $this->ebizCustomLogger = $ebizCustomLogger;
        $this->localeResolver = $localeResolver;
    }

    public function log($message, $level = null)
    {
        $this->ebizCustomLogger->ebizPaymentLogger->info($message);
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return (bool)(int)$this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/active', ScopeInterface::SCOPE_STORE);
    }

    public function isAchActive()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/enableAch', ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentCctypes()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/cctypes', ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentCurrency()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/currency', ScopeInterface::SCOPE_STORE);
    }

    /**
     * checkout card atomically saved when saved/update card use enabled
     * @Frank request
     * @return bool|mixed
     */
    public function getPaymentSavePayment()
    {
        $autoSaveCard = $this->getConfig('payment/ebizcharge_ebizcharge/save_payment');

        if ($this->getArea() == Area::AREA_ADMINHTML) {
            return $autoSaveCard;
        }

        return (bool) $this->showSavedMethodsCheckout() && $autoSaveCard;
    }

    public function getPaymentMinordertotal()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/min_order_total', ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentMaxordertotal()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/max_order_total', ScopeInterface::SCOPE_STORE);
    }

    public function isAuthorizeOnly()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/payment_action', ScopeInterface::SCOPE_STORE) == 'authorize';
    }

    public function saveCard()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/save_card', ScopeInterface::SCOPE_STORE) && ($this->customerSession->isLoggedIn() || $this->sessionQuote->getCustomerId());
    }

    public function getEbizActive()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/active', ScopeInterface::SCOPE_STORE);
    }

    public function getSourceKey()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/sourcekey', ScopeInterface::SCOPE_STORE);
    }

    public function getSourceId()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/sourceid', ScopeInterface::SCOPE_STORE);
    }

    public function getSourcePin()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/sourcepin', ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentDescription()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/description', ScopeInterface::SCOPE_STORE);
    }

    public function debugMode($code)
    {
        return !!$this->_scopeConfigInterface->getValue('payment/' . $code . '/debug', ScopeInterface::SCOPE_STORE);
    }

    public function getRequestCardCode()
    {
        return 1;
        // Removed setting from admin
        //return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/request_card_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getRequestCardCodeAdmin()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/request_card_code_admin', ScopeInterface::SCOPE_STORE);
    }

    public function getPaymentAction()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/payment_action', ScopeInterface::SCOPE_STORE);
    }

    public function getCustreceiptTemplate()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/custreceipt_template', ScopeInterface::SCOPE_STORE);
    }

    public function getArea()
    {
        return $this->appState->getAreaCode();
    }

    public function getDeleteURL()
    {
        return $this->urlBuilder->getUrl('ebizcharge/cards/inlineaction');
        //$this->_storeManager->getStore()->getUrl('ebizcharge/cards/inlineaction');
    }

    public function getBaseDeleteURL()
    {
        return $this->urlBuilder->getBaseUrl();
    }

    public function getConfig($path)
    {
        return $this->_scopeConfigInterface->getValue($path, ScopeInterface::SCOPE_STORE);
    }

    public function getEconnect()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/econnect', ScopeInterface::SCOPE_STORE);
    }

    public function isEbizchargeActive()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/active', ScopeInterface::SCOPE_STORE);
    }

    public function isRecurringActive()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/recurring_payments', ScopeInterface::SCOPE_STORE);
    }

    public function isRecurringEnabled()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/recurring_payments', ScopeInterface::SCOPE_STORE);
    }

    public function isEconnectUploadEnabled()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/uploadeconnect', ScopeInterface::SCOPE_STORE);
    }

    public function isEconnectDownlaodEnabled()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/downloadeconnect', ScopeInterface::SCOPE_STORE);
    }

    public function isShippingSelected()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/shippingmethod', ScopeInterface::SCOPE_STORE);
    }

    public function getObjectManagerInstance()
    {
        return \Magento\Framework\App\ObjectManager::getInstance();
    }

    public function getQueryResourceConnection()
    {
        // Getting Db resource connection for query Run start
        return $this->getObjectManagerInstance()->get('Magento\Framework\App\ResourceConnection');
    }

    public function getRecurringFrequencies()
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/recurring_frequency', ScopeInterface::SCOPE_STORE);
    }

    /**
     * Disable auto void on order cancel
     * @return bool
     */
    public function disableAutoVoid(): bool
    {
        return $this->_scopeConfigInterface->getValue('payment/ebizcharge_ebizcharge/disable_void', ScopeInterface::SCOPE_STORE);
    }

    /**
     * Show saved/update cards/bankAccounts on customer checkout
     * @Frank request
     *
     * @return bool
     */
    public function showSavedMethodsCheckout(): bool
    {
        return (bool) $this->getArea() == Area::AREA_FRONTEND && $this->getConfig('payment/ebizcharge_ebizcharge/show_saved_methods');
    }

    public function getRecurringFrequencyOptions($selectedFrequency = null)
    {
        $frequencies = $this->frequencyType->options();

        $selectedOptions = explode(',', $this->getRecurringFrequencies());
        if (empty($selectedOptions)) {
            $selectedOptions = array_keys($frequencies);
        }

        foreach ($selectedOptions as $option) { ?>
            <option value="<?php echo $option ?>"<?php if ($option == $selectedFrequency) {
            echo 'selected';
        } ?>>
                <?php echo isset($frequencies[$option]) ? $frequencies[$option] : $option;?>
            </option>
            <?php
        }
    }

    public function getCartPageURL()
    {
        return $this->_storeManager->getStore()->getUrl('checkout/cart');
    }

    /**
     * Check if indefinite recurring is enabled for customer or not
     *
     * @return bool
     */
    public function indefiniteRecurring(): bool
    {
        return $this->getConfig('payment/ebizcharge_ebizcharge/indefinite_recurring');
    }

    /**
     * Retrieve list of months
     * @return array
     */
    public function getMonths()
    {
        $data = [];
        $months = (new DataBundle())->get(
            $this->localeResolver->getLocale()
        )['calendar']['gregorian']['monthNames']['format']['wide'];
        foreach ($months as $key => $value) {
            $monthNum = ++$key < 10 ? '0' . $key : $key;
            $data[$monthNum] = $monthNum . ' - ' . $value;
        }
        return $data;
    }

    /**
     * Get ebizcharge default shipping method
     * @param $storeId
     * @return mixed
     */
    public function getDefaultShippingMethod($storeId = null) {
        return $this->_scopeConfigInterface->getValue(
            'payment/ebizcharge_ebizcharge/shippingmethod',
            ScopeInterface::SCOPE_STORE,
            $storeId);
    }
}
