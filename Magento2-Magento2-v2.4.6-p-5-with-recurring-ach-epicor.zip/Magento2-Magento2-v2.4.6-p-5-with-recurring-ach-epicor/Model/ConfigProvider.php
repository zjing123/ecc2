<?php
declare(strict_types=1);
/**
 * Connects the EBizCharge method renderer to the system config.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Model;

use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\CcConfig;
use Magento\Payment\Model\CcGenericConfigProvider;

/**
 * Class ConfigProvider
 * @package Ebizcharge\Ebizcharge\Model
 */
class ConfigProvider extends CcGenericConfigProvider
{
    /**
     * Payment method code
     */
    const METHOD_CODE = 'ebizcharge_ebizcharge';

    /**
     * @var string[]
     */
    protected $methodCodes = [
        self::METHOD_CODE
    ];

    /**
     * @var Config
     */
    private $config;

    /**
     * ConfigProvider constructor.
     * @param Config $config
     * @param CcConfig $ccConfig
     * @param PaymentHelper $paymentHelper
     * @param array $methodCodes
     */
    public function __construct(
        Config $config,
        CcConfig $ccConfig,
        PaymentHelper $paymentHelper,
        array $methodCodes = []
    ) {
        parent::__construct($ccConfig, $paymentHelper, $methodCodes);
        $this->config = $config;
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        if (!$this->config->isActive()) {
            return [];
        }

        $config = []; // parent::getConfig();

        $config = array_merge_recursive($config, [
            'payment' => [
                'ebizcharge' => [
                    'sourcekey' => $this->config->getSourceKey(),
                    'getDeleteURL' => $this->config->getDeleteURL(),
                    'useVault' => $this->methods[self::METHOD_CODE]->hasToken(),
                    'getEbzcCustId' => $this->methods[self::METHOD_CODE]->getEbzcCustId(),
                    'storedCards' => $this->methods[self::METHOD_CODE]->getSavedCards(),
                    'storedAccounts' => $this->methods[self::METHOD_CODE]->getSavedAccounts(),
                    'saveCard' => $this->config->getPaymentSavePayment() == 1,
                    'requestCardCode' => $this->config->getRequestCardCode() == 1,
                    'isAchActive' => $this->config->isAchActive(),
                    'getAchAccountTypes' => ['checking' => 'Checking', 'savings' => 'Savings'],
                    'isRecurringEnabled' => $this->config->isRecurringEnabled(),
                    'hasToken' => $this->methods[self::METHOD_CODE]->hasToken(),
                    'months' => $this->config->getMonths(),
                    'showSavedMethods' => $this->config->showSavedMethodsCheckout()
                ],
            ],
        ]);

        return $config;
    }
}
