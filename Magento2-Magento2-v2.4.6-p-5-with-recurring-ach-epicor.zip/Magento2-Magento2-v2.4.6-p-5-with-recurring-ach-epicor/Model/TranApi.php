<?php
/**
 * EBizCharge Transaction Class.
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Model;

define("EBIZCHARGE_VERSION", "2.4.4");
ini_set('memory_limit', '1000M');
ini_set('max_execution_time', 300);

class TranApi
{
    const EBIZCHARGE_VERSION = "2.4.4";
    // Required for all transactions
    public $userid = null;   // User Id
    public $key = null;   // Source key/ security Id
    public $pin = null;   // Source pin/password (optional)
    public $amount = null;  // the entire amount that will be charged to the customers card

    // (including tax, shipping, etc)
    public  $invoice = null;  // invoice number.  must be unique.limited to 10 digits.  use orderid if you need longer.

    // Required for Commercial Card support
    public  $ponum = null;   // Purchase Order Number
    public  $tax = null;   // Tax
    public $nontaxable = null; // Order is non taxable

    // Amount details (optional)
    public  $tip = null;    // Tip
    public float $shipping = 0;  // Shipping charge
    public float $discount = 0;  // Discount amount (ie gift certificate or coupon code)
    public float $subtotal = 0;  // if subtotal is set, then

    // subtotal + tip + shipping - discount + tax must equal amount
    // or the transaction will be declined.  If subtotal is left blank
    // then it will be ignored
    public $currency = null;  // Currency of $amount

    // Required Fields for Card Not Present transacitons (Ecommerce)
    public $card = null;   // card number, no dashes, no spaces
    public $cardtype = null;  //type of the card
    public $exp = null;   // expiration date 4 digits no /
    public $cardholder = null;  // name of card holderPlease enter a valid credit card type number.
    public  $street = null;  // street address
    public  $zip = null;   // zip code
    public  $savedMethodId = null;   // current saved method Id

    // Required Fields for Ach

    public $achroute = null;
    public $achtype = null;

    // Fields for Card Present (POS)
    public  $magstripe = null;   // mag stripe data.  can be either Track 1, Track2  or  Both  (Required if card,exp,cardholder,street and zip aren't filled in)
    public bool $cardpresent = false;   // Must be set to true if processing a card present transaction  (Default is false)

    // fields required for check transactions
    public $account = null;  // bank account number
    public $routing = null;  // bank routing number

    // Fields required for Secure Vault Payments (Direct Pay)
    public  $svpbank = null;  // ID of cardholders bank
    public  $svpreturnurl = null; // URL that the bank should return the user to when tran is completed
    public  $svpcancelurl = null;  // URL that the bank should return the user if they cancel

    // Option parameters
    public  $origauthcode = null; // required if running postauth transaction.
    public  $command = null;  // type of command to run; Possible values are:

    // sale, credit, void, preauth, postauth, check and checkcredit.
    // Default is sale.
    public  $orderid = null;  // Unique order identifier.  This field can be used to reference
    // the order for which this transaction corresponds to. This field
    // can contain up to 64 characters and should be used instead of
    // UMinvoice when orderids longer that 10 digits are needed.
    public  $custid = null;   // Alpha-numeric id that uniquely identifies the customer.
    public $description = null; // description of charge
    public $cvv2 = null;   // cvv2 code
    public  $custemail = null;  // customers email address
    public bool $custreceipt = false; // send customer a receipt
    public $custreceipt_template = null; // select receipt template
    public  $ignoreduplicate = null; // prevent the system from detecting and folding duplicates
    public $ip = null;   // ip address of remote host
    public $timeout = null;       // transaction timeout.  defaults to 45 seconds

    // Recurring Billing
    public  $recurring = null;  //  Save transaction as a recurring transaction:  yes/no
    public  $schedule = null;  //  How often to run transaction: daily, weekly, biweekly, monthly, bimonthly, quarterly, annually.  Default is monthly.
    public  $numleft = null;   //  The number of times to run. Either a number or * for unlimited.  Default is unlimited.
    public  $start = null;   //  When to start the schedule.  Default is tomorrow.  Must be in YYYYMMDD  format.
    public  $expire = null;   //  When to stop running transactions. Default is to run forever.  If both end and numleft are specified, transaction will stop when the ealiest condition is met.
    public  $recurringIndefinitely = null;   //  Method ID to set for recurring payment.
    public $recurringMethodId = null;   //  Method ID to set for recurring payment.
    public $billamount = null; //  Optional recurring billing amount.  If not specified, the amount field will be used for future recurring billing payments
    public $billtax = null;
    public $billsourcekey = null;

    // Billing Fields
    public  $billfname = null;
    public  $billlname = null;
    public  $billcompany = null;
    public  $billstreet = null;
    public  $billstreet2 = null;
    public  $billcity = null;
    public  $billstate = null;
    public  $billzip = null;
    public  $billcountry = null;
    public $billphone = null;
    public $email = null;
    public $fax = null;
    public $website = null;

    // Shipping Fields
    public string $delivery ="";  // type of delivery method ('ship','pickup','download')
    public string $shipfname ="";
    public string $shiplname ="";
    public string $shipcompany ="";
    public string $shipstreet ="";
    public string $shipstreet2 ="";
    public string $shipcity ="";
    public string $shipstate ="";
    public string $shipzip ="";
    public string $shipcountry ="";
    public string $shipphone ="";

    // Line items  (see addLine)
    public $lineitems = null;

    // Line items for tokenization (see addLineItem())
    public $lineItems = null;

    // Recurring items for add recurrings
    //public $recurringLineItems;

    public string $comments =""; // Additional transaction details or comments (free form text field supports up to 65,000 chars)
    public string $software =""; // Allows developers to identify their application to the gateway (for troubleshooting purposes)

    // response fields
    public string $rawresult ="";  // raw result from gateway
    public string $result ="";  // full result:  Approved, Declined, Error
    public string $resultcode ="";  // abreviated result code: A D E
    public string $authcode ="";  // authorization code
    public string $refnum;  // reference number
    public string $batch ="";  // batch number
    public string $avs_result ="";  // avs result
    public string $avs_result_code ="";  // avs result
    public string $avs ="";       // obsolete avs result
    public string $cvv2_result ="";  // cvv2 result
    public string $cvv2_result_code ="";  // cvv2 result
    public string $vpas_result_code ="";      // vpas result
    public string $isduplicate ="";      // system identified transaction as a duplicate
    public string $convertedamount ="";  // transaction amount after server has converted it to merchants currency
    public string $convertedamountcurrency ="";  // merchants currency
    public string $conversionrate ="";  // the conversion rate that was used
    public string $custnum ="";  //  gateway assigned customer ref number for recurring billing

    // Cardinal Response Fields
    public string $acsurl =""; // card auth url
    public string $pareq ="";  // card auth request
    public string $cctransid =""; // cardinal transid

    // Errors Response Fields
    public string $error = "";   // error message if result is an error
    public $errorcode = null;  // numerical error code
    // For TranAPI Config import
    protected $_token = null;
    protected $config = null;
    public $tokenFactory = null;
    protected $_paymentConfig = null;
    public \SoapClient|null $soapClient = null;
    public bool $achStatus = false;
    const  ACH = 'ACH';
    /**
     * @var EbizCustomLogger
     */
    private $ebizCustomLogger = null;

    public $order = null;

    public $ebiz_version = null;


    public const EBIZCHARGE_TRANSACTION_ERROR = 'Transaction failed, please try again and contact admin if issue persists.';

    /**
     * Epi cor customer management
     * @var  \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount
     */
    private $epiCorCustomer;

    /**
     * @param Token $tokenFactory
     * @param \Magento\Payment\Model\Config $paymentConfig
     * @param Token $token
     * @param Config $config
     * @param \Magento\Sales\Model\OrderFactory $order
     * @param EbizCustomLogger $ebizCustomLogger
     * @param Proxy\ErpAccount $epiCorCustomer
     */
    public function __construct(
        //\Ebizcharge\Ebizcharge\Model\TokenFactory $tokenFactory,
        \Ebizcharge\Ebizcharge\Model\Token            $tokenFactory,
        \Magento\Payment\Model\Config                 $paymentConfig,
        // For TranAPI Config import
        \Ebizcharge\Ebizcharge\Model\Token            $token,
        \Ebizcharge\Ebizcharge\Model\Config           $config,
        \Magento\Sales\Model\OrderFactory             $order,
        EbizCustomLogger                              $ebizCustomLogger,
        \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount $epiCorCustomer
    )
    {
        // Set default values.
        $this->tokenFactory = $tokenFactory;
        $this->_paymentConfig = $paymentConfig;
        // For TranAPI Config import
        $this->_token = $token;
        $this->config = $config;
        $this->order = $order;
        $this->command = "sale";
        $this->result = "Error";
        $this->resultcode = "E";
        $this->error = "Transaction not processed yet.";
        $this->timeout = 90;
        $this->cardpresent = false;
        $this->lineitems = [];

        if (isset($_SERVER['REMOTE_ADDR'])) {
            $this->ip = $_SERVER['REMOTE_ADDR'];
        }
        $this->software = "Magento2";
        $this->ebiz_version = "Ebizcharge_Ebizcharge" . self::EBIZCHARGE_VERSION;
        $this->soapClient = $this->getClient();
        $this->ebizCustomLogger = $ebizCustomLogger;
        $this->epiCorCustomer = $epiCorCustomer;
        $this->initTransactionAPI();
    }

    public function _getGatewayBaseUrl()
    {
        return 'https://soap.ebizcharge.net';
    }

    public function getWsdlUrl()
    {
        return 'https://soap.ebizcharge.net/eBizService.svc?singleWsdl'; // production
        //return 'https://ebizsoapapidev1.azurewebsites.net/eBizService.svc?singleWsdl'; // dev
    }

    public function getClient()
    {
        if (!$this->soapClient) {
            $this->soapClient = new \SoapClient($this->getWsdlUrl(), $this->soapParams());
        }
        return $this->soapClient;
    }

    public function initTransactionAPI()
    {
        $this->key = $this->config->getSourceKey();
        $this->userid = $this->config->getSourceId();
        $this->pin = $this->config->getSourcePin();
        $this->software = 'Magento2';
        return $this;
    }

    public function getUeSecurityToken()
    {
        return [
            'SecurityId' => $this->key,
            'UserId' => $this->userid,
            'Password' => $this->pin
        ];
    }

    public function soapParams()
    {
        return [
            'soap_version' => SOAP_1_1, // Work For local and live both
            //'trace'      => true, // NOt in use
            //'exceptions' => true, // disable exceptions // not in use
            //'features' => SOAP_SINGLE_ELEMENT_ARRAYS, // not in use
            //'encoding' => 'UTF-8', // not in use
            //'connection_timeout' => 300, // Work For local and live both
            //'cache_wsdl' => false, // disable any caching on the wsdl, encase you alter the wsdl server // Work For local and live both
            'cache_wsdl' => 0, // disable any caching on the wsdl, encase you alter the wsdl server // Work For local and live both
            //'keep_alive' => false // Work For live only
        ];
    }

    public function log($message, $level = null)
    {
        $this->ebizCustomLogger->ebizPaymentLogger->info($message);
    }

    public function cronlog($message, $level = null)
    {
        $this->ebizCustomLogger->ebizCronLogger->info($message);
    }

    /**
     * Add a line item to the transaction
     *
     * @param string $sku
     * @param string $name
     * @param string $description
     * @param double $cost
     * @param string $taxable
     * @param int $qty
     */
    public function addLine($sku, $name, $description, $cost, $qty, $taxAmount, $productId, $discount)
    {
        $this->lineitems[] = [
            'sku' => $sku,
            'name' => $name,
            'description' => $description,
            'cost' => $cost,
            'taxable' => ($taxAmount > 0) ? 'Y' : 'N',
            'qty' => $qty,
            'id' => $productId,
            'discount' => $discount
        ];
    }

    /**
     * Add line items to the transaction used in tokenization
     *
     * @param string $sku
     * @param string $name
     * @param string $description
     * @param double $cost
     * @param int $qty
     * @param double $taxAmount
     */
    public function addLineItem($sku, $name, $description, $cost, $qty, $taxAmount, $productId, $discountAmount, $discountPercent, $discountInvoiced)
    {
        $this->lineItems[] = [
            'SKU' => $sku,
            'ProductName' => $name,
            'Description' => $description,
            'UnitPrice' => $cost,
            'Taxable' => ($taxAmount > 0) ? 'Y' : 'N',
            'TaxAmount' => $taxAmount,
            'Qty' => $qty,
            'Id' => $productId,
            'DiscountAmount' => $discountAmount,
            'DiscountRate' => $discountPercent,
            'DiscountInvoiced' => $discountInvoiced
        ];
    }

    public function clearLines()
    {
        $this->lineitems = [];
    }

    public function clearLineItems()
    {
        $this->lineItems = [];
    }

    /**
     * Verify that all required data has been set
     *
     * @return string
     */
    public function checkData()
    {
        if (!$this->key) {
            return "Source Key is required";
        }

        if (in_array(strtolower($this->command), ["quickcredit", "quicksale", "cc:capture", "cc:refund", "refund", "check:refund", "capture", "creditvoid"])) {
            if (!$this->refnum) {
                return "Reference Number is required";
            }
        } elseif (in_array(strtolower($this->command), ["svp"])) {
            if (!$this->svpbank) {
                return "Bank ID is required";
            }

            if (!$this->svpreturnurl) {
                return "Return URL is required";
            }

            if (!$this->svpcancelurl) {
                return "Cancel URL is required";
            }
        } else {
            if (in_array(strtolower($this->command), ["check:sale", "check:credit", "check", "checkcredit", "reverseach"])) {
                if (!$this->account) {
                    return "Account Number is required";
                }

                if (!$this->achroute) {
                    return "Routing Number is required";
                }
            } else {
                if (!$this->magstripe) {
                    if (!$this->card) {
                        return "Credit Card Number is required ({$this->command})";
                    }

                    if (!$this->exp) {
                        return "Expiration Date is required";
                    }
                }
            }

            $this->amount = preg_replace('/[^\d.]+/', '', $this->amount);

            if (!$this->amount) {
                return "Amount is required";
            }

            if (!$this->invoice && !$this->orderid) {
                return "Invoice number or Order ID is required";
            }
        }

        return 0;
    }

    //------------------- Developer New Functions Added Start -------------------

    /**
     * set order shipping info
     * @param $order
     */
    public function setOrderShipping($order)
    {
        $shipping = $order->getShippingAddress();

        if (!empty($shipping)) {
            $shippingStreet = !empty($shipping->getStreet()) ? $shipping->getStreet() : [];
            $streetShip = isset($shippingStreet[0]) ? $shippingStreet[0] : "";

            if (empty($shipping->getStreet(2))) {
                $street2Ship = '';
            } else {
                $shippingStreet2 = !empty($shipping->getStreet(2)) ? $shipping->getStreet(2) : "";
                $street2Ship = isset($shippingStreet2[0]) ? $shippingStreet2[0] : "";
            }

            $this->shipfname = !empty($shipping->getFirstname()) ? $shipping->getFirstname() : "";
            $this->shiplname = !empty($shipping->getLastname()) ? $shipping->getLastname() : "";
            $this->shipcompany = !empty($shipping->getCompany()) ? $shipping->getCompany() : "";
            $this->shipstreet = !empty($streetShip) ? $streetShip : "";
            $this->shipstreet2 = !empty($street2Ship) ? $street2Ship : "";
            $this->shipcity = !empty($shipping->getCity()) ? $shipping->getCity() : "";
            $this->shipstate = !empty($shipping->getRegion()) ? $shipping->getRegion() : "";
            $this->shipzip = !empty($shipping->getPostcode()) ? $shipping->getPostcode() : "";
            $this->shipcountry = !empty($shipping->getCountryId()) ? $shipping->getCountryId() : "";
            $this->shipphone = !empty($shipping->getTelephone()) ? $shipping->getTelephone() : "";
        }
    }

    /**
     * add order billing info
     * @param $order
     */
    public function setOrderBilling($order)
    {
        $billing = $order->getBillingAddress();

        if (!empty($billing)) {
            $street = !empty($billing->getStreet()) ? $billing->getStreet() : "";
            $streetBill = isset($street[0]) ? $street[0] : "";

            if (empty($billing->getStreet(2))) {
                $street2Bill = '';
            } else {
                $Street2 = !empty($billing->getStreet(2)) ? $billing->getStreet(2) : "";
                $street2Bill = !empty($Street2[0]) ? $Street2[0] : "";
            }

            $this->billfname = !empty($billing->getFirstname()) ? $billing->getFirstname() : "";
            $this->billlname = !empty($billing->getLastname()) ? $billing->getLastname() : "";
            $this->billcompany = !empty($billing->getCompany()) ? $billing->getCompany() : "";
            $this->billstreet = !empty($streetBill) ? $streetBill : "";
            $this->billstreet2 = !empty($street2Bill) ? $street2Bill : "";
            $this->billcity = !empty($billing->getCity()) ? $billing->getCity() : "";
            $this->billstate = !empty($billing->getRegion()) ? $billing->getRegion() : "";
            $this->billzip = !empty($billing->getPostcode()) ? $billing->getPostcode() : "";
            $this->billcountry = !empty($billing->getCountryId()) ? $billing->getCountryId() : "";
            $this->billphone = !empty($billing->getTelephone()) ? $billing->getTelephone() : "";

            if ($this->custid == null) {
                $this->custid = !empty($billing->getCustomerId()) ? $billing->getCustomerId() : "";
            }
        }
    }

    /**
     * set payment transaction result
     * @param $transaction
     * @return bool
     */
    public function setTransactionResult($transaction)
    {
        $this->log('Transaction result: ' . $transaction->Result);
        if (isset($transaction->ErrorCode) && $transaction->ErrorCode != 0) {
            $this->log('Transaction Failed Error: ' . $transaction->Error);
        }
        $this->result = $transaction->Result ?? '';
        $this->resultcode = $transaction->ResultCode ?? '';
        $this->authcode = $transaction->AuthCode ?? '';
        $this->refnum = $transaction->RefNum ?? '';
        $this->batch = $transaction->BatchNum ?? '';
        $this->avs_result = $transaction->AvsResult ?? '';
        $this->avs_result_code = $transaction->AvsResultCode ?? '';
        $this->cvv2_result = $transaction->CardCodeResult ?? '';
        $this->cvv2_result_code = $transaction->CardCodeResultCode ?? '';
        $this->vpas_result_code = $transaction->VpasResultCode ?? '';
        $this->convertedamount = $transaction->ConvertedAmount ?? '';
        $this->convertedamountcurrency = $transaction->ConvertedAmountCurrency ?? '';
        $this->conversionrate = $transaction->ConversionRate ?? '';
        $this->error = $transaction->Error ?? '';
        $this->errorcode = $transaction->ErrorCode ?? '';
        $this->custnum = $transaction->CustNum ?? '';
        // Obsolete variable (for backward compatibility) At some point they will no longer be set.
        $this->avs = '';
        $this->cvv2 = '';

        $this->acsurl = $transaction->AcsUrl ?? '';
        $this->pareq = $transaction->Payload ?? '';

        return $this->resultcode == 'A';
    }

    /**
     * get order billing address
     * @return array
     */
    private function getBillingAddress(): array
    {
        return [
            'FirstName' => !empty($this->billfname) ? $this->billfname : "",
            'LastName' => !empty($this->billlname) ? $this->billlname : "",
            'Company' => !empty($this->billcompany) ? $this->billcompany : "",
            'Street' => !empty($this->billstreet) ? $this->billstreet : "",
            'Street2' => !empty($this->billstreet2) ? $this->billstreet2 : "",
            'City' => !empty($this->billcity) ? $this->billcity : "",
            'State' => !empty($this->billstate) ? $this->billstate : "",
            'Zip' => !empty($this->billzip) ? $this->billzip : "",
            'Country' => !empty($this->billcountry) ? $this->billcountry : "",
            'Phone' => !empty($this->billphone) ? $this->billphone : "",
            'Fax' => !empty($this->fax) ? $this->fax : "",
            'Email' => !empty($this->email) ? $this->email : ""
        ];
    }

    /**
     * get order shipping address
     * @return array
     */
    private function getShippingAddress(): array
    {
        return [
            'FirstName' => !empty($this->shipfname) ? $this->shipfname : "",
            'LastName' => !empty($this->shiplname) ? $this->shiplname : "",
            'Company' => !empty($this->shipcompany) ? $this->shipcompany : "",
            'Street' => !empty($this->shipstreet) ? $this->shipstreet : "",
            'Street2' => !empty($this->shipstreet2) ? $this->shipstreet2 : "",
            'City' => !empty($this->shipcity) ? $this->shipcity : "",
            'State' => !empty($this->shipstate) ? $this->shipstate : "",
            'Zip' => !empty($this->shipzip) ? $this->shipzip : "",
            'Country' => !empty($this->shipcountry) ? $this->shipcountry : "",
            'Phone' => !empty($this->shipphone) ? $this->shipphone : "",
            'Fax' => !empty($this->fax) ? $this->fax : "",
            'Email' => !empty($this->email) ? $this->email : ""
        ];
    }

    /**
     * get order transaction details
     * @return array
     */
    private function getTransactionDetails(): array
    {
        return [
            'OrderID' => $this->orderid,
            'Invoice' => $this->invoice,
            'PONum' => $this->ponum,
            'Description' => $this->description,
            'Amount' => $this->amount,
            'Tax' => $this->tax,
            'Currency' => $this->currency,
            'Shipping' => $this->shipping,
            'ShipFromZip' => $this->shipzip,
            'Discount' => $this->discount,
            'Subtotal' => $this->subtotal,
            'AllowPartialAuth' => false,
            'Tip' => 0,
            'NonTax' => false,
            'Duty' => 0,
        ];
    }

    /**
     * @return bool
     */
    private function isCardTypeACH(): bool
    {
        return $this->cardtype === self::ACH;
    }

    /**
     * get transaction request
     * @return array
     */
    private function getTransactionRequest(): array
    {
        $magCustomerId = empty($this->custid) ? 'Guest' : $this->custid;
        $magCommand = $this->isCardTypeACH() ? 'check' : $this->command;

        return [
            'CustReceipt' => $this->custreceipt ?? "",
            'CustReceiptName' => $this->custreceipt_template ?? "",
            'Software' => $this->software ?? "",
            'LineItems' => $this->lineItems ?? "",
            'IsRecurring' => false,
            'IgnoreDuplicate' => false,
            'Details' => $this->getTransactionDetails(),
            'CustomerID' => $magCustomerId,
            'CreditCardData' => [
                'InternalCardAuth' => false,
                'CardPresent' => false,
                'CardNumber' => $this->card ?? "",
                'CardExpiration' => $this->exp ?? "",
                'CardCode' => $this->cvv2 ?? "",
                'AvsStreet' => $this->billstreet ?? "",
                'AvsZip' => $this->billzip ?? ""
            ],
            'CheckData' => [
                'Account' => $this->card ?? "",
                'AccountType' => $this->achtype ?? "",
                'Routing' => $this->achroute ?? ""
            ],
            'Command' => $magCommand,
            'ClientIP' => $this->ip ?? "",
            'AccountHolder' => $this->cardholder ?? "",
            'RefNum' => $this->refnum ?? "",
            'BillingAddress' => $this->getBillingAddress(),
            'ShippingAddress' => $this->getShippingAddress()
        ];
    }

    /**
     * Get Customer Data for Add New Customer
     * @param $customerId
     * @return array
     */
    public function getCustomerData($customerId): array
    {
        return [
            'CustomerId' => $customerId,
            'FirstName' => $this->billfname  ?? "",
            'LastName' => $this->billlname ?? "",
            'CompanyName' => $this->billcompany ?? "",
            'Phone' => $this->billphone ?? "",
            'CellPhone' => $this->billphone ?? "",
            'Fax' => $this->fax ?? "",
            'Email' => $this->email ?? "",
            'WebSite' => $this->website ?? "",
            'ShippingAddress' => $this->getShippingAddressAddCust(),
            'BillingAddress' => $this->getBillingAddressAddCust(),
            'SoftwareId' => 'Magento2',
        ];
    }

    /**
     * Get Customer Payment data
     * @return array
     */
    private function getCustomerPayment(): array
    {
        $paymentTypes = $this->_paymentConfig->getCcTypes();
        $cardType = $this->cardtype;

        if ($cardType != self::ACH) {
            foreach ($paymentTypes as $code => $text) {
                if ($code == $this->cardtype) {
                    $cardType = $text;
                }
            }

            $paymentMethod = [
                'MethodName' => $cardType . ' ' . substr($this->card, -4) . ' - ' . $this->cardholder, # . ' - Expires on: ' . $this->exp,
                'AccountHolderName' => isset($this->cardholder) ? $this->cardholder : '',
                'SecondarySort' => 1,
                'Created' => date('Y-m-d\TH:i:s'),
                'Modified' => date('Y-m-d\TH:i:s'),
                'AvsStreet' => $this->billstreet ?? "",
                'AvsZip' => $this->billzip ?? "",
                'CardCode' => $this->cvv2 ?? "",
                'CardExpiration' => $this->exp ?? "",
                'CardNumber' => $this->card ?? "",
                'CardType' => $this->cardtype ?? "",
                'Balance' => $this->amount ?? 0,
                'MaxBalance' => $this->amount  ?? 0,
            ];
        } else {
            $paymentMethod = [
                'MethodName' => ucwords($this->achtype) . ' ' . substr($this->card, -4) . ' - ' . $this->cardholder,
                'SecondarySort' => 1,
                'Created' => date('Y-m-d\TH:i:s'),
                'Modified' => date('Y-m-d\TH:i:s'),
                'Account' => $this->card ?? "",
                'AccountType' => $this->achtype ?? "",
                'AccountHolderName' => isset($this->cardholder) ? $this->cardholder : '',
                'Routing' => $this->achroute ?? "",
                'MethodType' => self::ACH,
                'Balance' => $this->amount  ?? 0,
                'MaxBalance' => $this->amount ?? 0,
            ];
        }

        return $paymentMethod;
    }

    /**
     * get Customer transaction request
     * @return array
     */
    private function getCustomerTransactionRequest(): array
    {
        $command = $this->isCardTypeACH() ? 'check' : $this->command;

        return [
            'isRecurring' => false,
            'IgnoreDuplicate' => true,
            'Details' => $this->getTransactionDetails(),
            'Software' => $this->software ?? "",
            'MerchReceipt' => true,
            'CustReceiptName' => $this->custreceipt_template,
            'CustReceiptEmail' => '',
            'CustReceipt' => $this->custreceipt ?? "",
            'ClientIP' => $this->ip ?? "",
            'CardCode' => $this->cvv2 ?? "",
            'Command' => $command ?? "",
            'LineItems' => $this->lineItems
        ];
    }

    /**
     * New billing address for add customer
     * @return array
     */
    private function getBillingAddressAddCust(): array
    {
        return [
            'FirstName' => $this->billfname ?? "",
            'LastName' => $this->billlname ?? "",
            'Company' => $this->billcompany ?? "",
            'Address1' => $this->billstreet ?? "",
            'Address2' => $this->billstreet2 ?? "",
            'City' => $this->billcity ?? "",
            'State' => $this->billstate ?? "",
            'ZipCode' => $this->billzip ?? "",
            'Country' => $this->billcountry ?? "",
            'Phone' => $this->billphone ?? "",
            'Fax' => $this->fax ?? "",
            'Email' => $this->email ?? ""
        ];
    }

    /**
     * New shipping for add customer
     * @return array
     */
    private function getShippingAddressAddCust(): array
    {
        return [
            'FirstName' => $this->shipfname ?? "",
            'LastName' => $this->shiplname ?? "",
            'Company' => $this->shipcompany ?? "",
            'Address1' => $this->shipstreet ?? "",
            'Address2' => $this->shipstreet2 ?? "",
            'City' => $this->shipcity ?? "",
            'State' => $this->shipstate ?? "",
            'ZipCode' => $this->shipzip ?? "",
            'Country' => $this->shipcountry ?? "",
            'Phone' => $this->shipphone ?? "",
            'Fax' => $this->fax ?? "",
            'Email' => $this->email ?? ""
        ];
    }

    /**
     * Set Transaction Data for Void, Cancel and Refund
     * @param $payment
     */
    public function setTransactionData($payment, $isRefund = false): void
    {
        $this->refnum = $payment->getCcTransId();

        // if we refund we'll use TransactionId
        if ($isRefund && !empty($tnxId = $payment->getTransactionId())) {
            $tnxId = str_replace(
                '-' . \Magento\Sales\Api\Data\TransactionInterface::TYPE_CAPTURE,
                '',
                $tnxId
            );
            $this->refnum = str_replace(
                '-' . \Magento\Sales\Api\Data\TransactionInterface::TYPE_REFUND,
                '',
                $tnxId
            );
        }
        $this->cardholder = $payment->getCcOwner();
        $this->card = $payment->getCcNumber();
        $this->routing = $payment->getAchRoute();
        $this->achtype = $payment->getAchType();

        $this->exp = $payment->getCcExpMonth() . substr($payment->getCcExpYear() ?? '', 2, 2);
        $this->cvv2 = $payment->getCcCid();

        $order = $payment->getOrder();

        if (!empty($order)) {
            $orderId = $order->getIncrementId();
            $this->orderid = $orderId;
            $this->invoice = $orderId;
            $this->ponum = $orderId;

            $this->custid = $order->getCustomerId();
            $this->ip = $order->getRemoteIp();
            $this->email = $order->getCustomerEmail();
            $this->tax = $order->getTaxAmount();
            $this->shipping = $order->getShippingAmount();

            // avs data
            list($avsStreet) = $order->getBillingAddress()->getStreet();
            $this->street = $avsStreet;
            $this->zip = $order->getBillingAddress()->getPostcode();

            $this->setOrderBilling($order);
            $this->setOrderShipping($order);
            $this->clearLineItems();
            if ($order->hasInvoices()) {
                foreach ($order->getInvoiceCollection() as $invoice) {
                    foreach ($invoice->getAllItems() as $item) {
                        // for tokenization
                        $this->addLineItem(
                            $item->getSku(),
                            $item->getName(),
                            '',
                            $item->getFinalPrice(),
                            $item->getQty(),
                            $item->getTaxAmount(),
                            $item->getProductId(),
                            $item->getDiscountAmount(),
                            $item->getDiscountPercent(),
                            $item->getDiscountInvoiced()
                        );
                    }
                }
            }
        }
    }

    //-------------------- EBizCharge Connect Methods Start ---------------

    /**
     * search customer by local magento id
     * @param $mageCustomerId
     * @return string 'Found' or 'Not Found'
     */
    public function searchCustomers($mageCustomerId)
    {
        $this->log('search customer using ..' . __METHOD__);

        $mappedCustomerId = $this->getMappedCustomerId($mageCustomerId);

        try {
            $searchCustomer = $this->soapClient->SearchCustomers(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'customerId' => $mappedCustomerId,
                    'start' => 0,
                    'limit' => 1
                ]
            );

            if (!isset($searchCustomer->SearchCustomersResult->Customer) || empty($searchCustomer->SearchCustomersResult->Customer)) {
                $ebzcCustomer = 'Not Found';
                $this->log('Customer ' . $mappedCustomerId . ' Not Found');
            } else {
                $ebzcCustomer = $searchCustomer->SearchCustomersResult->Customer;
                $this->log('Customer ' . $mappedCustomerId . ' Found');
            }
        } catch (\Exception $ex) {
            $this->log('Error in search customer ' . $ex->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__('searchCustomers ' . $ex->getMessage()));
        }

        return $ebzcCustomer;
    }

    /**
     * @param $magCustomerId
     * @return mixed
     */
    public function getCustomerToken($magCustomerId)
    {
        if ($customer = $this->getCustomer($magCustomerId)) {
            return $customer->CustomerToken;
        }

        return null;
    }

    public function getCustomer($magCustomerId)
    {
        try {
            $mappedCustomerId = $this->getMappedCustomerId($magCustomerId);

            $customer = $this->soapClient->GetCustomer(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'customerId' => $mappedCustomerId
                ]
            );

            if (isset($customer->GetCustomerResult)) {
                return $customer->GetCustomerResult;
            }
        } catch (\Exception $ex) {
            $this->log(__METHOD__ . ' Error in getting customer ' . $ex->getMessage());
            return null;
        }

        return null;
    }

    /**
     * @param $tableName
     * @param $mageCustomerId
     * @param $ebzcCustomerId
     */
    public function runInsertCustomer($tableName, $mageCustomerId, $ebzcCustomerId): void
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($tableName);
        // add table name along with prefix
        $sql = "INSERT INTO " . $tableNamef . " (token_id, mage_cust_id, ebzc_cust_id) VALUES ('', $mageCustomerId, '$ebzcCustomerId')";
        $resource->getConnection()->query($sql);
    }

    /**
     * @param $tableName
     * @param $mageCustomerId
     * @param $ebzcCustomerId
     */
    public function runUpdateCustomer($tableName, $mageCustomerId, $ebzcCustomerId): void
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNameWithPrefix = $resource->getTableName($tableName); // add table name along with prefix
        // Getting Db resource connection for query Run start
        $sql = "UPDATE " . $tableNameWithPrefix . " SET ebzc_cust_id = '$ebzcCustomerId' WHERE mage_cust_id = " . $mageCustomerId;
        $this->log('Customer ' . $mageCustomerId . ' DB token updated from save payment method.');
        $resource->getConnection()->query($sql);
    }

    /**
     * @param $tableName
     * @param $column
     * @param $ecItemSyncStatus
     * @param $ecItemInternalId
     * @param $ecCustomerId
     * @param $ebizCustomerToken
     * @param $entityId
     */
    public function runUpdateQueryCustomer($tableName, $column, $ecItemSyncStatus, $ecItemInternalId, $ecCustomerId, $ebizCustomerToken, $entityId): void
    {
        $timeStamp = date("Y-m-d h:i:s");
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($tableName); // add table name along with prefix
        // Getting Db resource connection for query Run start
        $sql = "UPDATE " . $tableNamef . " SET ec_" . $column . "_sync_status = '$ecItemSyncStatus', ec_" . $column . "_internalid = '$ecItemInternalId', ec_" . $column . "_id = " . "'" . $ecCustomerId . "'" . ", ec_" . $column . "_token = " . "'" . $ebizCustomerToken . "'" . ", ec_" . $column . "_lastsyncdate = '$timeStamp' WHERE entity_id = " . "'" . $entityId . "'";
        $this->log('Customer ' . $entityId . ' DB updated from save payment method.');
        $resource->getConnection()->query($sql);
    }

    //---------------- EBizCharge Connect Methods End ---------------

    //---------------- EBizCharge Methods Start -----------

    /**
     * return Econnect customer id if found in mapping else return local magento customer id
     * @param $magCustomerId
     * @return mixed
     */
    public function getMappedCustomerId($magCustomerId)
    {
        $objectManager = $this->config->getObjectManagerInstance();
        $dataclass = $objectManager->get('Ebizcharge\Ebizcharge\Model\Data');
        $econnectCustomerId = $dataclass->getEconnectMappedCustomerId($magCustomerId);
        $this->log('local magento customer id: ' . $magCustomerId . ' econnect customer id: ' . $econnectCustomerId);
        return $econnectCustomerId;
    }

    /**
     * Tokenization customer checkout: Add customer to gateway and process the transaction
     * a user is logged in option is new customer + add payment method
     * @param $customerId
     * @param $paymentObj
     * @return bool
     */
    public function tokenProcess($customerId, $paymentObj)
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $searchCustomerResult = $this->searchCustomers($customerId);
            # Case 1 Local = No, Live = No
            if (($searchCustomerResult == 'Not Found') || ($searchCustomerResult == null)) {
                $this->addCustomerAndRunCustomerTransaction($customerId, $paymentObj);
            } else {
                $this->log('EBizCharge customer already exists. Processing as guest checkout using runTransaction but card is not saved.');
                $this->runTransaction();
            }
            # Case 3 Local = No, Live = Yes
            # Added on Payment.php line #404
        } catch (\Exception $e) {
            $this->log('SoapFault: ' . $e->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * @param $customerInternalId
     * @param $parameters
     * @return |null
     */
    public function addCustomerPaymentMethod($customerInternalId, $parameters)
    {
        try {
            $paymentMethod = $this->soapClient->addCustomerPaymentMethodProfile(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'customerInternalId' => $customerInternalId,
                    'paymentMethodProfile' => $parameters
                ]
            );

            if (isset($paymentMethod->AddCustomerPaymentMethodProfileResult)) {
                return $paymentMethod->AddCustomerPaymentMethodProfileResult;
            }

            return null;
        } catch (\Exception $ex) {
            $this->log(__METHOD__ . ' ' . $ex->getMessage());
            return null;
        }
    }

    /**
     * set customer payment id in Magento payment object
     * @param $methodId
     * @param $paymentObj
     */
    private function setPaymentMethodId($methodId, $paymentObj): void
    {
        $paymentObj->setEbzcMethodId($methodId);
        $paymentObj->setAdditionalInformation('ebzc_method_id', $methodId);
        $this->savedMethodId = $methodId;
        $this->recurringMethodId = $methodId;
    }

    /**
     * @param $customerId
     * @param $paymentObj
     * @return bool
     */
    private function addCustomerAndRunCustomerTransaction($customerId, $paymentObj)
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $customerResult = $this->soapClient->AddCustomer([
                'securityToken' => $this->getUeSecurityToken(),
                'customer' => $this->getCustomerData($customerId)
            ]);

            $ebizCustomer = $customerResult->AddCustomerResult;
            //add customer payment method
            $paymentMethodId = $this->addCustomerPaymentMethod($ebizCustomer->CustomerInternalId, $this->getCustomerPayment());
            $this->setPaymentMethodId($paymentMethodId, $paymentObj);

            // GetCustomerToken by calling GetCustomerToken function
            $ebizCustomerNumber = $this->getCustomerToken($ebizCustomer->CustomerId);
            // add token in ebizcharge_token table
            $this->runInsertCustomer('ebizcharge_token', $customerId, $ebizCustomerNumber);
            $paymentObj->setAdditionalInformation('ebzc_cust_id', $ebizCustomerNumber);
            $this->runUpdateQueryCustomer('customer_entity', 'cust', 1, $ebizCustomer->CustomerInternalId, $ebizCustomer->CustomerId, $ebizCustomerNumber, $customerId);

            $this->log('Customer ' . $customerId . ' uploaded to Econnect in during tokenProcessCNF save payment method.');
            // run Customer Transaction using saved payment method
            $this->savedProcess($ebizCustomerNumber, $paymentMethodId, $paymentObj);
        } catch (\Exception $e) {
            $this->log(__('SoapFault: ' . __METHOD__ . $e->getMessage()));
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * Add new payment method and process the transaction
     * A user is logged in option is existing customer only AddCustomerPaymentMethodProfile
     * @param $customerId
     * @param $ebzCustomerId
     * @param $paymentObj
     * @return bool
     */
    public function newPaymentProcess($customerId, $ebzCustomerId, $paymentObj)
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $customer = $this->getCustomer($customerId);

            # Case 2 Local = Yes, Live = No
            if ($customer == null) {
                $this->addCustomerAndRunCustomerTransaction($customerId, $paymentObj);
            } elseif ($customer && ($customer->CustomerToken == $ebzCustomerId)) {
                # Case 5 Local = Yes, Live = Yes , Token = Same
                try {
                    $paymentMethodId = $this->addCustomerPaymentMethod($customer->CustomerInternalId, $this->getCustomerPayment());

                    $this->setPaymentMethodId($paymentMethodId, $paymentObj);
                    // run customer transaction
                    return $this->savedProcess($ebzCustomerId, $paymentMethodId, $paymentObj);
                } catch (\Exception $ex) {
                    $this->log(__('newPaymentProcess: ' . __METHOD__ . $ex->getMessage()));
                    throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
                }
            } elseif ($customer && ($customer->CustomerToken != $ebzCustomerId)) {
                # Case 4 Local = Yes, Live = Yes , Token = Different
                $this->log(__METHOD__ . ': EBizCharge customer already exists and token mismatch. Processing as guest checkout using runTransaction but card is not saved.');
                $this->runTransaction();
            } else {
                # Case 6 In all other cases default
                throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
            }
        } catch (\Exception $ex) {
            $this->log('SoapFault: ' . __METHOD__ . $ex->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * Process a transaction from saved payment method
     * A user is logged in option is existing customer pay from saved payment methods
     * @param int $ebzcCustomerId EBizCharge Customer ID
     * @param int $ebzcMethodId EBizCharge Payment method ID
     * @param bool $partialAuth
     * @return boolean
     */
    public function savedProcess($ebzcCustomerId, $ebzcMethodId, $payment, $partialAuth = false)
    {
        $this->log('Transaction using ... ' . __METHOD__);

        try {
            $transactionResult = $this->soapClient->runCustomerTransaction(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'custNum' => $ebzcCustomerId,
                    'paymentMethodID' => $ebzcMethodId,
                    'tran' => $this->getCustomerTransactionRequest()
                ]
            );

            $transaction = $transactionResult->runCustomerTransactionResult;

            if (isset($transaction)) {
                $transactionApproved = $this->setTransactionResult($transaction);

                if ($transactionApproved && $this->config->isRecurringEnabled() == 1 && !$partialAuth) {
                    if (isset($payment)) {
                        $this->runRecurring($payment);
                    }
                }
                return $transactionApproved;
            }
        } catch (\Exception $ex) {
            $this->log(__('savedProcess ' . $ex->getMessage()));
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * @param $ebzcCustomerId
     * @param $ebzcMethodId
     * @return |null
     */
    public function getCustomerPaymentMethodProfile($ebzcCustomerId, $ebzcMethodId)
    {
        try {
            $paymentMethod = $this->soapClient->getCustomerPaymentMethodProfile(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'customerToken' => $ebzcCustomerId,
                    'paymentMethodId' => $ebzcMethodId,
                ]
            );

            if (isset($paymentMethod->GetCustomerPaymentMethodProfileResult)) {
                return $paymentMethod->GetCustomerPaymentMethodProfileResult;
            }

            return null;
        } catch (Exception $ex) {
            $this->log(__('get payment method: ' . $ex->getMessage()));
            return null;
        }
    }

    /**
     * @param $customerToken
     * @return array|null
     */
    public function getCustomerPaymentMethods($customerToken)
    {
        if (!empty($customerToken)) {
            try {
                $methodProfiles = $this->soapClient->getCustomerPaymentMethodProfiles(
                    [
                        'securityToken' => $this->getUeSecurityToken(),
                        'customerToken' => $customerToken
                    ]
                );

                if (!isset($methodProfiles->GetCustomerPaymentMethodProfilesResult->PaymentMethodProfile)) {
                    $paymentMethods = [];
                } elseif (
                    (is_array($methodProfiles->GetCustomerPaymentMethodProfilesResult->PaymentMethodProfile))
                    &&
                    (count($methodProfiles->GetCustomerPaymentMethodProfilesResult->PaymentMethodProfile))
                    > 1) {
                    $paymentMethods = $methodProfiles->GetCustomerPaymentMethodProfilesResult->PaymentMethodProfile;
                } else {
                    $paymentMethods[] = $methodProfiles->GetCustomerPaymentMethodProfilesResult->PaymentMethodProfile;
                }
                return $paymentMethods;
            } catch (Exception $ex) {
                $this->log(__('SoapFault: ' . $ex->getMessage()));
                return [];
            }
        }

        return [];
    }

    public function getSavedAccounts($customerToken): array
    {
        $accounts = [];
        if (!empty($customerToken)) {
            $paymentMethods = $this->getCustomerPaymentMethods($customerToken);

            foreach ($paymentMethods as $key => $paymentMethod) {
                if ($paymentMethod->MethodType == 'check') {
                    $accounts[] = $paymentMethod;
                }
            }
        }

        return $accounts;
    }

    /**
     * @param $customerToken
     * @param $methodId
     * @return bool
     */
    public function setDefaultPaymentMethod($customerToken, $methodId): bool
    {
        $setDefaultMethod = $this->soapClient->SetDefaultCustomerPaymentMethodProfile(
            [
                'securityToken' => $this->getUeSecurityToken(),
                'customerToken' => $customerToken,
                'paymentMethodId' => $methodId
            ]
        );

        if (isset($setDefaultMethod->SetDefaultCustomerPaymentMethodProfileResult)) {
            return true;
        }

        return false;
    }

    /**
     * Function Change #5 Ebiz Method Senario #5
     * a user is logged in option is existing customer pay from saved payment methods and update card details
     */

    public function updateProcess($ebzcCustomerId, $ebzcMethodId, $payment)
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $paymentMethodProfile = $this->getCustomerPaymentMethodProfile($ebzcCustomerId, $ebzcMethodId);

            $paymentMethodProfile->AccountHolderName = !empty($paymentMethodProfile->AccountHolderName)
                ? $paymentMethodProfile->AccountHolderName
                : $payment->getCcOwner();

            $paymentMethodProfile->CardNumber = 'XXXXXX' . substr($paymentMethodProfile->CardNumber, 6);
            $paymentMethodProfile->CardExpiration = $payment->getCcExpYear() . '-' . $payment->getCcExpMonth();

            if ($payment->getEbzcAvsStreet() != null) {
                $paymentMethodProfile->AvsStreet = $payment->getEbzcAvsStreet();
            } else {
                if ($payment->getAdditionalInformation('ebzc_avs_street') != null) {
                    $paymentMethodProfile->AvsStreet = $payment->getAdditionalInformation('ebzc_avs_street');
                } else {
                    $paymentMethodProfile->AvsStreet = $this->billstreet;
                }
            }

            if ($payment->getEbzcAvsZip() != null) {
                $paymentMethodProfile->AvsZip = $payment->getEbzcAvsZip();
            } else {
                if ($payment->getAdditionalInformation('ebzc_avs_zip') != null) {
                    $paymentMethodProfile->AvsZip = $payment->getAdditionalInformation('ebzc_avs_zip');
                } else {
                    $paymentMethodProfile->AvsZip = $this->billzip;
                }
            }

            if ($this->updatePaymentMethod($ebzcCustomerId, $paymentMethodProfile)) {
                return $this->savedProcess($ebzcCustomerId, $ebzcMethodId, $payment);
            } else {
                throw new \Magento\Framework\Exception\LocalizedException(__('Unable to update card.'));
            }
        } catch (\Exception $ex) {
            $this->log(__('SoapFault: ' . $ex->getMessage()));
            throw new \Magento\Framework\Exception\LocalizedException(__('Unable to update card'));
        }
    }

    /**
     * Run Customer payment transaction for One ResultCode
     */
    public function runTransaction()
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $transaction = $this->soapClient->runTransaction(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'tran' => $this->getTransactionRequest()
                ]
            );

            if (!empty($transactionResult = $transaction->runTransactionResult)) {
                return $this->setTransactionResult($transactionResult);
            }
        } catch (\Exception $ex) {
            $this->log('SoapFault: ' . __METHOD__ . $ex->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * Run Customer payment transaction for One ResultCode
     */
    public function runCustomerTransaction($ebzcCustomerId, $ebzcMethodId, $payment, $recurringOnOff)
    {
        $this->log('Transaction using ..' . __METHOD__);
        $getCustomerTransactionRequest = $this->getCustomerTransactionRequest();

        try {
            if ($this->config->isRecurringEnabled() == 1) {

                if ($recurringOnOff == 1 && !empty($payment->getExcludeAmount()) && $payment->getExcludeAmount() > 0) {

                    $getCustomerTransactionRequest['Details']['Amount'] -= $payment->getExcludeAmount();

                    $getCustomerTransactionRequest['Details']['Description'] = 'This is recurring order #' . $getCustomerTransactionRequest['Details']['OrderID'] . ' Amount [' . $payment->getExcludeAmount() . '] already paid. Remaining amount will be charge now.';

                    $this->log('getExcludeAmount found and updated');

                    $transactionResult = $this->soapClient->runCustomerTransaction(
                        [
                            'securityToken' => $this->getUeSecurityToken(),
                            'custNum' => $ebzcCustomerId,
                            'paymentMethodID' => $ebzcMethodId,
                            'tran' => $getCustomerTransactionRequest
                        ]
                    );

                    $transaction = $transactionResult->runCustomerTransactionResult;

                    if (isset($transaction)) {
                        return $this->setTransactionResult($transaction);
                    }
                } else {
                    $this->log('Full amount is already paid.');
                }
            } else {
                $this->log('Recurring is not enabled.');
            }
        } catch (\Exception $ex) {
            $this->log(__('runCustomerTransaction: ' . $ex->getMessage()));
            throw new \Magento\Framework\Exception\LocalizedException(__(self::EBIZCHARGE_TRANSACTION_ERROR));
        }

        return false;
    }

    /**
     * Refund previous transaction
     * @return bool
     */
    public function refundTransaction()
    {
        $this->log('Transaction using ..' . __METHOD__);

        try {
            $transaction = $this->soapClient->runTransaction(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'tran' => $this->getTransactionRequest()
                ]
            );

            $transaction = $transaction->runTransactionResult;

            $this->result = $transaction->Result;
            $this->resultcode = $transaction->ResultCode;
            $this->authcode = $transaction->AuthCode;
            // Caused refund issue. Commented out on 12/13/16
            //$this->refnum = $transaction->RefNum;
            $this->batch = $transaction->BatchNum;
            $this->avs_result = $transaction->AvsResult;
            $this->avs_result_code = $transaction->AvsResultCode;
            $this->cvv2_result = $transaction->CardCodeResult;
            $this->cvv2_result_code = $transaction->CardCodeResultCode;
            $this->vpas_result_code = $transaction->VpasResultCode;
            $this->convertedamount = $transaction->ConvertedAmount;
            $this->convertedamountcurrency = $transaction->ConvertedAmountCurrency;
            $this->conversionrate = $transaction->ConversionRate;
            $this->error = $transaction->Error;
            $this->errorcode = $transaction->ErrorCode;
            $this->custnum = $transaction->CustNum;

            // Obsolete variable (for backward compatibility) At some point they will no longer be set.
            $this->avs = $transaction->AvsResult;
            $this->cvv2 = $transaction->CardCodeResult;

            $this->cctransid = $transaction->RefNum;
            $this->acsurl = $transaction->AcsUrl;
            $this->pareq = $transaction->Payload;

            return $this->resultcode === 'A';
        } catch (\Exception $ex) {
            $this->log('SoapFault: ' . $ex->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__('SoapFault: ' . $ex->getMessage()));
        }
    }

    /**
     * @param $queryParameters
     * @return mixed
     */
    public function runSelectQuery($queryParameters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($queryParameters['tableName']); // add table name along with prefix
        $sql = $resource->getConnection()->select()
            ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
            ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue']);

        return $resource->getConnection()->fetchAll($sql);
    }

    public function runSelectQueryMultiple($queryParameters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($queryParameters['tableName']); // add table name along with prefix
        $sql = $resource->getConnection()->select()
            ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
            ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
            ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2'])
            ->where('rec_status = ?', 0);

        return $resource->getConnection()->fetchAll($sql);
    }

    public function runSelectQueryMultipleInput($queryParameters, $noOfFilters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($queryParameters['tableName']); // add table name along with prefix
        if ($noOfFilters == 1) {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue']);
        } elseif ($noOfFilters == 2) {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
                ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2']);
        } elseif ($noOfFilters == 3) {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
                ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2'])
                ->where($queryParameters['whereKey3'] . ' = ?', $queryParameters['whereValue3']);
        } elseif ($noOfFilters == 4) {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
                ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2'])
                ->where($queryParameters['whereKey3'] . ' = ?', $queryParameters['whereValue3'])
                ->where($queryParameters['whereKey4'] . ' = ?', $queryParameters['whereValue4']);
        } elseif ($noOfFilters == 5) {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
                ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2'])
                ->where($queryParameters['whereKey3'] . ' = ?', $queryParameters['whereValue3'])
                ->where($queryParameters['whereKey4'] . ' = ?', $queryParameters['whereValue4'])
                ->where($queryParameters['whereKey5'] . ' = ?', $queryParameters['whereValue5']);
        } else {
            $sql = $resource->getConnection()->select()
                ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
                ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue']);
        }

        return $resource->getConnection()->fetchAll($sql);
    }

    public function runSelectQueryTwoFields($queryParameters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableNamef = $resource->getTableName($queryParameters['tableName']); // add table name along with prefix
        $sql = $resource->getConnection()->select()
            ->from($tableNamef, $queryParameters['tableFields']) // to select all fields remove fields part
            ->where($queryParameters['whereKey'] . ' = ?', $queryParameters['whereValue'])
            ->where($queryParameters['whereKey2'] . ' = ?', $queryParameters['whereValue2']);

        return $resource->getConnection()->fetchAll($sql);
    }

    /**
     * @param $queryParameters
     * @return mixed
     */
    public function runInsertQuery($queryParameters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableName = $resource->getTableName($queryParameters['tableName']);
        $connection = $resource->getConnection();
        $connection->insert($tableName, $queryParameters['data']);

        return $connection->lastInsertId($tableName);
    }

    public function runBulkInsertQuery($tableName, $data)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableName = $resource->getTableName($tableName);

        $resource->getConnection()->insertMultiple($tableName, $data);
    }

    /**
     * @param $queryParameters
     */
    public function runUpdateQuery($queryParameters)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableName = $resource->getTableName($queryParameters['tableName']);
        $resource->getConnection()->update($tableName, $queryParameters['data'], $queryParameters['where']);
    }

    public function strToTime($data, $plusYears = '')
    {
        if (!empty($plusYears)) {
            $date = date("Y-m-d", strtotime("+" . $plusYears . " years", strtotime($data)));
        } else {
            $date = date("Y-m-d", strtotime($data));
        }
        return $date;
    }

    public function getMagentoCustomer($customerId, $colums)
    {
        $selectQueryParameters = [
            'option' => 'select',
            'tableName' => 'customer_entity',
            'tableFields' => $colums,
            'whereKey' => 'ec_cust_id',
            'whereValue' => $customerId
        ];

        $customerData = $this->runSelectQuery($selectQueryParameters);

        if (empty($customerData)) {
            $selectQueryParametersE = [
                'option' => 'select',
                'tableName' => 'customer_entity',
                'tableFields' => $colums,
                'whereKey' => 'entity_id',
                'whereValue' => $customerId
            ];

            $customerData = $this->runSelectQuery($selectQueryParametersE);
        }

        return $customerData;
    }

    /**
     * run recurring payments for EBizCharge
     * @param $payment
     * @return $this
     */
    public function runRecurring($payment)
    {
        $this->log('Get Recurring Data ... ' . __METHOD__);
        sleep(5);

        $order = $payment->getOrder();

        $orderVisibleItems = $order->getAllVisibleItems();

        $meredRecurrings = [];
        $simpleRecurring = true;
        foreach ($orderVisibleItems as $_item) {
            $itemDetails = $_item->getProductOptions();
            if (isset($itemDetails['info_buyRequest']['recurring'])) {
                $meredRecurrings[] = $itemDetails['info_buyRequest']['item'] ?? '';
            }
        }
        if (count($meredRecurrings) > 1) {
            $simpleRecurring = false;
        }

        foreach ($orderVisibleItems as $item) {
            $itemOptions = $item->getProductOptions();
            $itemRecurringOptions = $itemOptions['info_buyRequest']['recurring'] ?? [];
            $recurringActivate = isset($itemRecurringOptions['rec_activate']) && ($itemRecurringOptions['rec_activate'] == 1);

            if ($recurringActivate) {
                $itemRecurringBuyRequest = $itemOptions['info_buyRequest'];
                $itemRecurringQty = $item->getQtyOrdered(); // Take qty from cart item qty

                $getMainProductId = $item->getProductId();
                $getParentProductId = (!empty($itemRecurringBuyRequest['product'])) ? $itemRecurringBuyRequest['product'] : $getMainProductId;
                $getChildProductId = (!empty($itemRecurringBuyRequest['currentpid'])) ? $itemRecurringBuyRequest['currentpid'] : $getMainProductId;
                $getProductSimpleName = (!empty($itemOptions['simple_name'])) ? $itemOptions['simple_name'] : $item->getName();
                $recSdate = $this->strToTime($itemRecurringOptions['sdate']);
                $recEdate = $itemRecurringOptions['edate'] ?? null;

                $itemPrice = (!empty($item->getFinalPrice())) ? $item->getFinalPrice() : $item->getPrice();
                // apply coupon discount .. we need to apply current price in recurring orders, how this work in recurring orders
                $itemDiscountAmount = (!empty($item->getDiscountAmount())) ? $item->getDiscountAmount() : 0;
                $singleItemDiscountAmount = ($itemDiscountAmount / $item->getQtyOrdered());
                $recurringItemTotalDiscount = ($singleItemDiscountAmount * $itemRecurringQty);
                $recurringItemAmountBeforeDisc = ($itemPrice * $itemRecurringQty);
                $recurringItemFinalAmount = ($recurringItemAmountBeforeDisc - $recurringItemTotalDiscount);

                if ($recurringItemFinalAmount > 0 || ($item->getProductType() == 'virtual')) {
                    if (!empty($itemRecurringOptions['rec_frequency'])) {
                        $recurringBilling = [
                            'Amount' => $recurringItemFinalAmount,
                            'Tax' => ($item->getTaxAmount() * $itemRecurringQty),
                            'Enabled' => true,
                            'Start' => $recSdate,
                            'Schedule' => $itemRecurringOptions['rec_frequency'],
                            'ScheduleName' => $getChildProductId . '-' . $this->orderid . '-' . $order->getCustomerId() . '-' . $itemRecurringOptions['rec_frequency'] . '-' . $this->recurringMethodId,
                            'ReceiptNote' => 'Item [' . $getChildProductId . '-' . $getProductSimpleName . '] recurring payment added.',
                            'ReceiptTemplateName' => false,
                            'SendCustomerReceipt' => true
                        ];
                    }

                    if (!empty($recEdate)) {
                        $recurringBilling['Expire'] = $this->strToTime($recEdate);
                        $recurringBilling['Next'] = $recSdate;
                        $recIndefinitely = isset($itemRecurringOptions['rec_indefinitely']) ? 1 : 0;
                    } else {
                        $recurringBilling['Expire'] = $this->strToTime($itemRecurringOptions['sdate'], '10');
                        $recurringBilling['Next'] = $recSdate;
                        $recIndefinitely = '1';
                    }

                    $this->addRecurring($getChildProductId, $getParentProductId, $getProductSimpleName, $itemRecurringQty, $recurringBilling, $recIndefinitely, $order, $simpleRecurring);
                } else {
                    $this->log('Subscription not added because product(' . $getProductSimpleName . ') price is: ' . $recurringItemFinalAmount);
                }
            }
        }

        return $this;
    }

    /**
     * Adding recurring to EBizCharge
     */
    public function addRecurring($getChildProductId, $getParentProductId, $getProductSimpleName, $itemRecurringQty, $recurringBilling, $recIndefinitely, $order, $simpleRecurring = true)
    {
        $customer = $this->getCustomer($order->getCustomerId());
        if ($customer == null) {
            $this->log('Recurring not added because customer Not found. Id: ' . $order->getCustomerId());
            return false;
        }

        try {
            $paymentMethodName = $this->getRecurringPaymentMethodName($customer);

            $addRecurringParameters = [
                'securityToken' => $this->getUeSecurityToken(),
                'customerInternalId' => $customer->CustomerInternalId,
                'paymentMethodProfileId' => $this->recurringMethodId,
                'recurringBilling' => $recurringBilling
            ];

            $transaction = $this->soapClient->ScheduleRecurringPayment($addRecurringParameters);

            if (!empty($scheduledPaymentInternalId = $transaction->ScheduleRecurringPaymentResult)) {
                $this->log('Recurring Payment added for Item #[' . $getChildProductId . '][' . $getParentProductId . ']-' . $scheduledPaymentInternalId);
                $customerShippingAddressId = '';
                $customerBillingAddressId = '';

                if (!empty($order->getShippingAddress())) {
                    $customerShippingAddressId = $order->getShippingAddress()->getCustomerAddressId();
                }
                if (!empty($order->getBillingAddress())) {
                    $customerBillingAddressId = $order->getBillingAddress()->getCustomerAddressId();
                }

                $amount = $recurringBilling['Amount'];
                $shippingMethodName = $order->getShippingMethod();
                $couponCode = $order->getCouponCode() ? $order->getCouponCode() : '';

                $recurringDates = $this->getRecurringScheduledDates($scheduledPaymentInternalId);

                $insertQueryParameters = [
                    'option' => 'insert',
                    'tableName' => 'ebizcharge_recurring',
                    'data' => [
                        'rec_status' => 0,
                        'rec_indefinitely' => $recIndefinitely,
                        'mage_cust_id' => $this->custid,
                        'mage_order_id' => $this->orderid,
                        'mage_item_id' => $getChildProductId,
                        'mage_parent_item_id' => $getParentProductId,
                        'mage_item_name' => $getProductSimpleName,
                        'qty_ordered' => $itemRecurringQty,
                        'eb_rec_start_date' => $recurringBilling['Start'],
                        'eb_rec_end_date' => $recurringBilling['Expire'],
                        'eb_rec_frequency' => $recurringBilling['Schedule'],
                        'eb_rec_method_id' => $this->recurringMethodId,
                        'eb_rec_scheduled_payment_internal_id' => $scheduledPaymentInternalId,
                        'eb_rec_total' => count($recurringDates),
                        'eb_rec_processed' => 0,
                        'eb_rec_next' => $this->getNextRecurringDate($recurringDates),
                        'eb_rec_remaining' => count($recurringDates),
                        'eb_rec_due_dates' => serialize($recurringDates),
                        'shipping_address_id' => $customerShippingAddressId,
                        'billing_address_id' => $customerBillingAddressId,
                        'amount' => $amount,
                        'coupon_code' => $couponCode,
                        'payment_method_name' => $paymentMethodName,
                        'shipping_method' => $shippingMethodName,
                        'simple_recurring' => $simpleRecurring ? '0' : $this->orderid,
                    ]
                ];

                $recurringId = $this->runInsertQuery($insertQueryParameters);

                $this->insertScheduleDates($recurringId, $recurringDates);
            }
        } catch (\Exception $ex) {
            throw new \Magento\Framework\Exception\LocalizedException(__('addRecurring ' . $ex->getMessage()));
        }

        return $this;
    }

    public function getNextRecurringDate($recurringDates)
    {
        $nextDate = null;
        if (!empty($recurringDates)) {
            $todayDate = date('Y-m-d');

            foreach ($recurringDates as $count => $recurringDate) {
                if (strtotime($todayDate) < strtotime($recurringDate)) {
                    $nextDate = date('Y-m-d', strtotime($recurringDate));
                    break;
                }
            }
        }
        return $nextDate;
    }

    public function getRecurringPaymentMethodName($ebizCustomer)
    {
        // get recurring payment method name
        $paymentMethodName = '';
        $profiles = $ebizCustomer->PaymentMethodProfiles->PaymentMethodProfile;

        if (is_object($profiles)) {
            $paymentMethods[] = $profiles;
        } else {
            $paymentMethods = $profiles;
        }

        foreach ($paymentMethods as $paymentMethod) {
            if ($paymentMethod->MethodID == $this->recurringMethodId) {
                $paymentMethodName = $paymentMethod->MethodName;
                break;
            }
        }

        return $paymentMethodName;
    }

    public function getRecurringScheduledDates($schedulePaymentId)
    {
        try {
            $transaction = $this->soapClient->GetScheduledDates(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'scheduledPaymentInternalId' => $schedulePaymentId,
                ]
            );

            if (!empty($transaction->GetScheduledDatesResult)) {
                $dates = $transaction->GetScheduledDatesResult->ScheduledDates;
                return json_decode($dates);
            }
        } catch (\Exception $ex) {
            $this->log(__METHOD__ . $ex->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(__(__METHOD__ . $ex->getMessage()));
        }

        return [];
    }

    /**
     * @param $recurringId
     * @param $recurringDates
     */
    public function insertScheduleDates($recurringId, $recurringDates)
    {
        if (is_array($recurringDates) && !empty($recurringDates)) {
            $dates = [];
            foreach ($recurringDates as $date) {
                $dates[] = [
                    'recurring_id' => $recurringId,
                    'recurring_date' => $date,
                ];
            }
            // delete all existing dates first
            $this->deleteRecurringScheduleDates($recurringId);

            $this->runBulkInsertQuery('ebizcharge_recurring_dates', $dates);
        }
    }

    /**
     * @param $recurringId
     */
    public function deleteRecurringScheduleDates($recurringId)
    {
        $resource = $this->config->getQueryResourceConnection();
        $tableName = $resource->getTableName('ebizcharge_recurring_dates');
        $sql = "DELETE  FROM $tableName WHERE recurring_id = $recurringId";

        $resource->getConnection()->query($sql);
    }

    /**
     * @param $methodId
     * @param $schedulePaymentInternalId
     * @return bool
     */
    public function modifyRecurringPaymentMethod($methodId, $schedulePaymentInternalId)
    {
        $paymentMethodProfile = [
            'securityToken' => $this->getUeSecurityToken(),
            'scheduledPaymentInternalId' => trim($schedulePaymentInternalId),
            'paymentMethodProfileId' => $methodId
        ];

        $paymentMethodProfileResponse = $this->soapClient->ModifyScheduledRecurringPayment_PaymentMethodProfile($paymentMethodProfile);
        $paymentMethodProfileResult = $paymentMethodProfileResponse->ModifyScheduledRecurringPayment_PaymentMethodProfileResult;
        if (isset($paymentMethodProfileResult)) {
            return $paymentMethodProfileResult->StatusCode;
        }

        return false;
    }

    /**
     * @param $customerId
     * @param $customerInternalId
     * @param $schedulePaymentId
     * @return mixed|null
     */
    public function getSearchScheduledRecurringPayments($customerInternalId, $schedulePaymentId)
    {
        try {
            $response = $this->soapClient->SearchScheduledRecurringPayments(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'customerInternalId' => $customerInternalId,
                    'start' => 0,
                    'limit' => 900,
                ]
            );

            if (!isset($response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails)) {
                $recurringDetail = [];
            } elseif (
                (is_array($response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails))
                &&
                (count($response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails))
                > 1) {
                $recurringDetail = $response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails;
            } else {
                $recurringDetail[] = $response->SearchScheduledRecurringPaymentsResult->RecurringBillingDetails;
            }

            if (!empty($recurringDetail)) {
                $key = array_search($schedulePaymentId, array_column($recurringDetail, 'ScheduledPaymentInternalId'));
                return $paymentMethods = $recurringDetail[$key] ?? null;
            }
        } catch (Exception $ex) {
            $this->log(__METHOD__ . $ex->getMessage());
            return null;
        }

        return null;
    }

    /**
     * @param null $customerId
     * @param int $start
     * @param int $limit
     * @return array
     */
    public function getSearchTransactions($customerId = null, $start = 0, $limit = 1000)
    {
        try {
            $filterClerk = [
                'FieldName' => 'Clerk',
                'ComparisonOperator' => 'eq',
                'FieldValue' => 'Recurring'
            ];
            $filterStart = [
                'FieldName' => 'created',
                'ComparisonOperator' => 'gt',
                'FieldValue' => '2021-01-15'
            ];
            $searchFilters['SearchFilter'][0] = $filterClerk;
            $searchFilters['SearchFilter'][1] = $filterStart;

            if (!empty($customerId)) {
                $filterCustomer = [
                    'FieldName' => 'CustID',
                    'ComparisonOperator' => 'eq',
                    'FieldValue' => $customerId
                ];

                $searchFilters['SearchFilter'][2] = $filterCustomer;
            }

            $searchTransactionsReq = [
                'securityToken' => $this->getUeSecurityToken(),
                'filters' => $searchFilters,
                'matchAll' => 1,
                'countOnly' => 0,
                'start' => $start,
                'limit' => $limit,
                'sort' => 'DateTime DESC'
            ];

            $response = $this->soapClient->SearchTransactions($searchTransactionsReq);

            if (!isset($response->SearchTransactionsResult->Transactions->TransactionObject)) {
                $recurringDetail = [];
            } elseif (
                (is_array($response->SearchTransactionsResult->Transactions->TransactionObject))
                &&
                (count($response->SearchTransactionsResult->Transactions->TransactionObject))
                > 1) {
                $recurringDetail = $response->SearchTransactionsResult->Transactions->TransactionObject;
            } else {
                $recurringDetail[] = $response->SearchTransactionsResult->Transactions->TransactionObject;
            }
            return $recurringDetail;
        } catch (Exception $ex) {
            $this->log(__METHOD__ . $ex->getMessage());
            return [];
        }
    }

    /**
     * @return string
     */
    public function getReceiptRefNumber()
    {
        $receiptsList = [
            'securityToken' => $this->getUeSecurityToken(),
            'receiptType' => 'email'
        ];

        $receiptsList = $this->soapClient->GetReceiptsList($receiptsList);
        $getReceiptsListResult = $receiptsList->GetReceiptsListResult;
        $needle = 'Transaction API and Payment Form (Customer)';
        $receiptRefNum = '';
        if (isset($getReceiptsListResult)) {
            foreach ($getReceiptsListResult as $array) {
                foreach ($array as $item) {
                    if ($item->Name == $needle) {
                        $receiptRefNum = $item->ReceiptRefNum;
                        break;
                    }
                }
            }
        }

        return $receiptRefNum;
    }

    /**
     * @param $recurring
     * @param $status
     */
    public function suspendScheduledRecurringPaymentStatus($recurring, $status)
    {
        try {
            $scheduledPaymentInternalId = $recurring['eb_rec_scheduled_payment_internal_id'];
            $scheduledRecurringPaymentStatus = $this->soapClient->ModifyScheduledRecurringPaymentStatus(
                [
                    'securityToken' => $this->getUeSecurityToken(),
                    'scheduledPaymentInternalId' => $scheduledPaymentInternalId,
                    'statusId' => $status
                ]
            );

            $scheduledRecurringStatusResult = $scheduledRecurringPaymentStatus->ModifyScheduledRecurringPaymentStatusResult;

            if (!empty($scheduledRecurringStatusResult)) {
                if ($scheduledRecurringStatusResult->StatusCode == 1) {
                    //return true;
                    $this->cronlog($scheduledPaymentInternalId . ' - ScheduledPaymentInternalId is suspended!');

                    // Updating db recurring table start
                    $recId = $recurring['rec_id'];
                    $recMageItemId = $recurring['mage_item_id'];

                    $updateQueryParameters = [
                        'option' => 'update',
                        'tableName' => 'ebizcharge_recurring',
                        'data' => [
                            'rec_status' => $status
                        ],
                        'where' => [
                            'rec_id = ?' => $recId,
                            'mage_item_id = ?' => $recMageItemId
                        ]
                    ];
                    $this->runUpdateQuery($updateQueryParameters);
                    // Updating db recurring table end
                } else {
                    //return false;
                    $this->cronlog($scheduledPaymentInternalId . ' - ScheduledPaymentInternalId is not suspended!');
                }
            } else {
                $this->cronlog('No response from gateway!');
            }
        } catch (Exception $ex) {
            //throw new \Magento\Framework\Exception\LocalizedException(__('suspendScheduledRecurringPaymentStatus: ' . $ex->getMessage()));
            $this->cronlog('There is an error in updating ScheduledPaymentInternalId status');
        }
    }

    /**
     * @param $customerId
     * @param $scheduledPaymentInternalId
     * @param $orderDate
     * @return string|null
     */
    public function searchRecurringPayment($customerId, $scheduledPaymentInternalId, $orderDate)
    {
        $this->cronlog(__METHOD__);

        try {
            // Get full schedule
            $parametersSearch = [
                'securityToken' => $this->getUeSecurityToken(),
                'scheduledPaymentInternalId' => $scheduledPaymentInternalId,
                'customerId' => $customerId,
                'fromDateTime' => '2020-11-01',
                'toDateTime' => date('Y-m-d'),
                'start' => 0,
                'limit' => 1000
            ];
            $searchRecurringPayments = $this->soapClient->SearchRecurringPayments($parametersSearch);

            $recurringPaymentsResult = $searchRecurringPayments->SearchRecurringPaymentsResult;
            if (!empty($recurringPaymentsResult)) {
                if (isset($recurringPaymentsResult->Payment)) {
                    $payments = $recurringPaymentsResult->Payment;

                    if (is_object($payments)) {
                        $paymentData[] = $payments;
                    } else {
                        $paymentData = $payments;
                    }

                    foreach ($paymentData as $payment) {
                        if ($orderDate == date('Y-m-d', strtotime($payment->DatePaid))) {
                            $paymentInternalId = $payment->PaymentInternalId;
                            $this->cronlog('PaymentInternalId (' . $paymentInternalId . ') found against scheduledPaymentInternalId = ' . $scheduledPaymentInternalId);
                            return $paymentInternalId;
                        }
                    }
                } else {
                    $this->cronlog('No payment found against scheduledPaymentInternalId = ' . $scheduledPaymentInternalId);
                }
            } else {
                $this->log('No payment found against scheduledPaymentInternalId = ' . $scheduledPaymentInternalId);
            }

            return null;
        } catch (Exception $ex) {
            $this->cronlog(__METHOD__ . $ex->getMessage());
        }
    }

    /**
     * @param $paymentInternalId
     */
    public function markRecurringPaymentAsApplied($paymentInternalId)
    {
        $this->cronlog(__METHOD__);
        try {
            // Get full schedule
            $parametersPayment = [
                'securityToken' => $this->getUeSecurityToken(),
                'paymentInternalId' => $paymentInternalId
            ];

            $markRecurringPaymentAsApplied = $this->soapClient->MarkRecurringPaymentAsApplied($parametersPayment);
            $markRecurringPaymentAsAppliedResult = $markRecurringPaymentAsApplied->MarkRecurringPaymentAsAppliedResult;

            if (!empty($markRecurringPaymentAsAppliedResult)) {
                if ($markRecurringPaymentAsAppliedResult->StatusCode == 1) {
                    $this->cronlog('Payment is marked as applied against PaymentInternalId = ' . $paymentInternalId);
                } else {
                    $this->cronlog('Payment is not marked as applied against PaymentInternalId = ' . $paymentInternalId);
                }
            } else {
                $this->cronlog('Payment is not marked as applied against PaymentInternalId = ' . $paymentInternalId);
            }
        } catch (Exception $ex) {
            $this->cronlog('There is an error in mark as applied process.' . $ex->getMessage());
        }
    }

    /**
     * Delete customer payment method
     *
     * @param $customerToken
     * @param $methodId
     * @return bool
     */
    public function deleteCustomerPaymentMethod($customerToken, $methodId): bool
    {
        try {
            $params = [
                'securityToken' => $this->getUeSecurityToken(),
                'customerToken' => $customerToken,
                'paymentMethodId' => $methodId,
            ];

            $this->soapClient->deleteCustomerPaymentMethodProfile($params);

            return true;
        } catch (\Exception $ex) {
            $this->log($ex->getMessage());
        }
        return false;
    }

    /**
     * Update customer payment method profile
     *
     * @param $customerToken
     * @param $paymentMethodObject
     * @return bool
     */
    public function updatePaymentMethod($customerToken, $paymentMethodObject)
    {
        try {
            $params = [
                'securityToken' => $this->getUeSecurityToken(),
                'customerToken' => $customerToken,
                'paymentMethodProfile' => $paymentMethodObject,
            ];

            $updatedMethodProfile = $this->soapClient->updateCustomerPaymentMethodProfile($params);

            if (isset($updatedMethodProfile->UpdateCustomerPaymentMethodProfileResult)) {
                return true;
            }
        } catch (\Exception $ex) {
            $this->log($ex->getMessage());
        }
        return false;
    }

    //---------------- EBizCharge Methods End -----------
}
