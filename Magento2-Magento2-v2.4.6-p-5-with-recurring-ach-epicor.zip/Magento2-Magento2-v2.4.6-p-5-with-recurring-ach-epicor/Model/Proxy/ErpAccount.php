<?php
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Model\Proxy;

use Ebizcharge\Ebizcharge\Model\Token;
use Magento\Framework\Module\Manager;
use Magento\Framework\ObjectManager\NoninterceptableInterface;
use Magento\Framework\ObjectManagerInterface;

/**
 * ErpAccount proxy
 * Only going to work if epiCor module is installed
 */
class ErpAccount implements NoninterceptableInterface
{
    /**
     * @const EPI_CORE_MODULE_NAME
     */
    const EPI_COR_MODULE_NAME = 'Epicor_Comm';

    /**
     * @const EPI_CORE_CUSTOMER_CLASS
     */
    const EPI_COR_CUSTOMER_CLASS = '\Epicor\Comm\Model\Customer\Erpaccount';

    /**
     * Object manager
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * Will be available only if epiCor_Comm module is installed
     * @var \Epicor\Comm\Model\Customer\Erpaccount
     */
    protected $_subject = null;

    /**
     * @var Manager
     */
    private $moduleManager;

    /**
     * Proxied erpAccount instance name
     *
     * @var string
     */
    protected $_instanceName = null;
    /**
     * @var Token
     */
    private $customerTokenManagement;

    /**
     * Customer ErrpAccount model
     */
    private $model = null;

    /**
     * @param Token $customerTokenManagement
     * @param Manager $moduleManager
     * @param ObjectManagerInterface $objectManager
     * @param string $instanceName
     */
    public function __construct(
        Token $customerTokenManagement,
        Manager $moduleManager,
        ObjectManagerInterface $objectManager,
        $instanceName = '\\Epicor\\Comm\\Model\\Customer\\Erpaccount'
    ) {
        $this->_objectManager = $objectManager;
        $this->_instanceName = $instanceName;
        $this->moduleManager = $moduleManager;
        $this->customerTokenManagement = $customerTokenManagement;
    }

    /**
     * Retrieve epiCor subject
     *
     * @return \Epicor\Comm\Model\Customer\Erpaccount
     */
    protected function _getSubject()
    {
        if (!$this->_subject && $this->epiCorEnabled()) {
            $this->_subject = $this->_objectManager->get($this->_instanceName);
        }
        return $this->_subject;
    }

    /**
     * Check if epicor_comm module is enable
     * @return bool
     */
    public function epiCorEnabled()
    {
        return $this->moduleManager->isEnabled(static::EPI_COR_MODULE_NAME);
    }

    /**
     * Call epiCor methods, if class exist
     * @param $method_name
     * @param $args
     * @return mixed
     */
    public function __call($method_name, $args)
    {
        if ($this->_getSubject()) {
            return call_user_func_array(array($this->_subject, $method_name), $args);
        }
        return null;
    }

    /**
     * @param $customer
     * @return string|null
     */
    public function getCustomerInternalId($customer)
    {
        try {

            if ($erpErpaccountId = $this->getErpAccountId($customer)) {

                $internalId = $this->customerTokenManagement->getCollection()
                    ->addFieldToFilter('erp_erpaccount_id', $erpErpaccountId)
                    ->getFirstItem()
                    ->getEbzcCustId();

                if ($internalId && trim($internalId)) {
                    return trim($internalId);
                }
            }
        } catch (\Exception $e) {
            $message = $e->getMessage();
        }
        return null;
    }

    /**
     * @param $customer
     * @return \Epicor\Comm\Model\Customer\Erpaccount|null
     */
    public function loadErpCustomer($customer)
    {
        if (!$this->model && $model = $this->_getSubject()) {
            $this->model = $model->load($customer->getEccErpaccountId());
        }
        return $this->model;
    }

    /**
     * @param $customer
     * @param $ebzcCustId
     * @return void
     */
    public function updateErpCustomer($customer, $ebzc_cust_id)
    {

        if ($erpErpaccountId = $this->getErpAccountId($customer)) {
            try {
                $customerToken = $this->customerTokenManagement->load($customer->getId(), 'mage_cust_id');

                $ebzc_token = $customerToken->setData('mage_cust_id', $customer->getId())
                    ->setData('ebzc_cust_id', $ebzc_cust_id)
                    ->setData('erp_erpaccount_id', $erpErpaccountId)
                    ->save();

            } catch (\Exception $e) {
                $message = $e->getMessage();
            }
        } else {
            try {
                $customerToken = $this->customerTokenManagement->load($customer->getId(), 'mage_cust_id');

                $ebzc_token = $customerToken->setData('mage_cust_id', $customer->getId())
                    ->setData('ebzc_cust_id', $ebzc_cust_id)
                    ->setData('erp_erpaccount_id', '')
                    ->save();

            } catch (\Exception $e) {
                $message = $e->getMessage();
            }
        }

    }

    public function erpCustomerProcess($customer)
    {
        $internalId = null;
        if ($customer->getEccErpaccountId() > 0) {
            if ($internalId = $this->getCustomerInternalId($customer)) {
                return $internalId;
            } else {
                $internalId = null;
                /**
                 * @note search customer erpAccountId on the gateway, and update to token table
                 * @note cannot handle here due to circular dependency issue
                 * @note handle this in the class from where you are calling this method
                 */
            }

        } else {
            $internalId = $this->customerTokenManagement->getCollection()
                ->addFieldToFilter('mage_cust_id', $customer->getId())
                ->getFirstItem()
                ->getEbzcCustId();
        }

        return $internalId;

    }

    /**
     * Customer Erp Account Id
     * @param $customer
     * @return string|null
     */
    public function getErpAccountId($customer)
    {
        $erpErpAccountId = null;
        $model = $this->loadErpCustomer($customer);

        if ($model && $model->getId()) {
            $erpErpAccountId = $model->getCompany() . "-" . $model->getAccountNumber();
        }

        return $erpErpAccountId;
    }

}
