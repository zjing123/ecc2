<?php
/**
 * Handles all the payment functions - authorize, capture, refund, etc.
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */

namespace Ebizcharge\Ebizcharge\Model;

ini_set('memory_limit', '2000M');
ini_set('max_execution_time', 300);

use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Customer\Model\Customer;
use Magento\Framework\DataObject;
use Magento\Sales\Api\Data\TransactionSearchResultInterface;
use Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory;

class Payment extends \Magento\Payment\Model\Method\Cc
{
    protected $_formBlockType = \Ebizcharge\Ebizcharge\Block\Form\Card::class;

    /**
     * @var string
     */
    protected $_infoBlockType = \Ebizcharge\Ebizcharge\Block\Info\Cc::class;

    const CODE = 'ebizcharge_ebizcharge';
    const ACH = 'ACH';

    protected $_code = self::CODE;

    protected $_isGateway = true;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canCapturePartial = true;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;
    protected $_canVoid = true;
    protected $_canUseInternal = true;
    protected $_canUseCheckout = true;
    protected $_canUseForMultishipping = true;

    protected $_canSaveCc = false;

    protected $_authMode = 'auto';

    protected $_countryFactory;
    protected $_minAmount = null;
    protected $_maxAmount = null;
    protected $_supportedCurrencyCodes = [];
    protected $_debugReplacePrivateDataKeys = ['number', 'exp_month', 'exp_year', 'cvc'];
    protected $backendAuthSession;
    protected $customerSession;
    protected $_token;
    protected $_tran;
    protected $config;
    protected $_paymentConfig;
    protected $_scopeConfig;
    protected $sessionQuote;

    /**
     * @var TransactionSearchResultInterfaceFactory
     */
    private $transactionSearchResultInterfaceFactory;

    /**
     * epi core customer management
     * @var \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount
     */
    private $epiCorCustomer;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    private $customerFactory;

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
     * @param \Magento\Directory\Model\CountryFactory $countryFactory
     * @param \Magento\Backend\Model\Auth\Session $backendAuthSession
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param TranApi $tranApi
     * @param Token $token
     * @param Config $config
     * @param \Magento\Payment\Model\Config $paymentConfig
     * @param \Magento\Backend\Model\Session\Quote $sessionQuote
     * @param Proxy\ErpAccount $epiCorCustomer
     * @param TransactionSearchResultInterfaceFactory $transactionSearchResultInterfaceFactory
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context                        $context,
        \Magento\Framework\Registry                             $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory       $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory            $customAttributeFactory,
        \Magento\Payment\Helper\Data                            $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface      $scopeConfig,
        \Magento\Payment\Model\Method\Logger                    $logger,
        \Magento\Framework\Module\ModuleListInterface           $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface    $localeDate,
        \Magento\Directory\Model\CountryFactory                 $countryFactory,
        \Magento\Backend\Model\Auth\Session                     $backendAuthSession,
        \Magento\Customer\Model\Session                         $customerSession,
        \Magento\Customer\Model\CustomerFactory                 $customerFactory,
        \Ebizcharge\Ebizcharge\Model\TranApi                    $tranApi,
        \Ebizcharge\Ebizcharge\Model\Token                      $token,
        \Ebizcharge\Ebizcharge\Model\Config                     $config,
        \Magento\Payment\Model\Config                           $paymentConfig,
        \Magento\Backend\Model\Session\Quote                    $sessionQuote,
        \Ebizcharge\Ebizcharge\Model\Proxy\ErpAccount           $epiCorCustomer,
        TransactionSearchResultInterfaceFactory                 $transactionSearchResultInterfaceFactory,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb           $resourceCollection = null,
        array                                                   $data = []
    )
    {
        $this->_tran = $tranApi;
        $this->_token = $token;
        $this->config = $config;
        $this->_paymentConfig = $paymentConfig;
        $this->_scopeConfig = $scopeConfig;
        $this->sessionQuote = $sessionQuote;

        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $moduleList,
            $localeDate,
            null,
            null,
            $data
        );

        $this->_countryFactory = $countryFactory;
        $this->backendAuthSession = $backendAuthSession;
        $this->customerSession = $customerSession;

        $this->_minAmount = $this->getConfigData('min_order_total');
        $this->_maxAmount = $this->getConfigData('max_order_total');
        $this->_supportedCurrencyCodes[] = $this->getConfigData('currency');
        $this->transactionSearchResultInterfaceFactory = $transactionSearchResultInterfaceFactory;
        $this->epiCorCustomer = $epiCorCustomer;
        $this->customerFactory = $customerFactory;
        $this->erpCustomerProcess($this->getRequestCustomer());
    }

    /**
     * Validates payment object.
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     */
    public function validate()
    {
        $info = $this->getInfoInstance();
        return $this;
    }

    public function setCardType($paymentMethod)
    {
        $cardType = '';
        if (!empty($paymentMethod) && isset($paymentMethod->CardType)) {
            if ($paymentMethod->CardType == 'V') {
                $cardType = "VI";
            } elseif ($paymentMethod->CardType == 'M') {
                $cardType = "MC";
            } elseif ($paymentMethod->CardType == 'A') {
                $cardType = "AE";
            } elseif ($paymentMethod->CardType == 'DS') {
                $cardType = "DS";
            } elseif ($paymentMethod->CardType == 'ACH') {
                $cardType = "ACH";
            }
        } elseif ($paymentMethod->MethodType == 'check') {
            $cardType = self::ACH;
        }

        return $cardType;
    }

    /**
     * Assigns preliminary form data (ebizcharge.js - getData()) to $infoInstance, which is the payment object.
     * First Load Cards from #14 and #15 and assign to Customer and set for eBiz #16
     */
    public function assignData(\Magento\Framework\DataObject $data)
    {
        $tran = $this->_tran;

        $_tmpData = $data->_data;

        $_paymentToken = '';
        $_serializedAdditionalData = serialize($_tmpData['additional_data']);

        $additionalDataRef = $_serializedAdditionalData;
        $additionalDataRef = unserialize($additionalDataRef);

        $_paymentToken = $additionalDataRef['paymentToken'] ?? null;
        $_saveCard = $additionalDataRef['ebzc_save_payment'] ?? false;

        $_ebzcAvsStreet = $additionalDataRef['ebzc_avs_street'] ?? null;
        $_ebzcAvsZip = $additionalDataRef['ebzc_avs_zip'] ?? null;

        $additionalData = $data->getData(\Magento\Quote\Api\Data\PaymentInterface::KEY_ADDITIONAL_DATA);

        $infoInstance = $this->getInfoInstance();
        $infoInstance->setAdditionalInformation('payment_token', $_paymentToken);
        $infoInstance->setAdditionalInformation('save_card', $_saveCard);

        if (!is_object($additionalData)) {
            $additionalData = new DataObject($additionalData ?: []);
        }

        if ($additionalData->getEbzcOption() == "new") {
            if ($additionalData->getEbzcOptionType() == self::ACH) {
                $infoInstance->setCcType($additionalData->getCcType())
                    ->setCcOwner($additionalData->getAchType() . ' ' . $additionalData->getCcOwner())
                    ->setCcLast4(!empty($additionalData->getCcNumber()) ? substr($additionalData->getCcNumber(), -4) : '')
                    ->setCcNumber($additionalData->getCcNumber())
                    ->setCcCid($additionalData->getCcCid())
                    ->setAchRoute($additionalData->getAchRouting())
                    ->setAchType($additionalData->getAchType())
                    ->setEbzcOption($additionalData->getEbzcOption())
                    ->setEbzcCustId($additionalData->getEbzcCustId())
                    ->setEbzcSavePayment($additionalData->getEbzcSavePayment());
                $infoInstance->setAdditionalInformation('ach_type', $additionalData->getAchType());
                $infoInstance->setAdditionalInformation('ach_route', $additionalData->getAchRouting());
            } else {
                $infoInstance->setCcType($additionalData->getCcType())
                    ->setCcOwner($additionalData->getCcOwner())
                    ->setCcLast4(!empty($additionalData->getCcNumber()) ? substr($additionalData->getCcNumber(), -4) : '')
                    ->setCcNumber($additionalData->getCcNumber())
                    ->setCcCid($additionalData->getCcCid())
                    ->setCcExpMonth($additionalData->getCcExpMonth())
                    ->setCcExpYear($additionalData->getCcExpYear())
                    ->setCcSsIssue($additionalData->getCcSsIssue())
                    ->setCcSsStartMonth($additionalData->getCcSsStartMonth())
                    ->setCcSsStartYear($additionalData->getCcSsStartYear())
                    ->setEbzcOption($additionalData->getEbzcOption())
                    ->setEbzcCustId($additionalData->getEbzcCustId())
                    ->setEbzcSavePayment($additionalData->getEbzcSavePayment());
            }

            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData->getEbzcOption());
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData->getEbzcCustId());
            $infoInstance->setAdditionalInformation('ebzc_method_id', $additionalData->getEbzcMethodId());
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData->getEbzcSavePayment());
        } elseif ($additionalData->getEbzcOption() == "saved") {
            $tran->savedMethodId = $additionalData->getEbzcMethodId();

            $paymentMethods = $this->_tran->getCustomerPaymentMethodProfile(
                $additionalData->getEbzcCustId(),
                $additionalData->getEbzcMethodId()
            );

            if ($additionalData->getEbzcOptionType() == self::ACH) {
                $infoInstance->setEbzcOption($additionalData->getEbzcOption())
                    ->setCcType($this->setCardType($paymentMethods))
                    ->setEbzcMethodId($additionalData->getEbzcMethodId())
                    ->setEbzcCustId($additionalData->getEbzcCustId())
                    ->setCcOwner($paymentMethods->MethodName)
                    ->setCcLast4(!empty($paymentMethods->Account) ? substr($paymentMethods->Account, -4) : '')
                    ->setCcNumber($paymentMethods->Account)
                    ->setEbzcSavePayment($additionalData->getEbzcSavePayment());

                $infoInstance->setAdditionalInformation('ach_type', $paymentMethods->AccountType);
                $infoInstance->setAdditionalInformation('ach_route', $additionalData->getAchRouting());
            } else {
                $infoInstance->setEbzcOption($additionalData->getEbzcOption())
                    ->setEbzcMethodId($additionalData->getEbzcMethodId())
                    ->setEbzcCustId($additionalData->getEbzcCustId())
                    ->setCcType($this->setCardType($paymentMethods))
                    ->setCcOwner($paymentMethods->MethodName)
                    ->setCcLast4(!empty($paymentMethods->CardNumber) ? substr($paymentMethods->CardNumber, -4) : '')
                    ->setCcNumber($paymentMethods->CardNumber)
                    ->setCcExpMonth(!empty($paymentMethods->CardExpiration) ? substr($paymentMethods->CardExpiration, 5, 2) : '')
                    ->setCcExpYear(!empty($paymentMethods->CardExpiration) ? substr($paymentMethods->CardExpiration, 0, 4) : '')
                    ->setCcCid($additionalData->getCcCid())
                    ->setEbzcSavePayment($additionalData->getEbzcSavePayment());
            }

            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData->getEbzcOption());
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData->getEbzcCustId());
            $infoInstance->setAdditionalInformation('ebzc_method_id', $additionalData->getEbzcMethodId());
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData->getEbzcSavePayment());
        } elseif ($additionalData->getEbzcOption() == "update") {
            $tran->savedMethodId = $additionalData->getEbzcMethodId();

            try {
                $paymentMethods = $this->_tran->getCustomerPaymentMethodProfile(
                    $additionalData->getEbzcCustId(),
                    $additionalData->getEbzcMethodId()
                );
            } catch (Exception $ex) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Update Method:' . $ex->getMessage()));
            }

            $infoInstance->setEbzcOption($additionalData->getEbzcOption())
                ->setEbzcMethodId($additionalData->getEbzcMethodId())
                ->setEbzcCustId($additionalData->getEbzcCustId())
                ->setCcType($this->setCardType($paymentMethods))
                ->setCcOwner($paymentMethods->MethodName)
                ->setCcLast4(!empty($paymentMethods->CardNumber) ? substr($paymentMethods->CardNumber, -4) : '')
                ->setCcNumber($paymentMethods->CardNumber)
                ->setCcExpMonth($additionalData->getCcExpMonth())
                ->setCcExpYear($additionalData->getCcExpYear())
                ->setCcCid($additionalData->getCcCid())
                ->setEbzcAvsStreet($additionalData->getEbzcAvsStreet())
                ->setEbzcAvsZip($additionalData->getEbzcAvsZip())
                ->setEbzcSavePayment($additionalData->getEbzcSavePayment());

            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData->getEbzcOption());
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData->getEbzcCustId());
            $infoInstance->setAdditionalInformation('ebzc_method_id', $additionalData->getEbzcMethodId());
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData->getEbzcSavePayment());
            $infoInstance->setAdditionalInformation('ebzc_avs_street', $_ebzcAvsStreet);
            $infoInstance->setAdditionalInformation('ebzc_avs_zip', $_ebzcAvsZip);
        } elseif ($additionalData->getEbzcOption() == "paylater") {
            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData->getEbzcOption());
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData->getEbzcCustId());
            $infoInstance->setAdditionalInformation('ebzc_method_id', $additionalData->getEbzcMethodId());
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData->getEbzcSavePayment());
            $infoInstance->setAdditionalInformation('ebzc_paylater_payment', $additionalData->getEbzcPaylaterPayment());
        } elseif ($additionalData->getEbzcOption() == "downloadorder") {
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData['mage_cust_id']);
            $infoInstance->setAdditionalInformation('ebzc_method_id', ($additionalData['ebzc_method_id'] ?? null));
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData['ebzc_save_payment']);
            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData['ebzc_option']);
            $infoInstance->setAdditionalInformation('ebzc_avs_street', $additionalData['AvsStreet']);
            $infoInstance->setAdditionalInformation('ebzc_avs_zip', $additionalData['AvsZip']);
            $infoInstance->setAdditionalInformation('authorize_data', $additionalData->_data);
        } elseif ($additionalData->getEbzcOption() == "recurring") {
            $tran->savedMethodId = $additionalData->getEbzcMethodId();

            $paymentMethods = $this->_tran->getCustomerPaymentMethodProfile(
                $additionalData->getEbzcCustId(),
                $additionalData->getEbzcMethodId()
            );

            if ($paymentMethods->MethodType == 'check') {
                $ccNumber = $paymentMethods->Account;
                $ccLastNumbers = !empty($ccNumber) ? substr($ccNumber, -4) : '';
            } else {
                $ccNumber = $paymentMethods->CardNumber;
                $ccLastNumbers = !empty($ccNumber) ? substr($ccNumber, -4) : '';
            }

            $infoInstance->setEbzcOption($additionalData->getEbzcOption())
                ->setEbzcMethodId($additionalData->getEbzcMethodId())
                ->setEbzcCustId($additionalData->getEbzcCustId())
                ->setCcType($this->setCardType($paymentMethods))
                ->setCcOwner($paymentMethods->MethodName)
                ->setCcLast4($ccNumber)
                ->setCcNumber($ccLastNumbers)
                ->setCcExpMonth($additionalData->getCcExpMonth())
                ->setCcExpYear($additionalData->getCcExpYear())
                ->setCcCid($additionalData->getCcCid())
                ->setEbzcAvsStreet($additionalData->getEbzcAvsStreet())
                ->setEbzcAvsZip($additionalData->getEbzcAvsZip())
                ->setEbzcSavePayment($additionalData->getEbzcSavePayment());

            $infoInstance->setAdditionalInformation('ebzc_option', $additionalData['ebzc_option']);
            $infoInstance->setAdditionalInformation('ebzc_option_new', $additionalData['ebzc_option_new']);
            $infoInstance->setAdditionalInformation('ebzc_option_existing', $additionalData['ebzc_option_existing']);
            $infoInstance->setAdditionalInformation('ebzc_cust_id', $additionalData['ebzc_cust_id']);
            $infoInstance->setAdditionalInformation('mage_cust_id', $additionalData['mage_cust_id']);
            $infoInstance->setAdditionalInformation('ebzc_method_id', $additionalData['ebzc_method_id']);
            $infoInstance->setAdditionalInformation('excludeAmount', $additionalData['excludeAmount']);
        } else {
            $infoInstance->setEbzcSavePayment($additionalData->getEbzcSavePayment());
            $infoInstance->setAdditionalInformation('ebzc_save_payment', $additionalData->getEbzcSavePayment());
            return parent::assignData($additionalData);
        }

        return $this;
    }

    /**
     * Authorizes payment.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @param float
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $tran = $this->_tran;
        //------------- For download orders start -----------------
        if ($payment->getAdditionalInformation('ebzc_option') == 'downloadorder') {
            $new_authorize_data = $payment->getAdditionalInformation('authorize_data');
            // New Parms added
            $tran->authcode = isset($new_authorize_data['AuthCode']) ? $new_authorize_data['AuthCode'] : "";
            $tran->refnum = isset($new_authorize_data['RefNum'])? $new_authorize_data['RefNum'] : "";
            $tran->avs_result_code = isset($new_authorize_data['AvsResultCode'])? $new_authorize_data['AvsResultCode'] : "";
            $tran->cvv2_result_code = isset($new_authorize_data['CardCodeResultCode'])? $new_authorize_data['CardCodeResultCode'] : "";
            $tran->resultcode = isset($new_authorize_data['ResultCode'])? $new_authorize_data['ResultCode'] : "";
            $tran->result = isset($new_authorize_data['Result'])? $new_authorize_data['Result']: "";
            $tran->command = isset($new_authorize_data['TransactionType']) ? : "";

            // store response variables
            $payment->setCcApproval($tran->authcode)
                ->setCcTransId($tran->refnum)
                ->setCcAvsStatus($tran->avs_result_code)
                ->setCcCidStatus($tran->cvv2_result_code);

            $ccLast4 = !empty($new_authorize_data['CardNumber']) ? substr($new_authorize_data['CardNumber'], -4) : '';
            // add the special ebzc fields to the database
            $payment->getMethodInstance()->getInfoInstance()->setEbzcCustId($new_authorize_data['CustNum']);
            $payment->getMethodInstance()->getInfoInstance()->setEbzcMethodId($new_authorize_data['ebzc_method_id']);
            $payment->getMethodInstance()->getInfoInstance()->setEbzcSavePayment($new_authorize_data['ebzc_save_payment']);
            $payment->getMethodInstance()->getInfoInstance()->setEbzcOption($new_authorize_data['ebzc_option']);
            $payment->getMethodInstance()->getInfoInstance()->setEbzcAvsStreet($new_authorize_data['AvsStreet']);
            $payment->getMethodInstance()->getInfoInstance()->setEbzcAvsZip($new_authorize_data['AvsZip']);
            // New params
            $payment->getMethodInstance()->getInfoInstance()->setShippingCaptured($new_authorize_data['Shipping']);
            $payment->getMethodInstance()->getInfoInstance()->setBaseShippingCaptured($new_authorize_data['Shipping']);
            $payment->getMethodInstance()->getInfoInstance()->setCcExpMonth($new_authorize_data['cc_exp_month']);
            $payment->getMethodInstance()->getInfoInstance()->setCcApproval($new_authorize_data['AuthCode']);
            $payment->getMethodInstance()->getInfoInstance()->setCcLast4($ccLast4);
            $payment->getMethodInstance()->getInfoInstance()->setCcOwner($new_authorize_data['cc_owner']);
            $payment->getMethodInstance()->getInfoInstance()->setCcType($new_authorize_data['cc_type']);
            $payment->getMethodInstance()->getInfoInstance()->setPoNumber($new_authorize_data['PONum']);
            $payment->getMethodInstance()->getInfoInstance()->setCcExpYear($new_authorize_data['cc_exp_year']);
            $payment->getMethodInstance()->getInfoInstance()->setCcAvsStatus($new_authorize_data['AvsResultCode']);

            if ($tran->resultcode == 'A') {
                //$payment->setLastTransId($setLastTransId);
                $payment->setLastTransId($tran->refnum);
                $payment->setTransactionId($tran->refnum);
                $payment->setIsTransactionClosed(0)->setTransactionAdditionalInfo('trans_id', $tran->refnum);
                $payment->setStatus(self::STATUS_APPROVED);
            } else {
                $tran->log('Transaction not completed for ' . $tran->refnum, '');
                $payment->setLastTransId($tran->refnum);
                $payment->setTransactionId($tran->refnum);
                $payment->setIsTransactionClosed(0)->setTransactionAdditionalInfo('trans_id', $tran->refnum);
                $payment->setStatus(self::STATUS_ERROR);
                $tran->log('Transaction not completed for ' . $tran->refnum, '');
            }

            return $this;
            exit();
        }
        //------------- For download orders end -----------------
        // general payment data
        $tran->cardholder = $payment->getCcOwner() ?? "";
        $tran->card = $payment->getCcNumber() ?? "";
        $tran->cardtype = $payment->getCcType() ?? "";
        $tran->exp = $payment->getCcExpMonth() . substr($payment->getCcExpYear() ?? '', 2, 2);
        $tran->cvv2 = $payment->getCcCid() ?? "";
        $tran->amount = $amount ?? 0;

        $tran->achtype = $payment->getAdditionalInformation('ach_type');
        $tran->achroute = $payment->getAdditionalInformation('ach_route');

        // if order exists,  add order data
        $order = $payment->getOrder();

        /**
         * if the order is recurring, then customer new payment method will be saved in any case
         * @var $recurringOrder
         */
        $recurringOrder = false;

        /**  check if there is a recurring product in the order */
        foreach ($order->getAllVisibleItems() as $item) {
            if (isset($item->getProductOptions()['info_buyRequest']['recurring'])) {
                $recurringOrder = true;
                break;
            }
        }

        if (!empty($order)) {
            $orderid = $order->getIncrementId() ?? "";
            $tran->invoice = $orderid ?? "";
            $tran->orderid = $orderid ?? "";
            $tran->ponum = $orderid ?? "";
            $tran->ip = $order->getRemoteIp() ?? "";
            $tran->custid = $order->getCustomerId() ?? "";
            $tran->email = $order->getCustomerEmail() ?? "";

            $tran->tax = (float)$order->getTaxAmount() ?? 0;
            $tran->shipping = (float)$order->getShippingAmount() ?? 0;

            // avs data
            list($avsstreet) = $order->getBillingAddress()->getStreet();
            $tran->street = $avsstreet ?? "";
            $tran->zip = $order->getBillingAddress()->getPostcode() ?? "";

            $tran->description = ($this->getConfigData('description') ? str_replace('[orderid]', $orderid, $this->getConfigData('description')) : "Magento Order #" . $orderid);

            // Set Recurring Values
            $tran->recurringMethodId = $payment->getAdditionalInformation('ebzc_method_id') ?? "";
            // New Function #1 added by IF
            // set order shipping info
            $tran->setOrderShipping($order);
            // New Function #2 added by IF
            // add order billing info
            $tran->setOrderBilling($order);

            foreach ($order->getAllVisibleItems() as $item) {
                if (($item->getFinalPrice() > 0) || ($item->getProductType() == 'virtual')) {
                    $tran->addLine(
                        $item->getSku() ?? "",
                        $item->getName() ?? "",
                        '',
                        $item->getFinalPrice() ?? "0",
                        $item->getQtyOrdered() ?? "0",
                        $item->getTaxAmount() ?? "0",
                        $item->getProductId() ?? "",
                        $item->getDiscountAmount() ?? "0"
                    );
                    $tran->addLineItem(
                        $item->getSku() ?? "",
                        $item->getName() ?? "",
                        '',
                        $item->getFinalPrice() ?? "0",
                        $item->getQtyOrdered() ?? "0",
                        $item->getTaxAmount() ?? "0",
                        $item->getProductId() ?? "",
                        $item->getDiscountAmount() ?? "0",
                        $item->getDiscountPercent() ?? "",
                        $item->getDiscountInvoiced() ?? ""
                    );
                }
            }

            if ($tran->custid == null) {
                $tran->custid = "Guest";
            }
        }

        if ($this->getConfigData('payment_action') == self::ACTION_AUTHORIZE && $this->_authMode != 'capture') {
            $tran->command = 'authonly';
        } else {
            $tran->command = 'sale';
        }

        // get magento customer session
        if (!$order->getCustomerId()) {
            // Processing a guest checkout
            $tran->runTransaction();
        } else {
            // For loggedin Customer
            if ($payment->getAdditionalInformation('ebzc_option') == 'new') {
                //new method added by customer
                if ($this->config->getPaymentSavePayment() || $recurringOrder ||
                    ($this->getConfigData('save_payment') || $payment->getAdditionalInformation('ebzc_save_payment'))
                ) {
                    if (($payment->getAdditionalInformation('ebzc_cust_id') == null)) {
                        $tran->tokenProcess($order->getCustomerId(), $payment);
                    } else {
                        // SearchCustomer, AddPaymentMethod
                        $tran->newPaymentProcess($order->getCustomerId(), $payment->getAdditionalInformation('ebzc_cust_id'), $payment);
                    }
                } else {
                    // Processing a guest checkout
                    $tran->runTransaction();
                }
            } elseif ($payment->getAdditionalInformation('ebzc_option') == 'saved') {
                // Existing payment method selected by customer
                $tran->savedProcess($payment->getAdditionalInformation('ebzc_cust_id'), $payment->getAdditionalInformation('ebzc_method_id'), $payment);
            } elseif ($payment->getAdditionalInformation('ebzc_option') == 'update') {
                // Existing payment method selected by customer
                $tran->updateProcess($payment->getAdditionalInformation('ebzc_cust_id'), $payment->getAdditionalInformation('ebzc_method_id'), $payment);
            } elseif ($payment->getAdditionalInformation('ebzc_option') == 'paylater') {
                // payment will be paid later on gataway
                if ($payment->getAdditionalInformation('ebzc_paylater_payment') == 1) {
                    $payment->setIsTransactionClosed(0)->setTransactionAdditionalInfo('trans_id', 'paylater');
                    $payment->setStatus(self::STATUS_APPROVED);
                    return $this;
                } else {
                    throw new \Magento\Framework\Exception\LocalizedException(__('Please select Pay Later checkbox to avail this functionality!'));
                }
            } elseif ($payment->getAdditionalInformation('ebzc_option') == 'downloadorder') {
//				$payment->setIsTransactionClosed(0)
//					->setTransactionAdditionalInfo('trans_id', $payment->getAdditionalInformation('RefNum'));
//				$payment->setStatus(self::STATUS_APPROVED);
//				return $this;
            } elseif ($payment->getAdditionalInformation('ebzc_option') == 'recurring') {
                $deductableAmount = ($amount - $payment->getAdditionalInformation('excludeAmount'));
                if ($deductableAmount <= 0) {
                    $payment->setIsTransactionClosed(0)->setTransactionAdditionalInfo('trans_id', 'recurring');
                    $payment->setStatus(self::STATUS_APPROVED);
                    return $this;
                } elseif ($deductableAmount > 0) {
                    $payment->getMethodInstance()->getInfoInstance()->setExcludeAmount($payment->getAdditionalInformation('excludeAmount'));

                    $tran->runCustomerTransaction($payment->getAdditionalInformation('ebzc_cust_id'), $payment->getAdditionalInformation('ebzc_method_id'), $payment, 1);
                } else {
                    return $this;
                }
            } else {
                //first time processing the transaction
                if ($this->config->getPaymentSavePayment() &&
                    $this->getConfigData('save_payment') || $payment->getAdditionalInformation('ebzc_save_payment')
                ) {
                    // AddCustomer, AddPaymentMethod
                    $tran->tokenProcess($order->getCustomerId(), $payment);
                } else {
                    // Processing a guest checkout
                    $tran->runTransaction();
                }
            }
        }

        // store response variables
        $payment->setCcApproval($tran->authcode)
            ->setCcTransId($tran->refnum)
            ->setCcAvsStatus($tran->avs_result_code)
            ->setCcCidStatus($tran->cvv2_result_code);

        // add the special ebzc fields to the database
        $payment->getMethodInstance()->getInfoInstance()->setEbzcCustId($payment->getAdditionalInformation('ebzc_cust_id'));
        $payment->getMethodInstance()->getInfoInstance()->setEbzcMethodId($payment->getAdditionalInformation('ebzc_method_id'));
        $payment->getMethodInstance()->getInfoInstance()->setEbzcSavePayment($payment->getAdditionalInformation('ebzc_save_payment'));
        $payment->getMethodInstance()->getInfoInstance()->setEbzcOption($payment->getAdditionalInformation('ebzc_option'));
        $payment->getMethodInstance()->getInfoInstance()->setEbzcAvsStreet($payment->getAdditionalInformation('ebzc_avs_street'));
        $payment->getMethodInstance()->getInfoInstance()->setEbzcAvsZip($payment->getAdditionalInformation('ebzc_avs_zip'));

        if ($tran->resultcode == 'A') {
            if ($this->getConfigData('payment_action') == self::ACTION_AUTHORIZE) {
                $payment->setLastTransId('0');
            } else {
                $payment->setLastTransId($tran->refnum);
            }

            if (!$payment->getParentTransactionId() || $tran->refnum != $payment->getParentTransactionId()) {
                $payment->setTransactionId($tran->refnum);
            }

            $payment->setIsTransactionClosed(0)
                ->setTransactionAdditionalInfo('trans_id', $tran->refnum);

            $payment->setStatus(self::STATUS_APPROVED);

        } elseif ($tran->resultcode == 'D') {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization transaction has been declined:  ' . $tran->error));
        } else {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization error:  ' . $tran->error . '(' . $tran->errorcode . ')'));
        }

        return $this;
    }

    /**
     * Processes quickSale.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @param float
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     */
    public function quickSale(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {

        $this->_tran->initTransactionAPI($payment->getOrder()->getStoreId());

        if (!$payment->getLastTransId()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Unable to find previous transaction to reference'));
        }
        // initialize transaction object
        $tran = $this->_tran;
        $tran->command = 'capture';
        $tran->amount = $amount ?? 0;

        if ($this->getConfigData('custreceipt')) {
            $tran->custreceipt = true;
            $tran->custreceipt_template = $this->getConfigData('custreceipt_template');
        }

        $orderid = $payment->getOrder()->getIncrementId();
        $tran->description = ($this->getConfigData('description') ?
            str_replace('[orderid]', $orderid, $this->getConfigData('description')) :
            "Order #" . $orderid);

        $this->isPartialCaptureAllowed($payment, $amount);

        $tran->setTransactionData($payment);

        $tran->runTransaction();

        if ($tran->resultcode == 'A') {
            $payment->setStatus(self::STATUS_APPROVED);

            if (!$payment->getParentTransactionId() ||
                $tran->refnum != $payment->getParentTransactionId()) {
                $payment->setTransactionId($tran->refnum);
            }
            $payment->setIsTransactionClosed(0)
                ->setTransactionAdditionalInfo('trans_id', $tran->refnum);

            // authOnly partial transaction
            $this->createPartialAuthOnly($payment, $amount);

            if ($tran->refnum) {
                $payment->setLastTransId($tran->refnum);
                $payment->setCcTransId($tran->refnum);
            }

        } elseif ($tran->resultcode == 'D') {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization transaction has been declined:  ' . $tran->error));
        } else {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization error:  ' . $tran->error . '(' . $tran->errorcode . ')'));
        }

        return $this;
    }

    /**
     * Refunds payment.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @param float
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     * @throws \Magento\Framework\Validator\Exception
     * order -> invoice -> credit memo -> refund
     */
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        // In case of free product invoice refund, not to refund amount online EbizCharge
        if ($amount == 0) {
            return $this;
        }

        if (!$payment->getLastTransId()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Unable to find previous transaction to reference'));
        }

        $error = false;
        $tran = $this->_tran;

        $tran->command = 'refund';
        $tran->amount = $amount;
        if ($this->getConfigData('custreceipt')) {
            $tran->custreceipt = true;
            $tran->custreceipt_template = $this->getConfigData('custreceipt_template');
        }

        $orderId = $payment->getOrder()->getIncrementId();
        $tran->description = ($this->getConfigData('description') ?
            str_replace('[orderid]', $orderId, $this->getConfigData('description')) :
            "Order #" . $orderId);

        $tran->setTransactionData($payment, true);

        if (!$tran->refundTransaction()) {
            $payment->setStatus(self::STATUS_ERROR);
            $error = __('Error in authorizing the payment: ' . $tran->error);
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment Declined: ' . $tran->error . $tran->errorcode));
        } else {
            $payment->setStatus(self::STATUS_APPROVED);
            if ($tran->refnum != $payment->getParentTransactionId()) {
                $payment->setTransactionId($tran->refnum);
            }
            $shouldCloseCaptureTransaction = $payment->getOrder()->canCreditmemo() ? 0 : 1;
            $payment->setIsTransactionClosed(1)
                ->setShouldCloseParentTransaction($shouldCloseCaptureTransaction)
                ->setTransactionAdditionalInfo('trans_id', $tran->refnum);
        }

        if ($error !== false) {
            throw new \Magento\Framework\Exception\LocalizedException($error);
        }
        return $this;
    }

    /**
     * Captures payment.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @param float
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     * @throws \Magento\Framework\Validator\Exception
     * n authorised -> invoiced -> online capture
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        // 1. In case of free product invoice capturing, not to capture amount
        // as EbizCharge didn't handle to capture $0 amount
        // 2. If capture request not initiated from Magento AdminHtml area then bypass
        if ($amount == 0 || ($payment->getOrder()->getTotalPaid() > 0 &&
                $this->config->getArea() != Area::AREA_ADMINHTML)) {
            return $this;
        }

        // we have already captured the original auth,  we need to do full sale
        //if ($payment->getLastTransId() && $payment->getOrder()->getTotalPaid() > 0) {
        //    return $this->quickSale($payment, $amount);
        //}
        // if we don't have a transid than we are need to authorize
        if (!$payment->getParentTransactionId()) {
            $this->_authMode = 'capture';
            return $this->authorize($payment, $amount);
        }

        $tran = $this->_tran;
        // Set command 'quicksale' if partial capture process initiated
        $tran->command = $amount != $payment->getOrder()->getGrandTotal() ? 'quicksale' : 'capture';
        $tran->amount = $amount ?? 0;

        $orderId = $payment->getOrder()->getIncrementId();
        $tran->description = ($this->getConfigData('description') ?
            str_replace('[orderid]', $orderId, $this->getConfigData('description')) :
            "Order #" . $orderId);

        //$this->isPartialCaptureAllowed($payment, $amount);

        $tran->setTransactionData($payment);

        if ($tran->command == 'quicksale') {
            $tran->refnum = $payment->getParentTransactionId();
        }

        $tran->runTransaction();

        // look at result code
        if ($tran->resultcode == 'A') {
            $payment->setStatus(self::STATUS_APPROVED);

            if (!$payment->getParentTransactionId() ||
                $tran->refnum != $payment->getParentTransactionId()) {
                $payment->setTransactionId($tran->refnum);
            }
            $payment->setIsTransactionClosed(0)
                ->setTransactionAdditionalInfo('trans_id', $tran->refnum);

            //$this->createPartialAuthOnly($payment, $amount);
            $payment->setLastTransId($tran->refnum);
            $payment->setCcTransId($tran->refnum);

            return $this;
        } elseif ($tran->resultcode == 'D') {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization transaction has been declined: ' . $tran->error));
        } else {
            throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization error: ' . $tran->error . '(' . $tran->errorcode . ')'));
        }
    }

    public function canVoid()
    {
        return true;
    }

    /**
     * Get Order Payment Transactions
     *
     * @param mixed $orderId
     * @param mixed $txnType
     * @return array|TransactionSearchResultInterface
     */
    public function getOrderPaymentTransactions($orderId = null, $txnType = '')
    {
        if (!$orderId) {
            return [];
        }

        $transactionCollection = $this->transactionSearchResultInterfaceFactory->create();
        $transactionCollection->addOrderIdFilter($orderId);

        if ($txnType) {
            $transactionCollection->addTxnTypeFilter($txnType);
        }

        return $transactionCollection;
    }

    /**
     * Set Transaction Reference No for Cancel/Void
     *
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @return void
     */
    private function setTransactionReferenceNo(\Magento\Payment\Model\InfoInterface $payment)
    {
        $order = $payment->getOrder();
        $authTransaction = $this->getOrderPaymentTransactions($order->getId(), 'authorization');
        $authTransactionId = $authTransaction ? $authTransaction->getFirstItem()->getTxnId() : '';
        if ($authTransactionId) {
            $this->_tran->refnum = $authTransactionId ?? "";
        }
    }

    /**
     * Voids transaction.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     */

    public function void(\Magento\Payment\Model\InfoInterface $payment)
    {
        if ($payment->getCcTransId()) {
            $order = $payment->getOrder();
            $tran = $this->_tran;
            $tran->amount = $order->getTotalDue() ?? 0;
            $tran->command = 'creditvoid';

            $tran->setTransactionData($payment);

            // To set that transaction no whose type is 'authorization' because
            // void only possible for Auth only request
            $this->setTransactionReferenceNo($payment);

            $tran->runTransaction();

            if ($tran->resultcode == 'A') {
                $payment->setStatus(self::STATUS_SUCCESS);
            } elseif ($tran->resultcode == 'D') {
                $payment->setStatus(self::STATUS_ERROR);
                throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization transaction has been declined: ' . $tran->error));
            } else {
                $payment->setStatus(self::STATUS_ERROR);
                throw new \Magento\Framework\Exception\LocalizedException(__('Payment authorization error: ' . $tran->error . '(' . $tran->errorcode . ')'));
            }
        } else {
            $payment->setStatus(self::STATUS_ERROR);
            throw new \Magento\Framework\Exception\LocalizedException(__('Invalid transaction id '));
        }
        return $this;
    }

    /**
     * Cancels transaction.
     *
     * @param \Magento\Payment\Model\InfoInterface
     * @return \Ebizcharge\Ebizcharge\Model\Payment
     * order -> dropdown -> cancel order
     */

    public function cancel(\Magento\Payment\Model\InfoInterface $payment)
    {
        if (!$this->config->disableAutoVoid()) {

            if ($payment->getCcTransId()) {
                $order = $payment->getOrder();
                $tran = $this->_tran;
                $tran->amount = $order->getTotalDue() ?? 0;
                $tran->command = 'creditvoid';

                $tran->setTransactionData($payment);

                // To set that transaction no whose type is 'authorization' because
                // void only possible for Auth only request
                $this->setTransactionReferenceNo($payment);

                if (!$tran->runTransaction()) {
                    throw new \Magento\Framework\Exception\LocalizedException(__('Transaction not void'));
                }

            } else {
                $payment->setStatus(self::STATUS_ERROR);
                throw new \Magento\Framework\Exception\LocalizedException(__('Invalid transaction id '));
            }
        }
        return $this;
    }

    /**
     * Returns Ebizcharge customer ID.
     * #1 for delete customer card
     */
    public function getEbzcCustId()
    {
        $customer = $this->getRequestCustomer();

        return $this->_token->getCollection()
            ->addFieldToFilter('mage_cust_id', $customer->getId())
            ->getFirstItem()
            ->getEbzcCustId();
    }

    /**
     * Returns saved payment methods.
     * getSavedCards Load in Dropdown Frontend #14 added by IF Done
     */

    public function getSavedAccounts()
    {
        return $this->_tran->getSavedAccounts($this->getEbzcCustId());
    }

    public function getSavedCards()
    {
        $ebzcCustomerId = $this->getEbzcCustId();

        if ($ebzcCustomerId) {
            $paymentMethods = $this->_tran->getCustomerPaymentMethods($ebzcCustomerId);

            $paymentMethodsNew = [];
            foreach ($paymentMethods as $key => $payment) {
                if ($payment->MethodType != 'check') {
                    $paymentMethodsNew[] = $paymentMethods[$key];
                }
            }

            return $paymentMethodsNew;
        }

        return [];
    }

    //---------- Unknown Functions ----------------

    /**
     * Checks whether CVV is required.
     */
    public function hasVerification()
    {
        $info = $this->getInfoInstance();

        if ($info->getEbzcOption()) {
            if ($this->config->getArea() == 'adminhtml') {
                if ($this->getConfigData('request_card_code_admin')) {
                    return true;
                } else {
                    return false;
                }
            } elseif ($this->config->getArea() == 'frontend') {
                return true;
            }
        } else {
            $configData = $this->getConfigData('useccv');

            if (is_null($configData)) {
                return true;
            }

            return (bool)$configData;
        }
    }

    public function getConfigInterface()
    {
        return $this;
    }

    /**
     * Check whether an EBizCharge customer ID is
     * associated with current magento customer ID
     *
     * @return boolean
     */
    public function hasToken()
    {
        if ($this->backendAuthSession->isLoggedIn()) {
            $customerId = $this->sessionQuote->getCustomerId();
        } else {
            $customerId = $this->customerSession->getId();
        }

        $_ebzc_cust_id = $this->_token->getCollection()->addFieldToFilter('mage_cust_id', $customerId)
            ->getFirstItem()
            ->getEbzcCustId();

        return empty($_ebzc_cust_id) ? false : true;
    }

    /**
     * Determine method availability based on quote amount and config data
     *
     * @param \Magento\Quote\Api\Data\CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        return true;

        if ($quote && ($quote->getBaseGrandTotal() < $this->_minAmount || ($this->_maxAmount && $quote->getBaseGrandTotal() > $this->_maxAmount))) {
            return false;
        }

        $hasSourceKey = $this->_scopeConfig->getValue('payment/ebizcharge_ebizcharge/sourcekey', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        if (!$hasSourceKey) {
            return false;
        }

        //return parent::isAvailable($quote);
    }

    /**
     * ACH bank account only allowed capture
     * @return string
     */
    public function getConfigPaymentAction()
    {
        if ($this->getInfoInstance()->getCcType() == 'ACH') {
            return self::ACTION_AUTHORIZE_CAPTURE;
        }
        return $this->getConfigData('payment_action');
    }

    /**
     * Is Partial Capture Allowed
     *
     * @param $payment
     * @param $amount
     * @return bool
     * @throws LocalizedException
     */
    private function isPartialCaptureAllowed($payment, $amount)
    {
        $orderDueTotal = $payment->getOrder()->getTotalDue();
        $remainingAmount = $orderDueTotal - $amount;

        if ($orderDueTotal != $amount && $remainingAmount > 0 &&
            (empty($payment->getEbzcCustId()) || empty($payment->getEbzcMethodId()))) {

            throw new LocalizedException(__('Unable to create partial invoice for this order.
            We have not found the save payment method for this customer.'));
        }

        return true;
    }

    /**
     * Create Partial Authority
     *
     * @param InfoInterface $payment
     * @param int $amount
     * @throws LocalizedException
     */
    public function createPartialAuthOnly($payment, $amount)
    {
        $this->isPartialCaptureAllowed($payment, $amount);

        $order = $payment->getOrder();
        $orderDueTotal = $order->getTotalDue();
        $remainingAmount = $orderDueTotal - $amount;

        if ($orderDueTotal != $amount && $remainingAmount > 0) {
            $orderId = $order->getIncrementId();
            $this->_tran->setTransactionData($payment);

            $this->_tran->command = 'authonly';
            $this->_tran->amount = $remainingAmount;
            $this->_tran->description = 'New Authonly transaction after partial capture of order Id #' . $orderId;
            $this->_tran->clearLineItems();

            /** @var OrderInterface $order */
            foreach ($order->getAllVisibleItems() as $item) {
                if ($item->getQtyToInvoice() > 0 && ($item->getFinalPrice() > 0) || ($item->getProductType() == 'virtual')) {
                    $this->_tran->addLine(
                        $item->getSku() ?? "",
                        $item->getName() ?? "",
                        '',
                        $item->getFinalPrice() ?? "0",
                        $item->getQtyOrdered() ?? "0",
                        $item->getTaxAmount() ?? "0",
                        $item->getProductId() ?? "0",
                        $item->getDiscountAmount() ?? "0"
                    );
                    $this->_tran->addLineItem(
                        $item->getSku() ?? "",
                        $item->getName() ?? "",
                        '',
                        $item->getFinalPrice() ?? "0",
                        $item->getQtyOrdered() ?? "0",
                        $item->getTaxAmount() ?? "0",
                        $item->getProductId() ?? "",
                        $item->getDiscountAmount() ?? "0",
                        $item->getDiscountPercent() ?? "",
                        $item->getDiscountInvoiced() ?? "0"
                    );
                }
            }

            $this->_tran->savedProcess($payment->getEbzcCustId(), $payment->getEbzcMethodId(), $amount, true);

            if ($this->_tran->resultcode == 'A') {
                $this->_tran->log('Partial transaction created for orderId:#' . $orderId . ' with reference No#' . $this->_tran->refnum);
            } else {
                $this->_tran->log('Error: Partial transaction not created for orderId:#' . $orderId . ' Error: ' . $this->_tran->error);
            }
        }
    }

    /**
     * Process erp customer
     * @param $customer
     * @return void
     */
    private function erpCustomerProcess($customer)
    {
        if ($this->epiCorCustomer->epiCorEnabled() && $customer && $customer->getEccErpaccountId() > 0) {
            if (empty($this->epiCorCustomer->getCustomerInternalId($customer))) {
                $ebizCustomer = $this->_tran->getCustomer($customer->getId());
                $ebzc_cust_id = $ebizCustomer->CustomerToken;
                $this->epiCorCustomer->updateErpCustomer($customer, $ebzc_cust_id);
            }

        }
    }

    /**
     * Get current request customer
     * @return Customer|null
     */
    private function getRequestCustomer()
    {
        if ($this->backendAuthSession->isLoggedIn()) {
            try {
                return $this->customerFactory->create()->load($this->sessionQuote->getCustomerId());
            } catch (\Exception $e) {
                $this->_tran->log($e->getMessage());
                return null;
            }
        }
        return $this->customerSession->getCustomer();

    }
}
