<?php
/**
 * Payment Items Method Source Model
 *
 * @author      Century Business Solutions <support@centurybizsolutions.com>
 * @copyright   Copyright (c) 2020 Century Business Solutions  (www.centurybizsolutions.com)
 */
namespace Ebizcharge\Ebizcharge\Model\Config;

use \Magento\Framework\Option\ArrayInterface;
use \Magento\Framework\Data\OptionSourceInterface;

class ItemsMethod implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        $attributesArrays = array();

        $attributesArrays[0] =array(
            'label' => 'Upload',
            'value' => 'upload'
        );
        $attributesArrays[1] =array(
            'label' => 'Download',
            'value' => 'download'
        );
       return $attributesArrays;

    }

}
