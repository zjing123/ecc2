<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 9/24/21
 * Time: 2:28 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Model;
use Psr\Log\LoggerInterface;

/**
 * Custom Logger
 *
 * Class EbizCustomLogger
 * @package Ebizcharge\Ebizcharge\Model
 */
class EbizCustomLogger
{
    /**
     * @var LoggerInterface
     */
    public $ebizPaymentLogger;

    /**
     * @var LoggerInterface
     */
    public $ebizCronLogger;

    /**
     * @param LoggerInterface $ebizPaymentLogger
     * @param LoggerInterface $ebizCronLogger
     */
    public function __construct(
        LoggerInterface $ebizPaymentLogger,
        LoggerInterface $ebizCronLogger
    ) {
        $this->ebizPaymentLogger = $ebizPaymentLogger;
        $this->ebizCronLogger = $ebizCronLogger;
    }

}
