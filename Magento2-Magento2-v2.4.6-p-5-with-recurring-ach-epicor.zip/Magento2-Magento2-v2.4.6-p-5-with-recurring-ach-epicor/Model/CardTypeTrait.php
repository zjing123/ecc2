<?php
/**
 * @author Century Business Solutions <support@centurybizsolutions.com>
 * @copyriht Copyright (c) 2021 Century Business Solutions  (www.centurybizsolutions.com)
 * Created by PhpStorm
 * User: Mobeen
 * Date: 12/30/21
 * Time: 2:07 PM
 */
declare(strict_types=1);

namespace Ebizcharge\Ebizcharge\Model;

/**
 * Card type common functionality
 *
 * Class CardTypeTrait
 * @package Ebizcharge\Ebizcharge\Model
 */
trait CardTypeTrait
{
    /**
     * Get card image path
     *
     * @param $cardType
     * @return string
     */
    public function getCardImagePath($cardType)
    {
        $imagePath = '';
        if ($image = $this->getCCTypeImage($cardType)) {
            $imagePath = 'Ebizcharge_Ebizcharge::images/' . $image;
        }
        return $imagePath;
    }

    /**
     * @param $cardType
     * @return string|null
     */
    public function getCCTypeImage($cardType)
    {
        $image = 'no-card.png';

        switch (strtolower($cardType)) {
            case 'v':
            case 'vi':
            case 'visa':
                $image = 'visa.png';
                break;
            case 'ae':
            case 'a':
            case 'american':
            case 'americanexpress':
                $image = 'american_express.png';
                break;
            case 'mc':
            case 'm':
            case 'master':
            case 'mastercard':
                $image = 'mastercard.png';
                break;
            case 'ds':
            case 'discover':
                $image = 'discover.png';
                break;
            case 'jcb':
                $image = 'jcb.png';
                break;
            case 'savings':
            case 'checking':
            case 'ach':
                $image = 'Icon-Bank-Account.svg';
                break;
            case 'Default':
                $image = 'no-card.png';
                break;
        }

        return $image;
    }

    /**
     * Get card name with card code
     *
     * @param string $cardCode
     * @return string
     */
    public function getCardName($cardCode)
    {
        $cardName = $cardCode;

        switch (strtolower($cardCode)) {
            case 'v':
            case 'vi':
                $cardName = 'Visa';
                break;
            case 'jcb':
                $cardName = 'JCB';
                break;
            case 'ae':
            case 'a':
                $cardName = 'American Express';
                break;
            case 'mc':
            case 'm':
                $cardName = 'Master Card';
                break;
            case 'ds':
                $cardName = 'Discover';
                break;
            case 'ach':
                $cardName = 'ACH';
                break;
        }

        return $cardName;
    }

    /**
     * Get Image tag for card
     * @param string $imageViewUrl
     * @return string
     */
    public function getImageTag($imageViewUrl, $type = 'ach')
    {
        $imageWidth = 'width: 45px';
        $type == 'ach' && $imageWidth = 'width: 25px';

        $alt = 'Payment Card';
        try {
            if (empty(pathinfo($imageViewUrl)['extension'])) {
                return $alt;
            }
        } catch (\Exception $e) {
            return $alt;
        }

        return '<img style="vertical-align: middle; ' . $imageWidth . '" src="' . $imageViewUrl . '" alt="Payment Card" />';
    }
}
