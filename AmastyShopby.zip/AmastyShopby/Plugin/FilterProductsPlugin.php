<?php
/**
 * Re-apply ECC List & Location filtering on Amasty Shopby's custom fulltext collection.
 *
 * This plugin mirrors the logic from Epicor\Common\Plugin\FilterProducts which is registered
 * on Magento\CatalogSearch\Model\ResourceModel\Fulltext\Collection. Since Amasty_Shopby
 * replaces that collection with its own class (not inheriting from the standard one),
 * the ECC plugin never fires. This class bridges that gap.
 *
 * @see \Epicor\Common\Plugin\FilterProducts
 * @see vendor/epicor/module-common/etc/frontend/di.xml
 */

namespace Silk\AmastyShopby\Plugin;

use Amasty\Shopby\Model\ResourceModel\Fulltext\Collection;
use Magento\Bundle\Model\ResourceModel\Selection\Collection as BundleSelectionCollection;

class FilterProductsPlugin
{
    /**
     * @var \Epicor\Comm\Helper\Locations
     */
    private $commLocationsHelper;

    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;

    /**
     * @var \Epicor\Lists\Helper\Frontend\Product
     */
    private $listsFrontendProductHelper;

    /**
     * @var \Epicor\Lists\Helper\Frontend\Contract
     */
    private $listsFrontendContractHelper;

    public function __construct(
        \Epicor\Comm\Helper\Locations $commLocationsHelper,
        \Magento\Framework\Registry $registry,
        \Epicor\Lists\Helper\Frontend\Product $listsFrontendProductHelper,
        \Epicor\Lists\Helper\Frontend\Contract $listsFrontendContractHelper
    ) {
        $this->commLocationsHelper = $commLocationsHelper;
        $this->registry = $registry;
        $this->listsFrontendProductHelper = $listsFrontendProductHelper;
        $this->listsFrontendContractHelper = $listsFrontendContractHelper;
    }

    /**
     * Apply list & location filtering before Amasty collection load.
     *
     * @param Collection $collection
     * @param bool $printQuery
     * @param bool $logQuery
     * @return array
     */
    public function beforeLoad(
        Collection $collection,
        $printQuery = false,
        $logQuery = false
    ) {
        $this->applyLocationFilter($collection);
        $this->applyListFilter($collection);

        return [$printQuery, $logQuery];
    }

    /**
     * Apply list & location filtering before Amasty collection getSize.
     *
     * @param Collection $collection
     * @return array
     */
    public function beforeGetSize(Collection $collection)
    {
        $this->applyLocationFilter($collection);
        $this->applyListFilter($collection);

        return [];
    }

    /**
     * Override to force correct data in pagination when locations enabled.
     *
     * @param Collection $collection
     * @param int $result
     * @return int
     */
    public function afterGetSize(Collection $collection, $result)
    {
        if (!$this->commLocationsHelper->isLocationsEnabled()
            || $collection->getFlag('no_product_filtering')
            || $collection->getFlag('no_location_filtering')
        ) {
            return $result;
        }

        if ($this->registry->registry('Epicor_Locations_Paging')) {
            return $this->registry->registry('Epicor_Locations_Paging');
        }

        return $result;
    }

    /**
     * Apply location filtering if locations is enabled.
     *
     * @param Collection $collection
     * @return void
     */
    private function applyLocationFilter(Collection $collection)
    {
        if (!$this->commLocationsHelper->isLocationsEnabled()
            || $collection->getFlag('no_product_filtering')
            || $collection instanceof BundleSelectionCollection
            || $collection->getFlag('no_location_filtering')
            || $collection->getFlag('location_sql_applied')
        ) {
            return;
        }

        $locationString = $this->commLocationsHelper->getCustomerDisplayLocationCodes();
        if (!$this->commLocationsHelper->isLocationRequireForConfigurable()) {
            $locationString[] = 'NULL';
        }

        $collection->addFieldToFilter(
            \Epicor\Elasticsearch\Model\Adapter\BatchDataMapper\LocationFieldsProvider::ECC_LOCATION_CODE_FIELD_NAME,
            $locationString
        );

        $collection->setFlag('location_sql_applied', true);
        $this->registry->unregister('location_sql_applied');
        $this->registry->register('location_sql_applied', true);
    }

    /**
     * Apply list filtering if lists is enabled.
     *
     * @param Collection $collection
     * @return void
     */
    private function applyListFilter(Collection $collection)
    {
        if ($this->listsFrontendProductHelper->listsDisabled()
            || $collection->getFlag('no_product_filtering')
            || $collection instanceof BundleSelectionCollection
            || $collection->getFlag('lists_sql_applied')
        ) {
            return;
        }

        if ($this->listsFrontendProductHelper->hasFilterableLists()
            || $this->listsFrontendContractHelper->mustFilterByContract()
        ) {
            $productIds = $this->listsFrontendProductHelper->getActiveListsProductIds(true);
            // Elasticsearch filter
            $collection->addFieldToFilter('list_id', $productIds);
            // SQL fallback filter
            if (count($productIds) > 0) {
                $productIdsStr = implode(',', $productIds);
                $collection->getSelect()->where(
                    '(e.entity_id IN(' . $productIdsStr . '))'
                );
            }

            $collection->setFlag('lists_sql_applied', true);
        }
    }
}
