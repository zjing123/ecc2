<?php
/**
 * Silk_AmastyShopby module - Compatibility bridge between Amasty Shopby and Epicor ECC Lists.
 *
 * Amasty_Shopby replaces the standard Magento fulltext collection with its own implementation
 * that does NOT inherit from Magento\CatalogSearch\Model\ResourceModel\Fulltext\Collection.
 * This causes ECC's FilterProducts plugin (registered on the standard collection) to never
 * execute on Amasty's collection, breaking ECC Lists product filtering (Predefined Lists, etc.).
 *
 * This module registers the equivalent filtering plugin on Amasty's collection class.
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Silk_AmastyShopby',
    __DIR__
);
