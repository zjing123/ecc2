<?php
/**
 * Copyright © Silk. All rights reserved.
 */

declare(strict_types=1);

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Silk_AmastyGdpr',
    __DIR__
);
