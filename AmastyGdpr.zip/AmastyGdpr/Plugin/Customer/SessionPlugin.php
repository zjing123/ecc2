<?php
/**
 * Copyright © Silk. All rights reserved.
 */

declare(strict_types=1);

namespace Silk\AmastyGdpr\Plugin\Customer;

use Amasty\Gdpr\Model\Anonymization\AbstractType;
use Magento\Customer\Model\Session;
use Magento\Framework\Validator\EmailAddress;

/**
 * Plugin to check for anonymized customers and force logout.
 *
 * This replaces the original Amasty\Gdpr\Observer\Customer\SessionInit observer
 * to avoid circular dependency issues that occur when the observer runs during
 * session construction (customer_session_init event).
 *
 * The circular dependency chain was:
 * Epicor\Comm\Helper\Customer\Address
 *   -> Epicor\Common\Helper\ContextFactory
 *     -> Epicor\Common\Helper\Context
 *       -> Magento\Customer\Model\Address
 *         -> Epicor\Comm\Model\Customer\Address (preference)
 *           -> Magento\Customer\Model\SessionFactory
 *             -> Magento\Customer\Model\Session
 *               -> __construct() triggers customer_session_init
 *                 -> Amasty\Gdpr\Observer\Customer\SessionInit
 *
 * By using a plugin on getCustomer() instead, we delay the check until
 * the session is fully initialized.
 */
class SessionPlugin
{
    /**
     * @var EmailAddress
     */
    private $emailValidator;

    /**
     * @var bool
     */
    private $anonymousCheckDone = false;

    /**
     * @param EmailAddress $emailValidator
     */
    public function __construct(EmailAddress $emailValidator)
    {
        $this->emailValidator = $emailValidator;
    }

    /**
     * Check for anonymized customer after getCustomer() is called.
     *
     * @param Session $subject
     * @param \Magento\Customer\Model\Customer $result
     * @return \Magento\Customer\Model\Customer
     */
    public function afterGetCustomer(Session $subject, $result)
    {
        // Only check once per request to avoid repeated processing
        if (!$this->anonymousCheckDone && $subject->isLoggedIn()) {
            $this->anonymousCheckDone = true;
            $email = $result->getEmail();

            if ($this->emailValidator->isValid($email)) {
                $emailWithoutDomain = explode('@', $email)[0];

                if ($emailWithoutDomain === AbstractType::ANONYMOUS_SYMBOL) {
                    $subject->setCustomerId(null);
                    $subject->destroy(['clear_storage' => false]);
                }
            }
        }

        return $result;
    }
}
