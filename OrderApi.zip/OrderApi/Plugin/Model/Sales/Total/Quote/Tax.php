<?php
namespace SilkAppleApi\OrderApi\Plugin\Model\Sales\Total\Quote;

class Tax{
            public function afterCollect(
                        \Magento\Tax\Model\Sales\Total\Quote\Tax $obj,
                        $result,
                        \Magento\Quote\Model\Quote $quote,
                        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
                        \Magento\Quote\Model\Quote\Address\Total $total
            ){
                        file_put_contents(BP . "/var/log/ipad_app_api_debug.log", "come in...". PHP_EOL, FILE_APPEND);
                        $total->setTaxAmount(0);
                        $total->setBaseTaxAmount(0);
                        return $result;
            }
}