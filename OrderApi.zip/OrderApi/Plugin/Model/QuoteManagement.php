<?php
namespace SilkAppleApi\OrderApi\Plugin\Model;

class QuoteManagement{
            protected $commMessageRequestMsqFactory;
            protected $productCollectionFactory;
            
            public function __construct(
                        \Epicor\Comm\Model\Message\Request\MsqFactory $commMessageRequestMsqFactory,
                        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
            ){
                        $this->commMessageRequestMsqFactory = $commMessageRequestMsqFactory;
                        $this->productCollectionFactory = $productCollectionFactory;
            }

            public function afterGetCartForCustomer(\Magento\Quote\Model\QuoteManagement $quoteManagement,$quote){
                        $msq = $this->commMessageRequestMsqFactory->create();
                        $msq->setTrigger('API call');
                        $msq->setCustomerGroupId($quote->getEccErpAccountId());
                        $items = $quote->getAllItems();
            
                        $collection = $this->productCollectionFactory->create();
                        $skuList = array();
                        $result = array();
                        $priceList = array();
                        foreach ($items as $item){
                                    $skuList[] = $item->getSku();
                        }
                        $collection ->addFieldToSelect('*'); 
                        $collection ->addAttributeToFilter('sku', ['in' => $skuList]);
                        foreach ($collection->getItems() as $product) {
                                    $msq->addProduct($product, 1);
                        }
                        $msq->sendMessage();

                        foreach ($collection->getItems() as $product) {
                                    $priceList[$product->getSku()] = $product->getPrice();
                        }
                        foreach($quote->getAllItems() as $item){
                                    if(isset($priceList[$item->getSku()])){
                                                $item->setData('price',$priceList[$item->getSku()]);
                                    }
                        }
                        return $quote;
            }
}