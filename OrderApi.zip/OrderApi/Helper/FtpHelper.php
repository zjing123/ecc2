<?php
namespace SilkAppleApi\OrderApi\Helper;

use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;
use Psr\Log\LoggerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Exception\NoSuchEntityException;


class FtpHelper extends \Magento\Framework\App\Helper\AbstractHelper
{
    
    protected $scopeConfig;

    const P21_ENABLE = 'ftp/p21_config/p21_enable';
    const P21_IP = 'ftp/p21_config/p21_ip_address';
    const P21_PORT = 'ftp/p21_config/p21_port';
    const P21_USER = 'ftp/p21_config/p21_username';
    const P21_PASSWORD = 'ftp/p21_config/p21_password';

    public function __construct(
        
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        
        $this->scopeConfig = $scopeConfig;
        
    }

    
    public function saveFile($localPath,$remotePath)
    {

        $ftp_server = $this->scopeConfig->getValue(
            self::P21_IP,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        $ftp_port = $this->scopeConfig->getValue(
            self::P21_PORT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            
        $ftp_user_name = $this->scopeConfig->getValue(
            self::P21_USER,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        $ftp_user_pass = $this->scopeConfig->getValue(
            self::P21_PASSWORD,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        
        
        

        // set up basic connection
        $conn_id = ftp_connect($ftp_server);
        // login with username and password

        $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
        
        // upload a file
        ftp_pasv($conn_id, true);
        ftp_chdir($conn_id, '/');

        if (ftp_put($conn_id, $remotePath, $localPath, FTP_BINARY )) {
            file_put_contents(BP."/var/log/ipad_app_api_debug.log", "successfully uploaded" . $remotePath. PHP_EOL, FILE_APPEND);
            exit;
        } else {
            file_put_contents(BP."/var/log/ipad_app_api_debug.log", "There was a problem while uploading". $remotePath . PHP_EOL, FILE_APPEND); 
            exit;
            }
        // close the connection
        ftp_close($conn_id);
    }

    public function isEnabled()
    {
        file_put_contents(BP."/var/log/ipad_app_api_debug.log", $this->scopeConfig->getValue(
            self::P21_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        ) . PHP_EOL, FILE_APPEND);
        return (boolean)$this->scopeConfig->getValue(
            self::P21_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
