<?php
/**
 * Get Account Shipment List - CUSS Message Wrapper
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Model\Message\Request;

/**
 * CUSS (Customer Shipment Search) Message Request
 */
class GetAccountShipmentList extends \Epicor\Customerconnect\Model\Message\Request
{
    /**
     * @var string
     */
    protected $apiAccountNumbers;

    /**
     * @var string
     */
    protected $email;

    /**
     * Initialize message type
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setMessageType('CUSS');
        $this->setConfigBase('customerconnect_enabled_messages/CUSS_request/');
        $this->setResultsPath('shipments/shipment');
    }

    /**
     * Build request message
     *
     * @return bool|string
     */
    public function buildRequest()
    {
        if ($this->getAccountNumber()) {
            $maxResults = $this->getMaxResults() ?: $this->getConfig('max_results_value');
            $rangeMin = $this->getRangeMin() ?: $this->getConfig('range_min_value');
            $this->mergeSearches();

            $results = [
                'maxResults' => $maxResults,
                'rangeMin' => $rangeMin,
                'searches' => $this->_mergedSearches
            ];

            $this->addDisplayOption('results', $results);
            $this->addDisplayOption('accountNumber', $this->apiAccountNumbers);
            $this->addDisplayOption('languageCode', $this->getLanguageCode());

            if ($this->getIsCurrency()) {
                $currencies = [];
                if (count($this->_currencies) > 0) {
                    $currencies['currency'] = $this->_currencies;
                }
                $this->addDisplayOption('currencies', $currencies);
            }

            $data = $this->getMessageTemplate();
            $data['messages']['request']['body'] = array_merge(
                $data['messages']['request']['body'],
                $this->_displayData
            );

            $this->setOutXml($data);
            return true;
        } else {
            return 'Missing account number';
        }
    }

    /**
     * Process response message
     *
     * @return bool
     */
    public function processResponse()
    {
        if ($this->getIsSuccessful()) {
            $this->setResults(
                $this->getResponse()->getVarienDataArrayFromPath($this->getResultsPath())
            );
            return true;
        } else {
            return false;
        }
    }

    /**
     * Set API account number
     *
     * @param string $accountNumber
     * @return string
     */
    public function setApiAccounNumber($accountNumber)
    {
        return $this->apiAccountNumbers = $accountNumber;
    }

    /**
     * Set message subjects
     *
     * @return void
     */
    protected function setMessageSubjects()
    {
        if (!$this->getMessageSubject()) {
            $this->setMessageSubject($this->email);
        }
        if (!$this->getMessageSecondarySubject()) {
            $this->setMessageSecondarySubject($this->email);
        }
    }

    /**
     * Set request email
     *
     * @param string $email
     * @return string
     */
    public function getRequestEmail($email)
    {
        return $this->email = $email;
    }
}
