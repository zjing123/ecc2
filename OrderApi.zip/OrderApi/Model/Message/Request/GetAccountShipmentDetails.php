<?php
/**
 * Get Account Shipment Details - CUSD Message Wrapper
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Model\Message\Request;

/**
 * CUSD (Customer Shipment Details) Message Request
 */
class GetAccountShipmentDetails extends \Epicor\Customerconnect\Model\Message\Request
{
    /**
     * @var string
     */
    protected $shipmentNumber;

    /**
     * @var string
     */
    protected $orderNumber;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var string
     */
    protected $apiAccountNumbers;

    /**
     * Initialize message type
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setMessageType('CUSD');
        $this->setConfigBase('customerconnect_enabled_messages/CUSD_request/');
        $this->setResultsPath('shipment');
        $this->setIsOrder('true');
        $this->setIsShipment('true');
    }

    /**
     * Build request message
     *
     * @return bool|string
     */
    public function buildRequest()
    {
        if ($this->getAccountNumber()) {
            $this->addDisplayOption('accountNumber', $this->apiAccountNumbers);
            $this->addSecondaryAccountNumbers();

            if ($this->getIsOrder()) {
                $this->addDisplayOption('orderNumber', $this->orderNumber);
            }
            if ($this->getIsShipment()) {
                $this->addDisplayOption('shipmentNumber', $this->shipmentNumber);
            }

            $this->addDisplayOption('languageCode', $this->getLanguageCode());

            if ($this->getIsCurrency()) {
                $currencies = ['currency' => $this->_currencies];
                $this->addDisplayOption('currencies', $currencies);
            }

            $data = $this->getMessageTemplate();
            $data['messages']['request']['body'] = array_merge(
                $data['messages']['request']['body'],
                $this->_displayData
            );

            $this->setOutXml($data);
            return true;
        } else {
            return 'Missing account number';
        }
    }

    /**
     * Set API shipment number
     *
     * @param string $shipmentNumber
     * @return string
     */
    public function setApiShipmentNumber($shipmentNumber)
    {
        return $this->shipmentNumber = $shipmentNumber;
    }

    /**
     * Set API order number
     *
     * @param string $orderNumber
     * @return string
     */
    public function setApiOrderNumber($orderNumber)
    {
        return $this->orderNumber = $orderNumber;
    }

    /**
     * Set API account number
     *
     * @param string $accountNumber
     * @return string
     */
    public function setApiAccounNumber($accountNumber)
    {
        return $this->apiAccountNumbers = $accountNumber;
    }

    /**
     * Set message subjects
     *
     * @return void
     */
    protected function setMessageSubjects()
    {
        if (!$this->getMessageSubject()) {
            $this->setMessageSubject($this->email);
        }
        if (!$this->getMessageSecondarySubject()) {
            $this->setMessageSecondarySubject($this->email);
        }
    }

    /**
     * Set request email
     *
     * @param string $email
     * @return string
     */
    public function getRequestEmail($email)
    {
        return $this->email = $email;
    }
}
