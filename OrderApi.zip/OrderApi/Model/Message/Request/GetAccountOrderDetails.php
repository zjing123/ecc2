<?php
/**
 * User: jerry
 * Date: 2021/8/3
 * Time: 16:31
 */

namespace SilkAppleApi\OrderApi\Model\Message\Request;


class GetAccountOrderDetails extends \Epicor\Customerconnect\Model\Message\Request
{
    protected $orderNumber;

    protected $email;

    protected $apiAccountNumbers;

    protected function _construct()
    {
        parent::_construct();
        $this->setMessageType('CUOD');
        $this->setConfigBase('customerconnect_enabled_messages/CUOD_request/');
        $this->setResultsPath('order');
        $this->setIsOrder('true');
        $this->setLicenseType(array('Customer', 'Consumer'));
    }

    public function buildRequest(){
        if ($this->getAccountNumber()) {
            $this->addDisplayOption('accountNumber', $this->apiAccountNumbers);         // account number
            $this->addSecondaryAccountNumbers();
            if ($this->getIsOrder()) {                                                    // order number
                $this->addDisplayOption('orderNumber', $this->orderNumber);
            }
            if ($this->getIsShipment()) {                                                 // shipment
                $this->addDisplayOption('shipmentNumber', $this->getShipmentNumber());
            }
            if ($this->getIsInvoice()) {                                                  // invoice
                $this->addDisplayOption('invoiceNumber', $this->getInvoiceNumber());
                $this->addDisplayOption('type', $this->getType());
            }

            $this->addDisplayOption('languageCode', $this->getLanguageCode());

            if ($this->getIsCurrency()) {                                                 // currency code
                $currencies = array(
                    'currency' => $this->_currencies
                );
                $this->addDisplayOption('currencies', $currencies);
            }
            if ($this->getIsContact()) {
                $contacts = $this->_contacts;
                $this->addDisplayOption('contacts', $contacts);
            }
            if ($this->getIsDeliveryAvailability()) {
                $this->addDisplayOption('delivery', $this->_deliveryDetails);
            }

            $data = $this->getMessageTemplate();
            $data['messages']['request']['body'] = array_merge($data['messages']['request']['body'], $this->_displayData);

            $this->setOutXml($data);
            return true;
        } else {
            return 'Missing account number';
        }
    }

    public function setApiOrderNumber($orderNumber){
        return $this->orderNumber = $orderNumber;
    }

    protected function setMessageSubjects(){
        if (!$this->getMessageSubject()) {
            $this->setMessageSubject($this->email);
        }
        if (!$this->getMessageSecondarySubject()) {
            $this->setMessageSecondarySubject($this->email);
        }
    }

    public function setApiAccounNumber($accountNumber){
        return $this->apiAccountNumbers = $accountNumber;
    }


    public function getRequestEmail($email){
        return $this->email = $email;
    }
}