<?php
/**
 * User: jerry
 * Date: 2021/7/30
 * Time: 11:35
 */

namespace SilkAppleApi\OrderApi\Model\Message\Request;


class GetAccountOrderList extends \Epicor\Customerconnect\Model\Message\Request
{
    protected $apiAccountNumbers;

    protected $email;

    protected function _construct()
    {
        parent::_construct();
        $this->setMessageType('CUOS');
        $this->setConfigBase('customerconnect_enabled_messages/CUOS_request/');
        $this->setResultsPath('orders/order');
        $this->setIsCurrency(true);
    }

    public function buildRequest()
    {
        if ($this->getAccountNumber()) {
            $maxResults = $this->getMaxResults() ?: $this->getConfig('max_results_value');
            $rangeMin = $this->getRangeMin() ?: $this->getConfig('range_min_value');
            $this->mergeSearches();
            $results = array(
                'maxResults' => $maxResults,
                'rangeMin' => $rangeMin,
                'searches' => $this->_mergedSearches
            );
            $this->addDisplayOption('results', $results);

            $this->addDisplayOption('accountNumber', $this->apiAccountNumbers);         // current user account number

            $this->addDisplayOption('languageCode', $this->getLanguageCode());

            if ($this->getIsCurrency()) {                                                 // currency code
                $currencies = array();

                if (count($this->_currencies) > 0)
                    $currencies['currency'] = $this->_currencies;

                $this->addDisplayOption('currencies', $currencies);
            }

            $data = $this->getMessageTemplate();
            $data['messages']['request']['body'] = array_merge($data['messages']['request']['body'], $this->_displayData);

            $this->setOutXml($data);
            return true;
        } else {
            return 'Missing account number';
        }
    }

    public function processResponse()
    {
        if ($this->getIsSuccessful()) {
            // getVarienDataFromPath converts xml into a varien object, which can be referenced from controller
            $this->setResults($this->getResponse()->getVarienDataArrayFromPath($this->getResultsPath()));
            return true;
        } else {
            return false;
        }
    }

    public function setApiAccounNumber($accountNumber){
        return $this->apiAccountNumbers = $accountNumber;
    }

    protected function setMessageSubjects(){
        if (!$this->getMessageSubject()) {
            $this->setMessageSubject($this->email);
        }
        if (!$this->getMessageSecondarySubject()) {
            $this->setMessageSecondarySubject($this->email);
        }
    }

    public function getRequestEmail($email){
        return $this->email = $email;
    }
}