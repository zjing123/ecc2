<?php
/**
 * Get Account Invoice Details - CUID Message Wrapper
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Model\Message\Request;

class GetAccountInvoiceDetails extends \Epicor\Customerconnect\Model\Message\Request
{
    /**
     * @var string
     */
    protected $apiAccountNumbers;

    /**
     * @var string
     */
    protected $invoiceNumber;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var string|null
     */
    protected $attributeType;

    /**
     * Initialize message
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setMessageType('CUID');
        $this->setConfigBase('customerconnect_enabled_messages/CUID_request/');
        $this->setResultsPath('invoice');
        $this->setIsInvoice('true');
    }

    /**
     * Build request data
     *
     * @return bool|string
     */
    public function buildRequest()
    {
        if ($this->getAccountNumber()) {
            $this->addDisplayOption('accountNumber', $this->apiAccountNumbers);
            $this->addSecondaryAccountNumbers();

            if ($this->getIsInvoice()) {
                $this->addDisplayOption('invoiceNumber', $this->invoiceNumber);
                if ($this->attributeType) {
                    $this->addDisplayOption('type', $this->attributeType);
                }
            }

            $this->addDisplayOption('languageCode', $this->getLanguageCode());

            if ($this->getIsCurrency()) {
                $currencies = ['currency' => $this->_currencies];
                $this->addDisplayOption('currencies', $currencies);
            }

            $data = $this->getMessageTemplate();
            $data['messages']['request']['body'] = array_merge(
                $data['messages']['request']['body'],
                $this->_displayData
            );

            $this->setOutXml($data);
            return true;
        } else {
            return 'Missing account number';
        }
    }

    /**
     * Set API account number
     *
     * @param string $accountNumber
     * @return string
     */
    public function setApiAccounNumber($accountNumber)
    {
        return $this->apiAccountNumbers = $accountNumber;
    }

    /**
     * Set API invoice number
     *
     * @param string $invoiceNumber
     * @return string
     */
    public function setApiInvoiceNumber($invoiceNumber)
    {
        return $this->invoiceNumber = $invoiceNumber;
    }

    /**
     * Set API attribute type
     *
     * @param string|null $type
     * @return string|null
     */
    public function setApiAttributeType($type)
    {
        return $this->attributeType = $type;
    }

    /**
     * Set message subjects
     *
     * @return void
     */
    protected function setMessageSubjects()
    {
        if (!$this->getMessageSubject()) {
            $this->setMessageSubject($this->email);
        }
        if (!$this->getMessageSecondarySubject()) {
            $this->setMessageSecondarySubject($this->email);
        }
    }

    /**
     * Set request email
     *
     * @param string $email
     * @return string
     */
    public function getRequestEmail($email)
    {
        return $this->email = $email;
    }
}
