<?php
/**
 * Author: jerry, Roy
 * Date: 2021/7/29
 * Time: 16:58
 */

namespace SilkAppleApi\OrderApi\Model;

use Exception;
use SilkAppleApi\OrderApi\Api\OrderInterface;
use Magento\Checkout\Api\PaymentProcessingRateLimiterInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\CouldNotSaveException;
use \Magento\Quote\Api\CartRepositoryInterface;
use SilkAppleApi\OrderApi\Helper\FtpHelper;

class Order extends \Epicor\Customerconnect\Model\Message\Requestsearch implements OrderInterface
{
    /**
     * @var \Epicor\Customerconnect\Model\Message\Request\Cuos
     */
    protected $customerconnectMessageRequestCuos;
    /**
     * @var Message\Request\GetAccountOrderList
     */
    protected $getAccountOrderList;
    /**
     * @var Message\Request\GetAccountOrderDetails
     */
    protected $getAccountOrderDetails;
    /**
     * @var \Epicor\Comm\Model\Product
     */
    protected $_product;
    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    private $cartRepository;

    protected $salesRepResourceAccountCollectionFactory;
    protected $erpHelperData;
    protected $salesRepAccountFactory;
    protected $customer;
    protected $coreRegistry;
    protected $cache;
    protected $orderEmailSender;
    protected $commSalesOrderHelper;
    protected $request;
    protected $draftOrderEmailSender;

    protected $billingAddressManagement;
    protected $paymentMethodManagement;
    protected $cartManagement;
    protected $paymentDetailsFactory;
    protected $cartTotalsRepository;
    protected $paymentRateLimiter;
    protected $orderFactory;
    protected $ftp;
    protected $commMessagingHelper;
    protected $commCustomerErpaccountAddressFactory;
    protected $sendBsvHelperFactory;
    protected $orderConfirmEmailSender;
    /**
     * Order constructor.
     * @param \Epicor\Comm\Model\Product $product
     * @param Message\Request\GetAccountOrderList $getAccountOrderList
     * @param Message\Request\GetAccountOrderDetails $getAccountOrderDetails
     * @param \Epicor\Customerconnect\Model\Message\Request\Cuos $customerconnectMessageRequestCuos
     * @param \Magento\Quote\Api\BillingAddressManagementInterface $billingAddressManagement
     * @param \Magento\Quote\Api\PaymentMethodManagementInterface $paymentMethodManagement
     * @param \Magento\Quote\Api\CartManagementInterface $cartManagement
     * @param PaymentDetailsFactory $paymentDetailsFactory
     * @param \Magento\Quote\Api\CartTotalRepositoryInterface $cartTotalsRepository
     * @param PaymentProcessingRateLimiterInterface|null $paymentRateLimiter
     * @codeCoverageIgnore
     */
    public function __construct(
        \Epicor\Comm\Model\Product $product,
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountOrderList $getAccountOrderList,
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountOrderDetails $getAccountOrderDetails,
        \Epicor\Customerconnect\Model\Message\Request\Cuos $customerconnectMessageRequestCuos,
        \Magento\Quote\Api\BillingAddressManagementInterface $billingAddressManagement,
        \Magento\Quote\Api\PaymentMethodManagementInterface $paymentMethodManagement,
        \Magento\Quote\Api\CartManagementInterface $cartManagement,
        \Magento\Checkout\Model\PaymentDetailsFactory $paymentDetailsFactory,
        \Magento\Quote\Api\CartTotalRepositoryInterface $cartTotalsRepository,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Epicor\SalesRep\Model\ResourceModel\Account\CollectionFactory $salesRepResourceAccountCollectionFactory,
        \Epicor\Comm\Helper\Data $erpHelperData,
        \SilkAppleApi\OrderApi\Helper\FtpHelper $ftp,
        \Epicor\Comm\Model\Context $context,
        \Epicor\SalesRep\Model\AccountFactory $salesRepAccountFactory,
        \Magento\Customer\Model\CustomerFactory $customer,
        \Epicor\Comm\Model\Customer\Erpaccount\AddressFactory $commCustomerErpaccountAddressFactory,
        \Epicor\Comm\Helper\Cart\SendbsvFactory $sendBsvHelperFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\App\CacheInterface $cache,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderEmailSender,
        \Epicor\Comm\Helper\Sales\Order $commSalesOrderHelper,
        \SilkAppleApi\DraftOrder\Helper\Sender $draftOrderEmailSender,
        \SilkAppleApi\OrderConfirmEmail\Helper\Sender $orderConfirmEmailSender,
        ?PaymentProcessingRateLimiterInterface $paymentRateLimiter = null
    ){
        $this->_product = $product;
        $this->getAccountOrderDetails = $getAccountOrderDetails;
        $this->getAccountOrderList = $getAccountOrderList;
        $this->customerconnectMessageRequestCuos = $customerconnectMessageRequestCuos;
        $this->billingAddressManagement = $billingAddressManagement;
        $this->paymentMethodManagement = $paymentMethodManagement;
        $this->cartManagement = $cartManagement;
        $this->paymentDetailsFactory = $paymentDetailsFactory;
        $this->cartTotalsRepository = $cartTotalsRepository;
        $this->paymentRateLimiter = $paymentRateLimiter
            ?? ObjectManager::getInstance()->get(PaymentProcessingRateLimiterInterface::class);
        $this->orderFactory = $orderFactory;
        $this->erpHelperData = $erpHelperData;
        $this->salesRepResourceAccountCollectionFactory = $salesRepResourceAccountCollectionFactory;
        $this->ftp = $ftp;
        $this->commMessagingHelper = $context->getCommMessagingHelper();
        $this->salesRepAccountFactory = $salesRepAccountFactory;
        $this->customer = $customer;
        $this->commCustomerErpaccountAddressFactory = $commCustomerErpaccountAddressFactory;
        $this->sendBsvHelperFactory = $sendBsvHelperFactory;
        $this->coreRegistry = $coreRegistry;
        $this->cache = $cache;
        $this->orderEmailSender = $orderEmailSender;
        $this->commSalesOrderHelper = $commSalesOrderHelper;
        $this->request = $commSalesOrderHelper->getRequest();
        $this->draftOrderEmailSender = $draftOrderEmailSender;
        $this->orderConfirmEmailSender = $orderConfirmEmailSender;
    }

    /**
     * @param string $accountNumber
     * @param string $email
     * @return bool|mixed|void
     */
    public function getAccountOrderList($accountNumber,$email){
	    header('Content-Type:application/json; charset=utf-8');
        $cuos = $this->customerconnectMessageRequestCuos;
        $cuosString = $cuos->getHelper()->getMessageType('CUOS');
        if($cuos->isActive() && $cuosString){
            $this->getAccountOrderList->setApiAccounNumber($accountNumber);
	    $this->getAccountOrderList->getRequestEmail($email);
            $data = $this->getAccountOrderList->sendMessage();
            if($data){
                $receivedString = $this->getAccountOrderList->getReceivedXml();
                $ob= simplexml_load_string($receivedString,'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);
                $orderList = $configData['response']['body'];
                $orders['order'] =[];
                if(isset($orderList['orders']['order'])) {
                    foreach ($orderList['orders']['order'] as $order) {
                        if (isset($order['customerReference'])) {
                            if (is_array($order['customerReference']) && count($order['customerReference']) < 1) {
                                $order['customerReference'] = '';
                            }
                        } else {
                            $order['customerReference'] = '';
                        }
                        if (isset($order['orderAddress']['address2']) && is_array($order['orderAddress']['address2']) && count($order['orderAddress']['address2']) < 1) {
                            $order['orderAddress']['address2'] = '';
                        }
                        $orders['order'][] = $order;
                    }
                }

                if($orderList['status']['code']==200){
                    $responseArray = ['success' =>$orderList['status']['code'],'message' =>'Successfully retrived the Account order List','data'=>$orders];
                }else{
                    $responseArray = ['success' =>$orderList['status']['code'],'message' =>$orderList['status']['description'],'data'=>$orders];
                }
            }else{
                $responseArray = ['fail' =>400,'message' =>'Can\'t find the order',null];
            }
        }
        exit(json_encode($responseArray));
    }

    /**
     * @param string $accountNumber
     * @param string $orderNumber
     * @param string $email
     * @return array|mixed|void
     */
    public function getAccountOrderDetails($accountNumber,$orderNumber,$email){
	    file_put_contents(BP."/var/log/ipad_app_api_debug.log", $accountNumber ."  ". $orderNumber."  ". $email.  PHP_EOL, FILE_APPEND);
        header('Content-Type:application/json; charset=utf-8');
        $this->getAccountOrderDetails->setApiAccounNumber($accountNumber);
        $this->getAccountOrderDetails->setApiOrderNumber($orderNumber);
        $this->getAccountOrderDetails->getRequestEmail($email);
        $date = $this->getAccountOrderDetails->sendMessage();
        if($date){
            $receivedString = $this->getAccountOrderDetails->getReceivedXml();
            $ob= simplexml_load_string($receivedString,'SimpleXMLElement', LIBXML_NOCDATA);
            $json = json_encode($ob);
            $configData = json_decode($json, true);
            $orderList = $configData['response']['body'];
            if($orderList['status']['code']==200){
                if(isset($orderList['order']['lines']['line']['productCode'])){
                        $lines = [];
                        $productSku = $orderList['order']['lines']['line']['productCode'];
                        $productId = $this->_product->getIdBySku($productSku);
                        $product = $this->_product->load($productId);
                        $imageUrl = $product->getMediaConfig()->getMediaUrl($product->getImage());
                        $orderList['order']['lines']['line']['imageUrl'] = $imageUrl;
                        $lines[] = $orderList['order']['lines']['line'];
                        $orderList['order']['lines']['line'] = $lines;
                }else{
                    if(isset($orderList['order']['lines']['line'])) {
                        foreach ($orderList['order']['lines']['line'] as $key => $value) {
                            $productSku = $value['productCode'];
                            $productId = $this->_product->getIdBySku($productSku);
                            $product = $this->_product->load($productId);
                            $imageUrl = $product->getMediaConfig()->getMediaUrl($product->getImage());
                            $orderList['order']['lines']['line'][$key]['imageUrl'] = $imageUrl;
                        }
                    }
                }

                $responseArray = ['success' =>$orderList['status']['code'],'message' =>$orderList['status']['description'],'data'=>$orderList['order']];
            }else{
                $responseArray = ['success' =>$orderList['status']['code'],'message' =>$orderList['status']['description'],'data'=>$orderList['order']];
            }
        }else{
            $responseArray= ['fail' =>400,'message' =>'Can\'t find the order',null];
        }
        exit(json_encode($responseArray));
    }

    /**
     * @inheritdoc
     */
    public function savePaymentInformationAndPlaceOrder(
        $cartId,
        \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
        \Magento\Quote\Api\Data\AddressInterface $billingAddress = null,
        $note,
        $isQuote,
        $isApproved,
        $salesrep_newaddress,
        $order_source='REP'
    ) {
        $lockKey = 'place_order_lock_'.$cartId;
        if($this->cache->load($lockKey)){
            $responseArray= ['fail' =>500,'message' =>'The order is being processed, please do not submit again',null];
            exit(json_encode($responseArray));
        }
        try {
            $this->cache->save('pedding',$lockKey);
            if ($billingAddress) {$billingAddress->setCustomerAddressId(null);}
            $this->savePaymentInformation($cartId, $paymentMethod, $billingAddress, $note, $isQuote, $isApproved);

            $poNum = $paymentMethod->getPoNumber();
		    $orderId = $this->cartManagement->placeOrder($cartId);

            $orderModel = $this->orderFactory->create();
            $order = $orderModel->load($orderId);
            $customerNum = $order->getCustomerId();
            $customerObj = $this->customer->create()->load($customerNum);
            $salesRepAccount = $this->salesRepAccountFactory->create()->load($customerObj->getEccSalesRepAccountId());
            $salesRepId = $salesRepAccount->getSalesRepId();
            $addressId = explode("_",$salesrep_newaddress);
            $shipToId = end($addressId);

            //ecc_erp_account_address

            // Shipto ID must be from the frontend
            $order->setEccGorSent(5);
            $order->setEccGorMessage('Order Created.');
            $order->save();

            $delivery_method = $this->commMessagingHelper->create()->getShippingMethodMapping($order->getShippingMethod());
            $info = $this->erpHelperData->getErpAccountInfo($order->getEccErpAccountId());

            $customerId = $info->getAccountNumber();
            $company =  $order->getShippingAddress()->getLastName();
            $orderId = $order->getIncrementId();

            $erpAddress = $this->commCustomerErpaccountAddressFactory->create()->load($shipToId);
            $shipToId = $erpAddress->getErpCode();
            $shipToId = preg_replace('/[^0-9.]+/', '', $shipToId);

            $shipToName = $order->getShippingAddress()->getCompany();
            $shipStreet = $order->getShippingAddress()->getStreet()[0] ?? '';
            $shipStreet2 = $order->getShippingAddress()->getStreet()[1] ?? '';
            $shipCity = $order->getShippingAddress()->getCity();
            $shipState = $order->getShippingAddress()->getRegionCode();
            $shipPostcode = $order->getShippingAddress()->getPostcode();
            $shipCountry = $order->getShippingAddress()->getCountryId();

            $filePath = BP."/var/orders/order_".$order->getIncrementId().".csv";
            $arr = array("customerID","customer","orderID","customer_po",
                         "salesRepID","shipToID","shipToName","ship_street",
                         "ship_street2","ship_city","ship_state","ship_postcode",
                         "ship_country","ship_method","packaging_basis",
                         "sku","qty","unit_price","orderIsApproved","isQuote","Order Notes","Order Source");

            $fp = fopen($filePath,'w');
            fputcsv($fp,$arr);
            $items = $order->getItemsCollection();
            if($order_source == 'iPhone'){
                $order_source = 'B2B';
            }else{
                $order_source = 'REP';
            }
            foreach ($items as $item){
                $price = $item->getPrice();
                if ($price < 0.01) {
                    $price = 0;
                }
                fputcsv($fp,array(
                                  $customerId,
                                  $company,
                                  $orderId,
                                  $poNum,
                                  $salesRepId,
                                  $shipToId,
                                  $shipToName,
                                  $shipStreet,
                                  $shipStreet2,
                                  $shipCity,
                                  $shipState,
                                  $shipPostcode,
                                  $shipCountry,
                                  $delivery_method,
                                  "Confirmed",
                                  $item->getSku(),
                                  $item->getQtyOrdered(),
                                  $price,
                                  $isApproved ? "True" : "False",
                                  $isQuote ? "True" : "False",
                                  $note,
                                  $order_source
                                 ));
            }

            fclose($fp);
            if((boolean)!$this->ftp->isEnabled()) {
                $this->ftp->saveFile($filePath,"order_".$order->getIncrementId().".csv");
            }

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            file_put_contents(BP . "/var/log/ipad_app_api_debug.log", " savePaymentInformationAndPlaceOrder log:::::: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
            $this->getLogger()->critical(
                'Placing an order with quote_id ' . $cartId . ' is failed: ' . $e->getMessage()
	);
            throw new CouldNotSaveException(
                __($e->getMessage()),
                $e
            );
        } catch (\Exception $e) {
            file_put_contents(BP . "/var/log/ipad_app_api_debug.log", " savePaymentInformationAndPlaceOrder log:::::: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
            $this->getLogger()->critical($e);
            throw new CouldNotSaveException(
                __('A server error stopped your order from being placed. Please try to place your order again.'),
                $e
            );
        }finally{
            $this->cache->save('',$lockKey);
        }
        return $orderId;
    }

        /**
     * @inheritdoc
     */
    public function savePaymentInformation(
        $cartId,
        \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
        \Magento\Quote\Api\Data\AddressInterface $billingAddress = null,
        $note,
        $isQuote,
        $isApproved
    ) {
        try{
            $this->paymentRateLimiter->limit();

            if ($billingAddress) {
                /** @var \Magento\Quote\Api\CartRepositoryInterface $quoteRepository */
                $quoteRepository = $this->getCartRepository();
                /** @var \Magento\Quote\Model\Quote $quote */
                $quote = $quoteRepository->getActive($cartId);
                $customerId = $quote->getBillingAddress()
                    ->getCustomerId();
                if (!$billingAddress->getCustomerId() && $customerId) {
                    //It's necessary to verify the price rules with the customer data
                    $billingAddress->setCustomerId($customerId);
                }
                $quote->removeAddress($quote->getBillingAddress()->getId());
                $quote->setBillingAddress($billingAddress);
                $quote->setDataChanges(true);

                $quote->setPoNumber($paymentMethod->getPoNumber());
                $quote->setCustomerNote($note);
                $quote->setData("p21_is_quote", $isQuote);
                $quote->setData("p21_is_approved", $isApproved);

                $shippingAddress = $quote->getShippingAddress();
                if ($shippingAddress && $shippingAddress->getShippingMethod()) {
                    $shippingRate = $shippingAddress->getShippingRateByCode($shippingAddress->getShippingMethod());
                    if ($shippingRate) {
                        $shippingAddress->setLimitCarrier($shippingRate->getCarrier());
                    }
                }
            }
            $this->paymentMethodManagement->set($cartId, $paymentMethod);
            return true;
        }catch(Exception $e){
            file_put_contents(BP . "/var/log/ipad_app_api_debug.log", " savePaymentInformation:::::: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
        }

    }

    /**
     * @inheritdoc
     */
    public function getPaymentInformation($cartId)
    {
        /** @var \Magento\Checkout\Api\Data\PaymentDetailsInterface $paymentDetails */
        $paymentDetails = $this->paymentDetailsFactory->create();
        $paymentDetails->setPaymentMethods($this->paymentMethodManagement->getList($cartId));
        $paymentDetails->setTotals($this->cartTotalsRepository->get($cartId));
        return $paymentDetails;
    }

    /**
     * Get logger instance
     *
     * @return \Psr\Log\LoggerInterface
     * @deprecated 100.1.8
     */
    private function getLogger()
    {
        if (!$this->logger) {
            $this->logger = ObjectManager::getInstance()->get(\Psr\Log\LoggerInterface::class);
        }
        return $this->logger;
    }

    /**
     * Get Cart repository
     *
     * @return \Magento\Quote\Api\CartRepositoryInterface
     * @deprecated 100.2.0
     */
    private function getCartRepository()
    {
        if (!$this->cartRepository) {
            $this->cartRepository = ObjectManager::getInstance()
                ->get(\Magento\Quote\Api\CartRepositoryInterface::class);
        }
        return $this->cartRepository;
    }


    /**
     * @param string $cartId
     * @param string $discount
     * @return mixed
     */
    public function setDiscountPercentage($cartId, $discount)
    {

        $quoteRepository = $this->getCartRepository();
        /** @var \Magento\Quote\Model\Quote $quote */
        $quote = $quoteRepository->getActive($cartId);
        $quote->setData("p21_discount_percent",$discount);
        $cartItms = $quote->getAllItems();
        // $connection  = $this->_resource->getConnection();
        // $tableName = $connection->getTableName('quote_item');
        $subtotal = 0;
        foreach ($cartItms as $cartItm) {
            //$quote->getItemById($cartItm['item_id']);
            $subtotal += ($cartItm->getPrice() * $cartItm->getQty());
        }
       $quote->setData("p21_original_price",$subtotal);
        $quote->setData("p21_discount_amount",($subtotal*$discount/100));
        /* @var $helper \Epicor\Comm\Helper\Cart\Sendbsv */
        $helper = $this->sendBsvHelperFactory->create();
        $helper->sendCartBsv($quote, true);
        $quote->collectTotals()->save();
        $responseArray= ['success' =>200,'message' =>'applied discount'];
        exit(json_encode($responseArray));

    }

    /**
     * @return mixed
     */
    public function sendDraftOrderEmail($email,$orderNum,$items,$createdTime){
        $this->draftOrderEmailSender->sendEmail($email,$orderNum,$items,$createdTime);
        exit(json_encode(['code'=>200,'message'=>'successful']));
    }

    public function sendCofirmationEmail($accountNumber,$orderNumber,$email){
        try{
            $this->getAccountOrderDetails->setApiAccounNumber($accountNumber);
            $this->getAccountOrderDetails->setApiOrderNumber($orderNumber);
            $this->getAccountOrderDetails->getRequestEmail($email);
            $date = $this->getAccountOrderDetails->sendMessage();
            if($date){
                $receivedString = $this->getAccountOrderDetails->getReceivedXml();
                $ob= simplexml_load_string($receivedString,'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);
                if($configData['response']['body']['status']['code'] == 200){
                    $orderInfo = $configData['response']['body']['order'];
                    $this->orderConfirmEmailSender->sendEmail($orderInfo,$email);
                    $responseArray= ['success' =>200,'message' =>$configData['response']['body']['status']['description'],null];
                }else{
                    $responseArray= ['fail' =>400,'message' =>$configData['response']['body']['status']['description'],null];
                }
            }else{
                $responseArray= ['fail' =>400,'message' =>'Can\'t find the order',null];
            }
        }catch(\Exception $e){
            $responseArray= ['fail' =>400,'message' =>$e->getMessage(),null];
        }
        exit(json_encode($responseArray));
    }

}
