<?php
/**
 * Shipment API Model
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Model;

use SilkAppleApi\OrderApi\Api\ShipmentInterface;

/**
 * Shipment API Implementation
 */
class Shipment implements ShipmentInterface
{
    /**
     * @var \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentList
     */
    protected $getAccountShipmentList;

    /**
     * @var \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentDetails
     */
    protected $getAccountShipmentDetails;

    /**
     * @var \Epicor\Customerconnect\Model\Message\Request\Cuss
     */
    protected $customerconnectMessageRequestCuss;

    /**
     * @var \Epicor\Customerconnect\Model\Message\Request\Cusd
     */
    protected $customerconnectMessageRequestCusd;

    /**
     * @var \Epicor\Comm\Model\Product
     */
    protected $_product;

    /**
     * Initialize dependencies
     *
     * @param \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentList $getAccountShipmentList
     * @param \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentDetails $getAccountShipmentDetails
     * @param \Epicor\Customerconnect\Model\Message\Request\Cuss $customerconnectMessageRequestCuss
     * @param \Epicor\Customerconnect\Model\Message\Request\Cusd $customerconnectMessageRequestCusd
     * @param \Epicor\Comm\Model\Product $product
     */
    public function __construct(
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentList $getAccountShipmentList,
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountShipmentDetails $getAccountShipmentDetails,
        \Epicor\Customerconnect\Model\Message\Request\Cuss $customerconnectMessageRequestCuss,
        \Epicor\Customerconnect\Model\Message\Request\Cusd $customerconnectMessageRequestCusd,
        \Epicor\Comm\Model\Product $product
    ) {
        $this->getAccountShipmentList = $getAccountShipmentList;
        $this->getAccountShipmentDetails = $getAccountShipmentDetails;
        $this->customerconnectMessageRequestCuss = $customerconnectMessageRequestCuss;
        $this->customerconnectMessageRequestCusd = $customerconnectMessageRequestCusd;
        $this->_product = $product;
    }

    /**
     * Get account shipment list
     *
     * @param string $accountNumber
     * @param string $email
     * @return mixed
     */
    public function getAccountShipmentList($accountNumber, $email)
    {
        header('Content-Type:application/json; charset=utf-8');

        $cuss = $this->customerconnectMessageRequestCuss;
        $cussString = $cuss->getHelper()->getMessageType('CUSS');

        if ($cuss->isActive() && $cussString) {
            $this->getAccountShipmentList->setApiAccounNumber($accountNumber);
            $this->getAccountShipmentList->getRequestEmail($email);
            $data = $this->getAccountShipmentList->sendMessage();

            if ($data) {
                $receivedString = $this->getAccountShipmentList->getReceivedXml();
                $ob = simplexml_load_string($receivedString, 'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);
                $shipmentList = $configData['response']['body'];

                $shipments = ['shipment' => []];
                if (isset($shipmentList['shipments']['shipment'])) {
                    $shipmentsData = $shipmentList['shipments']['shipment'];
                    // Handle single shipment case (not wrapped in array)
                    if (isset($shipmentsData['packingSlip'])) {
                        $shipmentsData = [$shipmentsData];
                    }
                    foreach ($shipmentsData as $shipment) {
                        // Clean empty array fields
                        if (isset($shipment['shipToAddress']['address2']) &&
                            is_array($shipment['shipToAddress']['address2']) &&
                            count($shipment['shipToAddress']['address2']) < 1
                        ) {
                            $shipment['shipToAddress']['address2'] = '';
                        }
                        if (isset($shipment['shipToAddress']['state']) &&
                            is_array($shipment['shipToAddress']['state']) &&
                            count($shipment['shipToAddress']['state']) < 1
                        ) {
                            $shipment['shipToAddress']['state'] = '';
                        }
                        $shipments['shipment'][] = $shipment;
                    }
                }

                if ($shipmentList['status']['code'] == 200) {
                    $responseArray = [
                        'success' => $shipmentList['status']['code'],
                        'message' => 'Successfully retrieved the shipment list',
                        'data' => $shipments
                    ];
                } else {
                    $responseArray = [
                        'success' => $shipmentList['status']['code'],
                        'message' => $shipmentList['status']['description'],
                        'data' => $shipments
                    ];
                }
            } else {
                $responseArray = [
                    'fail' => 400,
                    'message' => 'Cannot find shipments',
                    'data' => null
                ];
            }
        } else {
            $responseArray = [
                'fail' => 400,
                'message' => 'CUSS message not enabled or not available',
                'data' => null
            ];
        }

        exit(json_encode($responseArray));
    }

    /**
     * Get account shipment details
     *
     * @param string $accountNumber
     * @param string $shipmentNumber
     * @param string $orderNumber
     * @param string $email
     * @return mixed
     */
    public function getAccountShipmentDetails($accountNumber, $shipmentNumber, $orderNumber, $email)
    {
        header('Content-Type:application/json; charset=utf-8');

        $cusd = $this->customerconnectMessageRequestCusd;
        $cusdString = $cusd->getHelper()->getMessageType('CUSD');

        if ($cusd->isActive() && $cusdString) {
            $this->getAccountShipmentDetails->setApiAccounNumber($accountNumber);
            $this->getAccountShipmentDetails->setApiShipmentNumber($shipmentNumber);
            $this->getAccountShipmentDetails->setApiOrderNumber($orderNumber);
            $this->getAccountShipmentDetails->getRequestEmail($email);

            $data = $this->getAccountShipmentDetails->sendMessage();

            if ($data) {
                $receivedString = $this->getAccountShipmentDetails->getReceivedXml();
                $ob = simplexml_load_string($receivedString, 'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);
                $shipmentData = $configData['response']['body'];

                if ($shipmentData['status']['code'] == 200) {
                    // Process line items and add product images
                    $shipment = $shipmentData['shipment'] ?? [];
                    if (isset($shipment['lines']['line'])) {
                        $shipment['lines']['line'] = $this->enrichLineItemsWithImages(
                            $shipment['lines']['line']
                        );
                    }

                    $responseArray = [
                        'success' => $shipmentData['status']['code'],
                        'message' => $shipmentData['status']['description'],
                        'data' => $shipment
                    ];
                } else {
                    $responseArray = [
                        'success' => $shipmentData['status']['code'],
                        'message' => $shipmentData['status']['description'],
                        'data' => isset($shipmentData['shipment']) ? $shipmentData['shipment'] : null
                    ];
                }
            } else {
                $responseArray = [
                    'fail' => 400,
                    'message' => 'Cannot find shipment details',
                    'data' => null
                ];
            }
        } else {
            $responseArray = [
                'fail' => 400,
                'message' => 'CUSD message not enabled or not available',
                'data' => null
            ];
        }

        exit(json_encode($responseArray));
    }

    /**
     * Enrich line items with product images
     *
     * @param array $lines
     * @return array
     */
    protected function enrichLineItemsWithImages($lines)
    {
        // Handle single line item case
        if (isset($lines['productCode'])) {
            $lines = [$lines];
            $singleLine = true;
        } else {
            $singleLine = false;
        }

        foreach ($lines as $key => $line) {
            if (isset($line['productCode'])) {
                $productSku = $line['productCode'];
                $productId = $this->_product->getIdBySku($productSku);
                if ($productId) {
                    $product = $this->_product->load($productId);
                    $imageUrl = $product->getMediaConfig()->getMediaUrl($product->getImage());
                    $lines[$key]['imageUrl'] = $imageUrl;
                } else {
                    $lines[$key]['imageUrl'] = '';
                }
            }
        }

        return $lines;
    }
}
