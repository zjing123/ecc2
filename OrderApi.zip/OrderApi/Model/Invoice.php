<?php
/**
 * Invoice API Model
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Model;

use SilkAppleApi\OrderApi\Api\InvoiceInterface;

/**
 * Invoice API Implementation
 */
class Invoice implements InvoiceInterface
{
    /**
     * @var \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceList
     */
    protected $getAccountInvoiceList;

    /**
     * @var \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceDetails
     */
    protected $getAccountInvoiceDetails;

    /**
     * @var \Epicor\Customerconnect\Model\Message\Request\Cuis
     */
    protected $customerconnectMessageRequestCuis;

    /**
     * @var \Epicor\Customerconnect\Model\Message\Request\Cuid
     */
    protected $customerconnectMessageRequestCuid;

    /**
     * Initialize dependencies
     *
     * @param \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceList $getAccountInvoiceList
     * @param \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceDetails $getAccountInvoiceDetails
     * @param \Epicor\Customerconnect\Model\Message\Request\Cuis $customerconnectMessageRequestCuis
     * @param \Epicor\Customerconnect\Model\Message\Request\Cuid $customerconnectMessageRequestCuid
     */
    public function __construct(
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceList $getAccountInvoiceList,
        \SilkAppleApi\OrderApi\Model\Message\Request\GetAccountInvoiceDetails $getAccountInvoiceDetails,
        \Epicor\Customerconnect\Model\Message\Request\Cuis $customerconnectMessageRequestCuis,
        \Epicor\Customerconnect\Model\Message\Request\Cuid $customerconnectMessageRequestCuid
    ) {
        $this->getAccountInvoiceList = $getAccountInvoiceList;
        $this->getAccountInvoiceDetails = $getAccountInvoiceDetails;
        $this->customerconnectMessageRequestCuis = $customerconnectMessageRequestCuis;
        $this->customerconnectMessageRequestCuid = $customerconnectMessageRequestCuid;
    }

    /**
     * Get account invoice list
     *
     * @param string $accountNumber
     * @param string $email
     * @return mixed
     */
    public function getAccountInvoiceList($accountNumber, $email)
    {
        header('Content-Type:application/json; charset=utf-8');

        $cuis = $this->customerconnectMessageRequestCuis;
        $cuisString = $cuis->getHelper()->getMessageType('CUIS');

        if ($cuis->isActive() && $cuisString) {
            $this->getAccountInvoiceList->setApiAccounNumber($accountNumber);
            $this->getAccountInvoiceList->getRequestEmail($email);

            $data = $this->getAccountInvoiceList->sendMessage();

            if ($data) {
                $receivedString = $this->getAccountInvoiceList->getReceivedXml();
                $ob = simplexml_load_string($receivedString, 'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);

                $invoiceList = $configData['response']['body'];
                $invoices = ['invoice' => []];

                if (isset($invoiceList['invoices']['invoice'])) {
                    $invoiceData = $invoiceList['invoices']['invoice'];
                    // Handle single invoice case (not wrapped in array)
                    if (isset($invoiceData['invoiceNumber'])) {
                        $invoiceData = [$invoiceData];
                    }
                    foreach ($invoiceData as $invoice) {
                        if (isset($invoice['reference']) && is_array($invoice['reference']) && count($invoice['reference']) < 1) {
                            $invoice['reference'] = '';
                        }
                        $invoices['invoice'][] = $invoice;
                    }
                }

                if ($invoiceList['status']['code'] == 200) {
                    $responseArray = [
                        'success' => $invoiceList['status']['code'],
                        'message' => 'Successfully retrieved the invoice list',
                        'data' => $invoices
                    ];
                } else {
                    $responseArray = [
                        'success' => $invoiceList['status']['code'],
                        'message' => $invoiceList['status']['description'],
                        'data' => $invoices
                    ];
                }
            } else {
                $responseArray = [
                    'fail' => 400,
                    'message' => 'Cannot find invoices',
                    'data' => null
                ];
            }
        } else {
            $responseArray = [
                'fail' => 400,
                'message' => 'CUIS message not enabled or not available',
                'data' => null
            ];
        }

        exit(json_encode($responseArray));
    }

    /**
     * Get account invoice details
     *
     * @param string $accountNumber
     * @param string $invoiceNumber
     * @param string $email
     * @param string|null $attributeType
     * @return mixed
     */
    public function getAccountInvoiceDetails($accountNumber, $invoiceNumber, $email, $attributeType = null)
    {
        header('Content-Type:application/json; charset=utf-8');

        $cuid = $this->customerconnectMessageRequestCuid;
        $cuidString = $cuid->getHelper()->getMessageType('CUID');

        if ($cuid->isActive() && $cuidString) {
            $this->getAccountInvoiceDetails->setApiAccounNumber($accountNumber);
            $this->getAccountInvoiceDetails->setApiInvoiceNumber($invoiceNumber);
            $this->getAccountInvoiceDetails->getRequestEmail($email);

            if ($attributeType) {
                $this->getAccountInvoiceDetails->setApiAttributeType($attributeType);
            }

            $data = $this->getAccountInvoiceDetails->sendMessage();

            if ($data) {
                $receivedString = $this->getAccountInvoiceDetails->getReceivedXml();
                $ob = simplexml_load_string($receivedString, 'SimpleXMLElement', LIBXML_NOCDATA);
                $json = json_encode($ob);
                $configData = json_decode($json, true);

                $invoiceData = $configData['response']['body'];

                if ($invoiceData['status']['code'] == 200) {
                    $responseArray = [
                        'success' => $invoiceData['status']['code'],
                        'message' => $invoiceData['status']['description'],
                        'data' => $invoiceData['invoice']
                    ];
                } else {
                    $responseArray = [
                        'success' => $invoiceData['status']['code'],
                        'message' => $invoiceData['status']['description'],
                        'data' => isset($invoiceData['invoice']) ? $invoiceData['invoice'] : null
                    ];
                }
            } else {
                $responseArray = [
                    'fail' => 400,
                    'message' => 'Cannot find invoice details',
                    'data' => null
                ];
            }
        } else {
            $responseArray = [
                'fail' => 400,
                'message' => 'CUID message not enabled or not available',
                'data' => null
            ];
        }

        exit(json_encode($responseArray));
    }
}
