<?php
/**
 * Shipment API Interface
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Api;

/**
 * Interface for shipment API operations
 * @api
 */
interface ShipmentInterface
{
    /**
     * Get customer shipment list
     *
     * @param string $accountNumber ERP account number
     * @param string $email Customer email
     * @return mixed
     */
    public function getAccountShipmentList($accountNumber, $email);

    /**
     * Get shipment details
     *
     * @param string $accountNumber ERP account number
     * @param string $shipmentNumber Shipment number
     * @param string $orderNumber Order number
     * @param string $email Customer email
     * @return mixed
     */
    public function getAccountShipmentDetails($accountNumber, $shipmentNumber, $orderNumber, $email);
}
