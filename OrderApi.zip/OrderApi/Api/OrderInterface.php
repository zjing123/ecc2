<?php
/**
 * User: jerry
 * Date: 2021/7/29
 * Time: 16:56
 */

namespace SilkAppleApi\OrderApi\Api;


interface OrderInterface
{
    /**
     * @param string $accountNumber
     * @param string $email
     * @return bool|mixed|void
     */
    public function getAccountOrderList($accountNumber,$email);
    /**
     * @param string $accountNumber
     * @param string $orderNumber
     * @param string $email
     * @return array|mixed|void
     */
    public function getAccountOrderDetails($accountNumber,$orderNumber,$email);

    /**
     * Set payment information and place order for a specified cart.
     *
     * @param int $cartId
     * @param \Magento\Quote\Api\Data\PaymentInterface $paymentMethod
     * @param \Magento\Quote\Api\Data\AddressInterface|null $billingAddress
     * @param string $note
     * @param int $isQuote
     * @param int $isApproved
     * @param string $salesrep_newaddress
     * @param string $order_source
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return int Order ID.
     */
    public function savePaymentInformationAndPlaceOrder(
        $cartId,
        \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
        \Magento\Quote\Api\Data\AddressInterface $billingAddress = null,
        $note,
        $isQuote,
        $isApproved,
        $salesrep_newaddress,
        $order_source='REP'
    );

    /**
     * Set payment information for a specified cart.
     *
     * @param int $cartId
     * @param \Magento\Quote\Api\Data\PaymentInterface $paymentMethod
     * @param \Magento\Quote\Api\Data\AddressInterface|null $billingAddress
     * @param string $note
     * @param int $isQuote
     * @param int $isApproved
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return int Order ID.
     */
    public function savePaymentInformation(
        $cartId,
        \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
        \Magento\Quote\Api\Data\AddressInterface $billingAddress = null,
        $note,
        $isQuote,
        $isApproved
    );

    /**
     * Get payment information
     *
     * @param int $cartId
     * @return \Magento\Checkout\Api\Data\PaymentDetailsInterface
     */
    public function getPaymentInformation($cartId);


    /**
     * Get payment information
     *
     * @param int $cartId
     * @param int $discount
     * @return mixed
     */
    public function setDiscountPercentage($cartId, $discount);

    /**
     * send draft order email
     *
     * @param string $email
     * @param string $orderNum
     * @param mixed $items
     * @param string $createdTime
     * @return mixed
     */
    public function sendDraftOrderEmail($email,$orderNum,$items,$createdTime);

    /**
     * send cofirmation email
     *
     * @param string $accountNumber
     * @param string $orderNumber
     * @param string $email
     * @return mixed
     */
    public function sendCofirmationEmail($accountNumber,$orderNumber,$email);
}
