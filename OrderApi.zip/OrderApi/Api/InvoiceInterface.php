<?php
/**
 * Invoice API Interface
 *
 * @category  SilkAppleApi
 * @package   SilkAppleApi_OrderApi
 */
namespace SilkAppleApi\OrderApi\Api;

/**
 * Interface for invoice API operations
 * @api
 */
interface InvoiceInterface
{
    /**
     * Get customer invoice list
     *
     * @param string $accountNumber ERP account number
     * @param string $email Customer email
     * @return mixed
     */
    public function getAccountInvoiceList($accountNumber, $email);

    /**
     * Get invoice details
     *
     * @param string $accountNumber ERP account number
     * @param string $invoiceNumber Invoice number
     * @param string $email Customer email
     * @param string|null $attributeType Optional attribute type
     * @return mixed
     */
    public function getAccountInvoiceDetails($accountNumber, $invoiceNumber, $email, $attributeType = null);
}
