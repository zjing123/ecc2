<?php
/**
 * Copyright © 2010-2018 Epicor Software Corporation: All Rights Reserved
 */
namespace SilkAppleApi\OrderApi\Observer\Bsv;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class UpdateDiscountPrices extends AbstractObserver implements ObserverInterface
{
    /**
     * @param Observer $observer
     * @throws \Exception
     */
    public function execute(Observer $observer)
    {
        /* @var $salesRepHelper \Epicor\SalesRep\Helper\Data */
        $salesRepHelper = $this->salesRepHelper;

        // if (!$salesRepHelper->isEnabled()) {
        //     return;
        // }

        $isSalesRep = $this->customerSession->getCustomer()->isSalesRep();

        // if ($isSalesRep == false) {
        //     return;
        // }

        /* @var $bsv \Epicor\Comm\Model\Message\Request\Bsv */
        $bsv = $observer->getEvent()->getMessage();
        $data = $bsv->getMessageArray();
        $quote = $bsv->getQuote();
        $discount = $quote->getData("p21_discount_percent");

        /* @var $helper \Epicor\SalesRep\Helper\Pricing\Rule\Product */
        $helper = $this->salesRepPricingRuleProductHelper;

        if (isset($data['messages']['request']['body']['lines']['line']) && is_array($data['messages']['request']['body']['lines']['line'])) {
            $bGoodstotal = 0;
            $bGoodstotalInc = 0;
            $totalsRecalculation = false;
            foreach ($data['messages']['request']['body']['lines']['line'] as &$line) {
                $itemId = $line['_attributes']['itemId'];
                $item = $bsv->getLineItem($itemId);
                if ($item) {
                    $quantity = $line['quantity'];

                    $totalsRecalculation = true;
                    //Get Item Product Prices & Qty
                    $origPrice = !is_null($item->getEccOriginalPrice()) ? $item->getEccOriginalPrice() : $item->getBasePrice();
                    $salesrepItemPrice = $item->getEccOriginalPrice() - $item->getEccOriginalPrice() * ($discount / 100);

                    $update = false;
                    $product = $item->getProduct();
                    $product->setEwaSku($item->getOptionByType('ewa_sku'));
                    $product->setEccMsqBasePrice($item->getEccMsqBasePrice());
                    $rulePrice = $helper->getRuleBasePrice($product, $origPrice, $quantity);
                    $minPrice = $helper->getMinPrice($product, $origPrice, $quantity);

                    $salesrepItemPriceInc = $item->getPriceInclTax() - $item->getPrice() * ($discount / 100);
                    
                    $salesrepLineTotal = $salesrepItemPrice * $quantity;
                    
                    $itemOrigData = $item->getOrigData();
                    $itemData = $item->getData();
                    if ((isset($itemData['qty']) && isset($itemOrigData['qty']) && $itemData['qty'] != $itemOrigData['qty']) || ($salesrepItemPrice != $origPrice)) {
                        $salesrepItemPriceInc = $salesrepItemPrice;
                        $salesrepLineTotalInc = $salesrepLineTotal;
                    } else {
                        $salesrepLineTotalInc = $salesrepItemPriceInc * $quantity;
                    }
                    if ($discount == 100) {
                        $itemDiscount = $origPrice;
                        $lineDiscount = ($itemDiscount * $quantity);
                        $line['price'] = 0.0001;
                        $line['priceInc'] = 0.0001;
                        $line['lineValue'] = 0.0001;
                        $line['lineValueInc'] = 0.0001;
                        $line['lineDiscount'] = $lineDiscount;
                        $line['_attributes']['preventRepricing'] = "N";

                        $salesrepItemPriceInc = 0.0001;
                        $salesrepLineTotal = 0.0001;
                        $bGoodstotal = 0.0001;
                        $bGoodstotalInc = 0.0001;
                        
                    } else {
                        $itemDiscount = ($origPrice - $salesrepItemPrice);
                        $lineDiscount = ($itemDiscount * $quantity);
                        $line['price'] = $salesrepItemPrice;
                        $line['priceInc'] = $salesrepItemPriceInc;
                        $line['lineValue'] = $salesrepLineTotal;
                        $line['lineValueInc'] = $salesrepLineTotalInc;
                        $line['lineDiscount'] = $lineDiscount;
                        $line['_attributes']['preventRepricing'] = "N";

                        $salesrepItemPriceInc = $item->getPriceInclTax() - $item->getPrice() * ($discount / 100);
                        $salesrepLineTotal = ($salesrepItemPrice * $quantity);
                        $bGoodstotal += $salesrepLineTotal;
                        $bGoodstotalInc += $salesrepLineTotalInc;
                    }
                }
            }

            if ($totalsRecalculation) {
                $data = $this->setUpdateTotal($data, $bGoodstotal, $bGoodstotalInc);
            }
        }
        file_put_contents(BP . "/var/log/ipad_app_api_debug.log", json_encode($data) . PHP_EOL, FILE_APPEND);
        $bsv->setMessageArray($data);
    }

    /**
     * @param $data
     * @param $bGoodstotal
     * @param $bGoodstotalInc
     * @return mixed
     */
    private function setUpdateTotal($data, $bGoodstotal, $bGoodstotalInc)
    {
        $charge = $data['messages']['request']['body']['order']['carriageAmount'];
        $chargeInc = $data['messages']['request']['body']['order']['carriageAmountInc'];
        $calculateDiscount = $data['messages']['request']['body']['order']['discountAmount'];
        file_put_contents(BP . "/var/log/ipad_app_api_debug.log", $charge . PHP_EOL, FILE_APPEND);
        file_put_contents(BP . "/var/log/ipad_app_api_debug.log", $chargeInc . PHP_EOL, FILE_APPEND);
        file_put_contents(BP . "/var/log/ipad_app_api_debug.log", $calculateDiscount . PHP_EOL, FILE_APPEND);
        $bgrandTotal = $bGoodstotal + $charge - $calculateDiscount;
        $bgrandTotalInc = $bGoodstotalInc + $chargeInc - $calculateDiscount;

        $data['messages']['request']['body']['order']['goodsTotal'] = $bGoodstotal ?: 0;
        $data['messages']['request']['body']['order']['goodsTotalInc'] = $bGoodstotalInc ?: 0;
        $data['messages']['request']['body']['order']['grandTotal'] = $this->checkValueDataType($bgrandTotal);
        $data['messages']['request']['body']['order']['grandTotalInc'] = $this->checkValueDataType($bgrandTotalInc);

        return $data;
    }

    /**
     * Convert array value from Integer to String
     *
     * @param null $value
     * @return string|null
     */
    private function checkValueDataType($value = null)
    {
        if ($value == null || $value == 0) {
            return '0';
        } else {
            return $value;
        }
    }
}
