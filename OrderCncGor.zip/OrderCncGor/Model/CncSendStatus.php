<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Model;

/**
 * CNC Send Status constants
 */
class CncSendStatus
{
    /**
     * CNC not sent yet (new customer)
     */
    public const PENDING = 0;

    /**
     * CNC sent successfully
     */
    public const SENT = 1;

    /**
     * Get status label
     *
     * @param int $status
     * @return string
     */
    public static function getLabel(int $status): string
    {
        return [
            self::PENDING => 'Pending',
            self::SENT => 'Sent',
        ][$status] ?? 'Unknown';
    }
}
