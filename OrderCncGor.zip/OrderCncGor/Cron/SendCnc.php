<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Cron;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Sales\Api\OrderRepositoryInterface;
use Psr\Log\LoggerInterface;
use Silk\OrderCncGor\Model\CncSendStatus;
use Silk\OrderCncGor\Service\CncSender;

/**
 * Cron job to send CNC for new customers
 * Processes orders with ecc_cnc_send_status = 0
 */
class SendCnc
{
    private OrderRepositoryInterface $orderRepository;
    private SearchCriteriaBuilder $searchCriteriaBuilder;
    private DateTime $dateTime;
    private CncSender $cncSender;
    private ResourceConnection $resourceConnection;
    private LoggerInterface $logger;

    /**
     * Maximum customers to process per cron run
     */
    private const MAX_CUSTOMERS_PER_RUN = 100;

    public function __construct(
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        DateTime $dateTime,
        CncSender $cncSender,
        ResourceConnection $resourceConnection,
        LoggerInterface $logger
    ) {
        $this->orderRepository = $orderRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->dateTime = $dateTime;
        $this->cncSender = $cncSender;
        $this->resourceConnection = $resourceConnection;
        $this->logger = $logger;
    }

    /**
     * Execute cron job
     *
     * @return void
     */
    public function execute(): void
    {
        $this->logger->info('CNC Cron: Starting execution');

        // Get customers with pending orders directly from database
        $customersToProcess = $this->getPendingCustomerIds();

        if (empty($customersToProcess)) {
            $this->logger->info('CNC Cron: No pending customers found');
            return;
        }

        $this->logger->info(sprintf('CNC Cron: Found %d customers to process', count($customersToProcess)));

        // Process each customer
        foreach ($customersToProcess as $customerId => $email) {
            $this->processCustomer((int) $customerId, $email);
        }

        $this->logger->info('CNC Cron: Execution completed');
    }

    /**
     * Get customer IDs with pending CNC orders directly from database
     * Groups by customer_id and limits to MAX_CUSTOMERS_PER_RUN
     *
     * @return array [customer_id => email]
     */
    private function getPendingCustomerIds(): array
    {
        $connection = $this->resourceConnection->getConnection();
        $tableName = $this->resourceConnection->getTableName('sales_order');

        // Query: get unique customer_ids with pending CNC status
        // Limit to MAX_CUSTOMERS_PER_RUN to avoid processing too many at once
        $select = $connection->select()
            ->from(
                $tableName,
                ['customer_id', 'customer_email']
            )
            ->where('ecc_cnc_send_status = ?', CncSendStatus::PENDING)
            ->where('customer_id IS NOT NULL')
            ->group('customer_id')
            ->order('entity_id ASC') // Process oldest orders first
            ->limit(self::MAX_CUSTOMERS_PER_RUN);

        return $connection->fetchPairs($select);
    }

    /**
     * Process single customer - send CNC and update orders
     *
     * @param int $customerId
     * @param string $email
     * @return void
     */
    private function processCustomer(int $customerId, string $email): void
    {
        $this->logger->info(sprintf('CNC Cron: Processing customer %d (%s)', $customerId, $email));

        try {
            // Send CNC using the service
            $status = $this->cncSender->sendForCustomer($customerId);

            switch ($status) {
                case CncSender::RESULT_SUCCESS:
                    $this->logger->info(sprintf('CNC Cron: CNC sent successfully for customer %d', $customerId));
                    $this->updateCustomerOrdersToSent($customerId);
                    break;

                case CncSender::RESULT_SKIPPED:
                    $this->logger->info(sprintf('CNC Cron: Customer %d already has ERP account, marking orders as sent', $customerId));
                    $this->updateCustomerOrdersToSent($customerId);
                    break;

                case CncSender::RESULT_FAILED:
                    $this->logger->error(sprintf('CNC Cron: CNC failed for customer %d', $customerId));
                    // TODO: Implement retry logic with max retry count
                    break;
            }

        } catch (\Exception $e) {
            $this->logger->critical(sprintf('CNC Cron: Exception processing customer %d: %s', $customerId, $e->getMessage()));
        }
    }

    /**
     * Update all customer orders to SENT status and enable GOR
     *
     * @param int $customerId
     * @return void
     */
    private function updateCustomerOrdersToSent(int $customerId): void
    {
        $connection = $this->resourceConnection->getConnection();
        $tableName = $this->resourceConnection->getTableName('sales_order');

        // Direct SQL update for better performance
        // Only update orders that were blocked by our observer (ecc_gor_sent = NEVER_SEND)
        $where = [
            'customer_id = ?' => $customerId,
            'ecc_cnc_send_status = ?' => CncSendStatus::PENDING,
            'ecc_gor_sent = ?' => \Epicor\Comm\Model\Message\Request\Gor::GOR_STATUS_NEVER_SEND
        ];

        $data = [
            'ecc_cnc_send_status' => CncSendStatus::SENT,
            'ecc_gor_sent' => \Epicor\Comm\Model\Message\Request\Gor::GOR_STATUS_NOT_SENT,
            'ecc_cnc_processed_at' => $this->dateTime->gmtDate()
        ];

        $affectedRows = $connection->update($tableName, $data, $where);

        $this->logger->info(sprintf('CNC Cron: Updated %d orders for customer %d to SENT', $affectedRows, $customerId));
    }
}
