<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Observer;

use Epicor\Comm\Model\Message\Request\Gor;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Silk\OrderCncGor\Model\CncSendStatus;

/**
 * Check customer ERP account on order placement
 * Sets CNC status to block default GOR for new customers
 *
 * Observes: sales_model_service_quote_submit_before
 * This event fires before the order is saved, so we only set data attributes.
 * The order will be saved automatically by the orderManagement->place() call.
 *
 */
class CheckCustomerCncStatus implements ObserverInterface
{
    private CustomerRepositoryInterface $customerRepository;
    private LoggerInterface $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    public function execute(Observer $observer): void
    {
        $this->logger->info('=== CheckCustomerCncStatus Observer triggered ===');

        $order = $observer->getEvent()->getOrder();

        if (!$order) {
            $this->logger->warning('No order found in event');
            return;
        }

        $this->logger->info(sprintf('Order ID: %s, Increment ID: %s', $order->getId(), $order->getIncrementId()));

        // Skip if already has CNC status set
        if ($order->getData('ecc_cnc_send_status') !== null) {
            $this->logger->info(sprintf('Order already has CNC status: %s', $order->getData('ecc_cnc_send_status')));
            return;
        }

        // Try to get customer from order
        $customer = $this->getCustomerFromOrder($order);

        // Handle guest orders - no ERP account needed
        if (!$customer) {
            $this->logger->info('Guest order detected - setting CNC status to PENDING and blocking GOR');
            $order->setData('ecc_cnc_send_status', CncSendStatus::PENDING);
            $order->setData('ecc_gor_sent', Gor::GOR_STATUS_NEVER_SEND);

            return;
        }

        $this->logger->info(sprintf('Handling customer order for: %s (ID: %d)', $customer->getEmail(), $customer->getId()));
        $this->handleCustomerOrder($order, $customer);
    }

    /**
     * Get customer from order by customerId or customerEmail
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @return \Magento\Customer\Api\Data\CustomerInterface|null
     */
    private function getCustomerFromOrder($order): ?\Magento\Customer\Api\Data\CustomerInterface
    {
        // First try by customerId
        $customerId = $order->getCustomerId();
        if ($customerId) {
            try {
                return $this->customerRepository->getById((int) $customerId);
            } catch (\Exception $e) {
                $this->logger->warning(sprintf('Customer ID %d not found, trying by email', $customerId));
            }
        }

        // Then try by customerEmail
        $customerEmail = $order->getCustomerEmail();
        if ($customerEmail) {
            try {
                return $this->customerRepository->get($customerEmail);
            } catch (\Exception $e) {
                $this->logger->warning(sprintf('Customer with email %s not found', $customerEmail));
            }
        }

        return null;
    }

    /**
     * Handle registered customer order
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @param \Magento\Customer\Api\Data\CustomerInterface $customer
     * @return void
     */
    private function handleCustomerOrder($order, $customer): void
    {
        try {
            // Check if customer has ERP account (CNC already sent)
            $erpAccountId = $customer->getCustomAttribute('ecc_erpaccount_id');
            if ($erpAccountId && $erpAccountId->getValue()) {
                // Customer already has ERP account, no CNC needed
                $this->logger->info(sprintf('Customer %s already has ERP account ID: %s - setting CNC status to SENT',
                    $customer->getEmail(),
                    $erpAccountId->getValue()
                ));
                $order->setData('ecc_cnc_send_status', CncSendStatus::SENT);
                return;
            }

            $this->logger->info(sprintf('Customer %s has no ERP account - needs CNC', $customer->getEmail()));
        } catch (\Exception $e) {
            $this->logger->error(sprintf('Order CNC check error: %s', $e->getMessage()));
        }

        // New customer: needs CNC before GOR
        $order->setData('ecc_cnc_send_status', CncSendStatus::PENDING);
        $order->setData('ecc_gor_sent', Gor::GOR_STATUS_NEVER_SEND);

        $this->logger->info(
            sprintf('NEW CUSTOMER ORDER: %s (ID: %d) - CNC status=PENDING, GOR blocked',
                $customer->getEmail(),
                $customer->getId()
            )
        );
    }
}
