<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Observer;

use Epicor\Comm\Model\Message\Request\Gor;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\ResourceModel\Order as OrderResource;
use Psr\Log\LoggerInterface;
use Silk\OrderCncGor\Model\CncSendStatus;

/**
 * Check customer ERP account on order placement
 * Sets CNC status to block default GOR for new customers
 */
class CheckCustomerCncStatus implements ObserverInterface
{
    private CustomerRepositoryInterface $customerRepository;
    private OrderResource $orderResource;
    private LoggerInterface $logger;
    private array $processedOrders = [];

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        OrderResource $orderResource,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->orderResource = $orderResource;
        $this->logger = $logger;
    }

    public function execute(Observer $observer): void
    {
        $order = $observer->getEvent()->getOrder();

        if (!$order || !$order->getEntityId()) {
            return;
        }

        $orderId = (int) $order->getEntityId();

        // Avoid duplicate processing
        if (isset($this->processedOrders[$orderId])) {
            return;
        }

        $this->processedOrders[$orderId] = true;

        // Skip if already has CNC status set (should not happen on new orders)
        if ($order->getData('ecc_cnc_send_status') !== null) {
            return;
        }

        // Check if GOR is active
        $gor = $order->getGor();
        if ($gor && !$gor->isActive()) {
            return;
        }

        // Handle guest orders - no ERP account needed
        $customerId = $order->getCustomerId();
        if (!$customerId) {
            $order->setData('ecc_cnc_send_status', CncSendStatus::SENT);
            $this->orderResource->saveAttribute($order, 'ecc_cnc_send_status');
            $this->logger->info(sprintf('Guest order %d: CNC status set to SENT', $orderId));
            return;
        }

        $this->handleCustomerOrder($order, (int) $customerId);
    }

    /**
     * Handle registered customer order
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @param int $customerId
     * @return void
     */
    private function handleCustomerOrder($order, int $customerId): void
    {
        $orderId = $order->getEntityId();

        try {
            $customer = $this->customerRepository->getById($customerId);

            // Check if customer has ERP account (CNC already sent)
            $erpAccountId = $customer->getCustomAttribute('ecc_erpaccount_id');
            if ($erpAccountId && $erpAccountId->getValue()) {
                // Customer already has ERP account, no CNC needed
                $order->setData('ecc_cnc_send_status', CncSendStatus::SENT);
                $this->orderResource->saveAttribute($order, 'ecc_cnc_send_status');
                $this->logger->info(sprintf('Order %d: Customer has ERP account, CNC status=SENT', $orderId));
                return;
            }

            // New customer: needs CNC before GOR
            $order->setData('ecc_cnc_send_status', CncSendStatus::PENDING);
            $order->setData('ecc_gor_sent', Gor::GOR_STATUS_NEVER_SEND); // Block default GOR
            $this->orderResource->saveAttribute($order, 'ecc_cnc_send_status');
            $this->orderResource->saveAttribute($order, 'ecc_gor_sent');

            $this->logger->info(sprintf('Order %d: New customer, CNC status=PENDING, GOR blocked', $orderId));

        } catch (\Exception $e) {
            $this->logger->error(sprintf('Order %d error: %s', $orderId, $e->getMessage()));
            // On error, allow normal flow to avoid blocking the order
            $order->setData('ecc_cnc_send_status', CncSendStatus::SENT);
            $this->orderResource->saveAttribute($order, 'ecc_cnc_send_status');
        }
    }
}
