<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Observer;

use Epicor\Comm\Model\Message\Request\Gor;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Silk\OrderCncGor\Model\CncSendStatus;

/**
 * Check customer ERP account on order placement
 * Sets CNC status to block default GOR for new customers
 *
 * Observes: sales_model_service_quote_submit_before
 * This event fires before the order is saved, so we only set data attributes.
 * The order will be saved automatically by the orderManagement->place() call.
 *
 */
class CheckCustomerCncStatus implements ObserverInterface
{
    private CustomerRepositoryInterface $customerRepository;
    private LoggerInterface $logger;

    public function __construct(
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    public function execute(Observer $observer): void
    {
        $order = $observer->getEvent()->getOrder();

        if (!$order) {
            return;
        }

        // Skip if already has CNC status set
        if ($order->getData('ecc_cnc_send_status') !== null) {
            return;
        }

        // Try to get customer from order
        $customer = $this->getCustomerFromOrder($order);

        // Handle guest orders - no ERP account needed
        if (!$customer) {
            $order->setData('ecc_cnc_send_status', CncSendStatus::PENDING);
            $order->setData('ecc_gor_sent', Gor::GOR_STATUS_NEVER_SEND);

            return;
        }

        $this->handleCustomerOrder($order, $customer);
    }

    /**
     * Get customer from order by customerId or customerEmail
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @return \Magento\Customer\Api\Data\CustomerInterface|null
     */
    private function getCustomerFromOrder($order): ?\Magento\Customer\Api\Data\CustomerInterface
    {
        // First try by customerId
        $customerId = $order->getCustomerId();
        if ($customerId) {
            try {
                return $this->customerRepository->getById((int) $customerId);
            } catch (\Exception $e) {
                $this->logger->warning(sprintf('Customer ID %d not found, trying by email', $customerId));
            }
        }

        // Then try by customerEmail
        $customerEmail = $order->getCustomerEmail();
        if ($customerEmail) {
            try {
                return $this->customerRepository->get($customerEmail);
            } catch (\Exception $e) {
                $this->logger->warning(sprintf('Customer with email %s not found', $customerEmail));
            }
        }

        return null;
    }

    /**
     * Handle registered customer order
     *
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @param \Magento\Customer\Api\Data\CustomerInterface $customer
     * @return void
     */
    private function handleCustomerOrder($order, $customer): void
    {
        try {
            // Check if customer has ERP account (CNC already sent)
            $erpAccountId = $customer->getCustomAttribute('ecc_erpaccount_id');
            if ($erpAccountId && $erpAccountId->getValue()) {
                // Customer already has ERP account, no CNC needed
                $order->setData('ecc_cnc_send_status', CncSendStatus::SENT);
                return;
            }
        } catch (\Exception $e) {
            $this->logger->error(sprintf('Order CNC check error: %s', $e->getMessage()));
        }

        // New customer: needs CNC before GOR
        $order->setData('ecc_cnc_send_status', CncSendStatus::PENDING);
        $order->setData('ecc_gor_sent', Gor::GOR_STATUS_NEVER_SEND);

        $this->logger->info(
            sprintf('Order: New customer %s (%d), CNC status=PENDING, GOR blocked', $customer->getEmail(), $customer->getId())
        );
    }
}
