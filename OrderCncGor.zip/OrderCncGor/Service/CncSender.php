<?php

declare(strict_types=1);

namespace Silk\OrderCncGor\Service;

use Epicor\Comm\Model\Customer\ErpaccountFactory;
use Epicor\Comm\Model\Message\Request\CncFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterface;
use Psr\Log\LoggerInterface;

/**
 * Service class to send CNC (Create New Customer) messages to ERP
 *
 * @api
 */
class CncSender
{
    private CncFactory $cncFactory;
    private ErpaccountFactory $erpAccountFactory;
    private CustomerRepositoryInterface $customerRepository;
    private LoggerInterface $logger;

    /**
     * CNC sending result status codes
     */
    public const RESULT_SUCCESS = 'success';
    public const RESULT_FAILED = 'failed';
    public const RESULT_SKIPPED = 'skipped';

    public function __construct(
        CncFactory $cncFactory,
        ErpaccountFactory $erpAccountFactory,
        CustomerRepositoryInterface $customerRepository,
        LoggerInterface $logger
    ) {
        $this->cncFactory = $cncFactory;
        $this->erpAccountFactory = $erpAccountFactory;
        $this->customerRepository = $customerRepository;
        $this->logger = $logger;
    }

    /**
     * Send CNC for a customer and link the returned ERP account
     *
     * @param int $customerId
     * @return string One of: RESULT_SUCCESS, RESULT_FAILED, RESULT_SKIPPED
     */
    public function sendForCustomer(int $customerId): string
    {
        try {
            $customer = $this->customerRepository->getById($customerId);

            // Check if customer already has ERP account
            if ($this->customerHasErpAccount($customer)) {
                $erpAccountId = $this->getCustomerErpAccountId($customer);
                $this->logger->info(sprintf('Customer %d already has ERP account %d', $customerId, $erpAccountId));
                return self::RESULT_SKIPPED;
            }

            // Send CNC to ERP
            return $this->sendCncToErp($customer);

        } catch (\Exception $e) {
            $this->logger->error(sprintf('CNC Sender error for customer %d: %s', $customerId, $e->getMessage()));
            return self::RESULT_FAILED;
        }
    }

    /**
     * Check if customer already has an ERP account
     *
     * @param CustomerInterface $customer
     * @return bool
     */
    public function customerHasErpAccount(CustomerInterface $customer): bool
    {
        $erpAccountId = $customer->getCustomAttribute('ecc_erpaccount_id');
        return $erpAccountId && $erpAccountId->getValue();
    }

    /**
     * Get customer ERP account ID
     *
     * @param CustomerInterface $customer
     * @return int|null
     */
    public function getCustomerErpAccountId(CustomerInterface $customer): ?int
    {
        $erpAccountId = $customer->getCustomAttribute('ecc_erpaccount_id');
        if ($erpAccountId && $erpAccountId->getValue()) {
            return (int) $erpAccountId->getValue();
        }
        return null;
    }

    /**
     * Send CNC message to ERP and link the returned ERP account to customer
     *
     * @param CustomerInterface $customer
     * @return string One of: RESULT_SUCCESS, RESULT_FAILED
     */
    private function sendCncToErp(CustomerInterface $customer): string
    {
        try {
            /** @var \Epicor\Comm\Model\Message\Request\Cnc $cnc */
            $cnc = $this->cncFactory->create();

            // Build ERP account from customer data
            $erpAccount = $this->buildErpAccountFromCustomer($customer);
            $cnc->setAccount($erpAccount);

            // Send CNC message
            $success = $cnc->sendMessage();

            if ($success) {
                // Get the returned ERP account from CNC response
                $returnedErpAccount = $cnc->getAccount();
                $erpAccountId = $returnedErpAccount ? $returnedErpAccount->getId() : null;

                if ($erpAccountId) {
                    // Link ERP account to customer
                    $this->linkErpAccountToCustomer($customer, $erpAccountId);

                    $this->logger->info(sprintf(
                        'CNC sent for customer %d, ERP account %d linked successfully',
                        $customer->getId(),
                        $erpAccountId
                    ));

                    return self::RESULT_SUCCESS;
                } else {
                    $this->logger->warning(sprintf(
                        'CNC sent for customer %d but no ERP account ID returned',
                        $customer->getId()
                    ));

                    return self::RESULT_FAILED;
                }
            } else {
                $this->logger->error(sprintf(
                    'CNC failed for customer %d: %s',
                    $customer->getId(),
                    $cnc->getStatusDescription() ?: 'Unknown error'
                ));

                return self::RESULT_FAILED;
            }

        } catch (\Exception $e) {
            $this->logger->error(sprintf(
                'CNC sending exception for customer %d: %s',
                $customer->getId(),
                $e->getMessage()
            ));

            return self::RESULT_FAILED;
        }
    }

    /**
     * Link ERP account to customer
     *
     * @param CustomerInterface $customer
     * @param int $erpAccountId
     * @return void
     */
    private function linkErpAccountToCustomer(CustomerInterface $customer, int $erpAccountId): void
    {
        $customer->setCustomAttribute('ecc_erpaccount_id', $erpAccountId);
        $this->customerRepository->save($customer);

        $this->logger->info(sprintf(
            'Linked ERP account %d to customer %d (%s)',
            $erpAccountId,
            $customer->getId(),
            $customer->getEmail()
        ));
    }

    /**
     * Build ERP account data from customer
     *
     * @param CustomerInterface $customer
     * @return \Epicor\Comm\Model\Customer\Erpaccount
     */
    private function buildErpAccountFromCustomer(CustomerInterface $customer)
    {
        /** @var \Epicor\Comm\Model\Customer\Erpaccount $erpAccount */
        $erpAccount = $this->erpAccountFactory->create();

        $erpAccount->setName($this->getCustomerName($customer));
        $erpAccount->setEmail($customer->getEmail());
        $erpAccount->setAccountType('B'); // B2B

        // TODO: Add addresses, phone, etc. as needed
        // Can be extended to include billing/shipping addresses from the order

        return $erpAccount;
    }

    /**
     * Get customer full name
     *
     * @param CustomerInterface $customer
     * @return string
     */
    private function getCustomerName(CustomerInterface $customer): string
    {
        $firstname = $customer->getFirstname() ?? '';
        $lastname = $customer->getLastname() ?? '';

        return trim($firstname . ' ' . $lastname);
    }
}
